"""后台管理接口。"""
import random
import string
from datetime import datetime, timedelta
from typing import Optional
import io
import qrcode

from fastapi import APIRouter, Depends, HTTPException, status, Query, Request, UploadFile, File
from fastapi.responses import JSONResponse, StreamingResponse
from jose import JWTError, jwt
from sqlalchemy import select, func, desc

from ..config import SECRET_KEY, ALGORITHM
from ..database import get_db, get_password_hash, verify_password
from ..models import Admin, Activity, CheckinRecord, Student, ActivityEnrollment
from ..schemas import AdminLogin, AdminCreate, ActivityCreate, ActivityUpdate, ManualCheckin, Token, StudentImportRequest
from pydantic import BaseModel, Field

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False

router = APIRouter(prefix="/api/admin", tags=["管理员"])


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now() + (expires_delta or timedelta(hours=24))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def get_current_admin(token: str = Query(...)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        admin_id = payload.get("sub")
        if not admin_id:
            raise HTTPException(status_code=401, detail="无效的令牌")
        return int(admin_id)
    except JWTError:
        raise HTTPException(status_code=401, detail="无效的令牌")


def require_super_admin(admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin or not admin.is_super:
        raise HTTPException(status_code=403, detail="需要超级管理员权限")
    return admin_id


@router.post("/login", response_model=Token)
def login(payload: AdminLogin, db=Depends(get_db)):
    admin = db.execute(select(Admin).where(Admin.username == payload.username)).scalar_one_or_none()
    if not admin or not verify_password(payload.password, admin.password):
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    access_token = create_access_token(data={"sub": str(admin.id)})
    return Token(access_token=access_token, token_type="bearer", admin={
        "id": admin.id,
        "username": admin.username,
        "real_name": admin.real_name,
        "role": admin.role,
        "department": admin.department,
        "is_super": admin.is_super
    })


@router.post("/admins")
def create_admin(payload: AdminCreate, admin_id: int = Depends(require_super_admin), db=Depends(get_db)):
    existing = db.execute(select(Admin).where(Admin.username == payload.username)).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=400, detail="用户名已存在")
    admin = Admin(
        username=payload.username,
        password=get_password_hash(payload.password),
        real_name=payload.real_name,
        role=payload.role,
        department=payload.department,
        is_super=payload.is_super
    )
    db.add(admin)
    db.commit()
    return {"id": admin.id, "username": admin.username, "real_name": admin.real_name}


@router.get("/admins")
def list_admins(admin_id: int = Depends(require_super_admin), db=Depends(get_db)):
    admins = db.execute(select(Admin).order_by(desc(Admin.created_at))).scalars().all()
    return {"total": len(admins), "items": [{
        "id": a.id, "username": a.username, "real_name": a.real_name,
        "role": a.role, "department": a.department, "is_super": a.is_super,
        "created_at": str(a.created_at)
    } for a in admins]}


@router.delete("/admins/{admin_id}")
def delete_admin(admin_id: int, current_id: int = Depends(require_super_admin), db=Depends(get_db)):
    if admin_id == current_id:
        raise HTTPException(status_code=400, detail="不能删除自己")
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin:
        raise HTTPException(status_code=404, detail="管理员不存在")
    db.delete(admin)
    db.commit()
    return {"message": "删除成功"}


@router.post("/admins/{admin_id}/password")
def reset_password(admin_id: int, new_password: str, admin_id_cur: int = Depends(require_super_admin), db=Depends(get_db)):
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin:
        raise HTTPException(status_code=404, detail="管理员不存在")
    admin.password = get_password_hash(new_password)
    db.commit()
    return {"message": "密码重置成功"}


@router.post("/activities", response_model=dict)
def create_activity(payload: ActivityCreate, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    code = ''.join(random.choices(string.digits, k=6))
    while db.execute(select(Activity).where(Activity.code == code)).scalar_one_or_none():
        code = ''.join(random.choices(string.digits, k=6))
    activity = Activity(
        name=payload.name,
        description=payload.description,
        location=payload.location,
        department=admin.department,
        code=code,
        checkin_duration=payload.checkin_duration,
        code_refresh_interval=payload.code_refresh_interval,
        is_active=False,
        created_by=admin_id,
        
        enable_location_check=payload.enable_location_check,
        location_latitude=payload.location_latitude,
        location_longitude=payload.location_longitude,
        location_radius=payload.location_radius,
        
        enable_captcha=payload.enable_captcha,
        captcha_length=payload.captcha_length,
        captcha_refresh_interval=payload.captcha_refresh_interval
    )
    db.add(activity)
    db.commit()
    db.refresh(activity)
    return {
        "id": activity.id,
        "name": activity.name,
        "code": activity.code,
        "qr_code": f"/qr/{activity.code}",
        "enable_location_check": activity.enable_location_check,
        "enable_captcha": activity.enable_captcha
    }


@router.get("/activities")
def list_activities(admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if admin.is_super:
        activities = db.execute(select(Activity).order_by(desc(Activity.created_at))).scalars().all()
    else:
        activities = db.execute(select(Activity).where(Activity.department == admin.department).order_by(desc(Activity.created_at))).scalars().all()
    items = []
    for a in activities:
        checkin_count = db.execute(select(func.count(CheckinRecord.id)).where(CheckinRecord.activity_id == a.id)).scalar()
        if a.is_active:
            status_text = "进行中"
        else:
            status_text = "未开始"
        items.append({
            "id": a.id, "name": a.name, "description": a.description,
            "location": a.location, "department": a.department,
            "code": a.code, "qr_code": f"/qr/{a.code}",
            "checkin_duration": a.checkin_duration,
            "code_refresh_interval": a.code_refresh_interval,
            "is_active": a.is_active, "status": status_text,
            "checkin_count": checkin_count,
            "checkin_start": str(a.checkin_start) if a.checkin_start else None,
            "checkin_end": str(a.checkin_end) if a.checkin_end else None,
            "created_at": str(a.created_at),
            "enable_location_check": a.enable_location_check,
            "location_latitude": a.location_latitude,
            "location_longitude": a.location_longitude,
            "location_radius": a.location_radius,
            "enable_captcha": a.enable_captcha,
            "captcha_length": a.captcha_length,
            "captcha_refresh_interval": a.captcha_refresh_interval
        })
    return {"total": len(items), "items": items}


@router.get("/activities/{activity_id}")
def get_activity(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    checkin_count = db.execute(select(func.count(CheckinRecord.id)).where(CheckinRecord.activity_id == activity_id)).scalar()
    return {
        "id": activity.id, "name": activity.name, "description": activity.description,
        "location": activity.location, "department": activity.department,
        "code": activity.code, "qr_code": f"/qr/{activity.code}",
        "checkin_duration": activity.checkin_duration,
        "code_refresh_interval": activity.code_refresh_interval,
        "is_active": activity.is_active,
        "checkin_count": checkin_count,
        "checkin_start": str(activity.checkin_start) if activity.checkin_start else None,
        "checkin_end": str(activity.checkin_end) if activity.checkin_end else None,
        "enable_location_check": activity.enable_location_check,
        "location_latitude": activity.location_latitude,
        "location_longitude": activity.location_longitude,
        "location_radius": activity.location_radius,
        "enable_captcha": activity.enable_captcha,
        "captcha_length": activity.captcha_length,
        "captcha_refresh_interval": activity.captcha_refresh_interval
    }


@router.put("/activities/{activity_id}")
def update_activity(activity_id: int, payload: ActivityUpdate, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin.is_super and activity.created_by != admin_id:
        raise HTTPException(status_code=403, detail="无权修改此活动")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(activity, key, value)
    db.commit()
    return {"message": "更新成功"}


@router.delete("/activities/{activity_id}")
def delete_activity(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin.is_super and activity.created_by != admin_id:
        raise HTTPException(status_code=403, detail="无权删除此活动")
    db.delete(activity)
    db.commit()
    return {"message": "删除成功"}


@router.post("/activities/{activity_id}/refresh-code")
def refresh_code(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin.is_super and activity.created_by != admin_id:
        raise HTTPException(status_code=403, detail="无权操作此活动")
    new_code = ''.join(random.choices(string.digits, k=6))
    while db.execute(select(Activity).where(Activity.code == new_code)).scalar_one_or_none():
        new_code = ''.join(random.choices(string.digits, k=6))
    activity.code = new_code
    db.commit()
    return {"code": new_code, "qr_code": f"/qr/{new_code}"}


@router.post("/activities/{activity_id}/start")
def start_activity(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin.is_super and activity.created_by != admin_id:
        raise HTTPException(status_code=403, detail="无权操作此活动")
    if activity.is_active:
        raise HTTPException(status_code=400, detail="活动已经在进行中")
    now = datetime.now()
    activity.is_active = True
    activity.checkin_start = now
    activity.checkin_end = now + timedelta(minutes=activity.checkin_duration)
    db.commit()
    return {"message": "签到已发布", "checkin_end": str(activity.checkin_end)}


@router.post("/activities/{activity_id}/end")
def end_activity(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin.is_super and activity.created_by != admin_id:
        raise HTTPException(status_code=403, detail="无权操作此活动")
    if not activity.is_active:
        raise HTTPException(status_code=400, detail="活动还未开始")
    activity.is_active = False
    activity.checkin_end = datetime.now()
    db.commit()
    return {"message": "签到已结束"}


@router.get("/activities/{activity_id}/records")
def get_activity_records(activity_id: int, keyword: str = Query(None), admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    query = select(CheckinRecord).where(CheckinRecord.activity_id == activity_id)
    if keyword:
        query = query.where(
            (CheckinRecord.student_id.contains(keyword)) |
            (CheckinRecord.user_name.contains(keyword))
        )
    records = db.execute(query.order_by(desc(CheckinRecord.checkin_time))).scalars().all()
    return {"total": len(records), "items": [{
        "id": r.id, "student_id": r.student_id, "user_name": r.user_name,
        "class_name": r.class_name, "checkin_time": str(r.checkin_time),
        "checkin_method": r.checkin_method
    } for r in records]}


@router.get("/activities/{activity_id}/stats")
def get_activity_stats(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    total = db.execute(select(func.count(CheckinRecord.id)).where(CheckinRecord.activity_id == activity_id)).scalar()
    return {
        "activity_name": activity.name,
        "total_checkins": total,
        "is_active": activity.is_active
    }


class ImportStudents(BaseModel):
    students: list[dict] = Field(..., description="学生列表，包含student_id, name, class_name")


@router.post("/activities/{activity_id}/import-students")
def import_students(activity_id: int, payload: ImportStudents, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin.is_super and activity.created_by != admin_id:
        raise HTTPException(status_code=403, detail="无权操作此活动")
    
    count = 0
    for student in payload.students:
        if student.get('student_id') and student.get('name'):
            existing_student = db.execute(select(Student).where(Student.student_id == student['student_id'])).scalar_one_or_none()
            if not existing_student:
                new_student = Student(
                    student_id=student['student_id'],
                    name=student['name'],
                    class_name=student.get('class_name')
                )
                db.add(new_student)
                count += 1
    db.commit()
    return {"message": f"成功导入 {count} 名学生"}


@router.post("/activities/{activity_id}/checkin")
def manual_checkin(activity_id: int, payload: ManualCheckin, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    existing = db.execute(
        select(CheckinRecord).where(
            CheckinRecord.activity_id == activity_id,
            CheckinRecord.student_id == payload.student_id
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=400, detail="该学生已签到")
    record = CheckinRecord(
        user_name=payload.name,
        student_id=payload.student_id,
        class_name=payload.class_name,
        activity_id=activity_id,
        checkin_time=datetime.now(),
        checkin_method="manual"
    )
    db.add(record)
    db.commit()
    return {"message": "补签成功", "id": record.id}


@router.delete("/records/{record_id}")
def delete_record(record_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    record = db.execute(select(CheckinRecord).where(CheckinRecord.id == record_id)).scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="记录不存在")
    db.delete(record)
    db.commit()
    return {"message": "删除成功"}


@router.get("/records")
def get_all_records(keyword: str = Query(None), activity_id: int = Query(None), admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    query = select(CheckinRecord, Activity).join(Activity)
    if activity_id:
        query = query.where(CheckinRecord.activity_id == activity_id)
    if keyword:
        query = query.where(
            (CheckinRecord.student_id.contains(keyword)) |
            (CheckinRecord.user_name.contains(keyword))
        )
    results = db.execute(query.order_by(desc(CheckinRecord.checkin_time))).all()
    return {"total": len(results), "items": [{
        "id": r[0].id, "student_id": r[0].student_id, "user_name": r[0].user_name,
        "class_name": r[0].class_name, "checkin_time": str(r[0].checkin_time),
        "checkin_method": r[0].checkin_method, "activity_name": r[1].name
    } for r in results]}


@router.get("/students")
def get_students(keyword: str = Query(None), page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100), admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    query = select(Student)
    if keyword:
        query = query.where(
            (Student.student_id.contains(keyword)) |
            (Student.name.contains(keyword)) |
            (Student.class_name.contains(keyword))
        )
    total = db.execute(select(func.count()).select_from(query.subquery())).scalar()
    students = db.execute(query.order_by(desc(Student.created_at)).offset((page - 1) * page_size).limit(page_size)).scalars().all()
    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "items": [{
            "id": s.id, "student_id": s.student_id, "name": s.name,
            "class_name": s.class_name, "created_at": str(s.created_at)
        } for s in students]
    }


@router.post("/students/import")
def import_students(payload: StudentImportRequest, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    success_count = 0
    skip_count = 0
    errors = []
    
    for i, item in enumerate(payload.students):
        try:
            existing = db.execute(select(Student).where(Student.student_id == item.student_id)).scalar_one_or_none()
            if existing:
                skip_count += 1
                continue
            
            student = Student(
                student_id=item.student_id,
                name=item.name,
                class_name=item.class_name
            )
            db.add(student)
            success_count += 1
        except Exception as e:
            errors.append(f"第{i + 1}条: {str(e)}")
    
    db.commit()
    
    return {
        "success_count": success_count,
        "skip_count": skip_count,
        "errors": errors
    }


@router.delete("/students/{student_id}")
def delete_student(student_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    student = db.execute(select(Student).where(Student.id == student_id)).scalar_one_or_none()
    if not student:
        raise HTTPException(status_code=404, detail="学生不存在")
    db.delete(student)
    db.commit()
    return {"message": "删除成功"}


@router.delete("/students")
def clear_students(admin_id: int = Depends(require_super_admin), db=Depends(get_db)):
    students = db.execute(select(Student)).scalars().all()
    for s in students:
        db.delete(s)
    db.commit()
    return {"message": "清空成功"}


@router.get("/activities/{activity_id}/qr-code")
def generate_qr_code(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    
    qr_data = f"CHECKIN:{activity.code}"
    img = qrcode.make(qr_data)
    
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    
    return StreamingResponse(buf, media_type='image/png')


@router.get("/activities/{activity_id}/students")
def get_activity_students(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    
    records = db.execute(
        select(CheckinRecord).where(CheckinRecord.activity_id == activity_id)
        .order_by(CheckinRecord.checkin_time)
    ).scalars().all()
    
    return {
        "activity_name": activity.name,
        "total": len(records),
        "items": [{
            "student_id": r.student_id,
            "student_name": r.user_name,
            "class_name": r.class_name,
            "checkin_time": str(r.checkin_time) if r.checkin_time else None,
            "checkin_method": r.checkin_method
        } for r in records]
    }


class EnrollStudent(BaseModel):
    student_id: str = Field(..., description="学号")
    student_name: str = Field(..., description="姓名")
    class_name: str = Field(None, description="班级")


class EnrollStudentsBatch(BaseModel):
    students: list[EnrollStudent] = Field(..., description="报名学生列表")


@router.post("/activities/{activity_id}/enroll")
def enroll_student(activity_id: int, payload: EnrollStudent, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    
    existing = db.execute(
        select(ActivityEnrollment).where(
            ActivityEnrollment.activity_id == activity_id,
            ActivityEnrollment.student_id == payload.student_id
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=400, detail="该学生已报名")
    
    enrollment = ActivityEnrollment(
        activity_id=activity_id,
        student_id=payload.student_id,
        student_name=payload.student_name,
        class_name=payload.class_name
    )
    db.add(enrollment)
    db.commit()
    
    return {"message": "报名成功", "id": enrollment.id}


@router.post("/activities/{activity_id}/enroll/batch")
def batch_enroll_students(activity_id: int, payload: EnrollStudentsBatch, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    
    success_count = 0
    skip_count = 0
    
    for student in payload.students:
        existing = db.execute(
            select(ActivityEnrollment).where(
                ActivityEnrollment.activity_id == activity_id,
                ActivityEnrollment.student_id == student.student_id
            )
        ).scalar_one_or_none()
        if existing:
            skip_count += 1
            continue
        
        enrollment = ActivityEnrollment(
            activity_id=activity_id,
            student_id=student.student_id,
            student_name=student.student_name,
            class_name=student.class_name
        )
        db.add(enrollment)
        success_count += 1
    
    db.commit()
    
    return {"success_count": success_count, "skip_count": skip_count}


@router.get("/activities/{activity_id}/enrollments")
def get_activity_enrollments(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    
    enrollments = db.execute(
        select(ActivityEnrollment).where(ActivityEnrollment.activity_id == activity_id)
        .order_by(ActivityEnrollment.enrolled_at)
    ).scalars().all()
    
    return {
        "activity_name": activity.name,
        "total": len(enrollments),
        "items": [{
            "id": e.id,
            "student_id": e.student_id,
            "student_name": e.student_name,
            "class_name": e.class_name,
            "enrolled_at": str(e.enrolled_at),
            "is_checked_in": e.is_checked_in
        } for e in enrollments]
    }


@router.delete("/activities/{activity_id}/enrollments/{enrollment_id}")
def delete_enrollment(activity_id: int, enrollment_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    enrollment = db.execute(
        select(ActivityEnrollment).where(
            ActivityEnrollment.id == enrollment_id,
            ActivityEnrollment.activity_id == activity_id
        )
    ).scalar_one_or_none()
    if not enrollment:
        raise HTTPException(status_code=404, detail="报名记录不存在")
    
    db.delete(enrollment)
    db.commit()
    
    return {"message": "删除成功"}


@router.get("/activities/{activity_id}/checkin-report")
def get_checkin_report(activity_id: int, admin_id: int = Depends(get_current_admin), db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    
    enrollments = db.execute(
        select(ActivityEnrollment).where(ActivityEnrollment.activity_id == activity_id)
    ).scalars().all()
    
    records = db.execute(
        select(CheckinRecord).where(CheckinRecord.activity_id == activity_id)
    ).scalars().all()
    
    checked_in_ids = set(r.student_id for r in records)
    
    report_data = []
    for enrollment in enrollments:
        is_checked = enrollment.student_id in checked_in_ids
        record = next((r for r in records if r.student_id == enrollment.student_id), None)
        report_data.append({
            "student_id": enrollment.student_id,
            "student_name": enrollment.student_name,
            "class_name": enrollment.class_name,
            "enrolled_at": str(enrollment.enrolled_at),
            "is_checked_in": is_checked,
            "checkin_time": str(record.checkin_time) if record else None,
            "checkin_method": record.checkin_method if record else None
        })
    
    return {
        "activity_name": activity.name,
        "total_enrolled": len(enrollments),
        "total_checked_in": len(checked_in_ids),
        "absent_count": len(enrollments) - len(checked_in_ids),
        "items": report_data
    }


@router.post("/activities/{activity_id}/import-excel")
def import_enrollments_excel(
    activity_id: int,
    file: UploadFile = File(...),
    admin_id: int = Depends(get_current_admin),
    db=Depends(get_db)
):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    
    admin = db.execute(select(Admin).where(Admin.id == admin_id)).scalar_one_or_none()
    if not admin.is_super and activity.department != admin.department:
        raise HTTPException(status_code=403, detail="只能导入本部门活动的名单")
    
    if not PANDAS_AVAILABLE:
        raise HTTPException(status_code=400, detail="请先安装pandas和openpyxl库")
    
    content = file.file.read()
    try:
        df = pd.read_excel(io.BytesIO(content), engine='openpyxl')
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Excel解析失败: {str(e)}")
    
    required_columns = ['学号', '姓名']
    for col in required_columns:
        if col not in df.columns:
            raise HTTPException(status_code=400, detail=f"Excel缺少必要列: {col}")
    
    success_count = 0
    skip_count = 0
    errors = []
    
    for idx, row in df.iterrows():
        try:
            student_id = str(row['学号']).strip()
            student_name = str(row['姓名']).strip()
            if not student_id or not student_name:
                skip_count += 1
                continue
            
            class_name = str(row.get('班级', '')) if pd.notna(row.get('班级')) else None
            
            existing = db.execute(
                select(ActivityEnrollment).where(
                    ActivityEnrollment.activity_id == activity_id,
                    ActivityEnrollment.student_id == student_id
                )
            ).scalar_one_or_none()
            
            if existing:
                skip_count += 1
                continue
            
            enrollment = ActivityEnrollment(
                activity_id=activity_id,
                student_id=student_id,
                student_name=student_name,
                class_name=class_name
            )
            db.add(enrollment)
            success_count += 1
        except Exception as e:
            errors.append(f"第{idx+2}行: {str(e)}")
    
    db.commit()
    
    return {
        "success": True,
        "success_count": success_count,
        "skip_count": skip_count,
        "errors": errors
    }
