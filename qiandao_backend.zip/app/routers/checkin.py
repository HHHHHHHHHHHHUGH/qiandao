"""学生签到接口。"""
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, Query, Cookie
from fastapi.responses import JSONResponse
from sqlalchemy import select, func

from ..database import get_db
from ..models import Activity, CheckinRecord, Student, ActivityCaptcha
from ..schemas import StudentCheckin

router = APIRouter(prefix="/api", tags=["学生签到"])

def generate_session_token():
    import random
    import string
    return ''.join(random.choices(string.ascii_letters + string.digits, k=32))

def generate_captcha(length=4):
    import random
    import string
    return ''.join(random.choices(string.digits, k=length))

student_sessions = {}

def haversine_distance(lat1, lon1, lat2, lon2):
    """计算两点之间的距离（米）"""
    from math import radians, sin, cos, sqrt, atan2
    R = 6371000  
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * atan2(sqrt(a), sqrt(1-a))
    return R * c

def get_current_student(token: str = Query(None), session_token: str = Cookie(None), db=Depends(get_db)):
    actual_token = token or session_token
    if not actual_token or actual_token not in student_sessions:
        raise HTTPException(status_code=401, detail="请先登录")
    data = student_sessions[actual_token]
    if datetime.now() > data['expire_time']:
        del student_sessions[actual_token]
        raise HTTPException(status_code=401, detail="登录已过期，请重新登录")
    student = db.execute(select(Student).where(Student.student_id == data['student_id'])).scalar_one_or_none()
    return student


@router.post("/checkin")
def student_checkin(payload: StudentCheckin, request: Request, db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.code == payload.activity_code)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="签到码错误，活动不存在")
    if not activity.is_active:
        raise HTTPException(status_code=400, detail="活动已结束")
    now = datetime.now()
    if now < activity.checkin_start:
        raise HTTPException(status_code=400, detail=f"签到还未开始，开始时间：{activity.checkin_start}")
    if now > activity.checkin_end:
        raise HTTPException(status_code=400, detail=f"签到已结束，结束时间：{activity.checkin_end}")
    
    if activity.enable_location_check:
        if not payload.latitude or not payload.longitude:
            raise HTTPException(status_code=400, detail="请授权获取位置信息")
        if not activity.location_latitude or not activity.location_longitude:
            raise HTTPException(status_code=400, detail="活动定位信息未设置")
        
        distance = haversine_distance(
            payload.latitude, payload.longitude,
            activity.location_latitude, activity.location_longitude
        )
        
        if distance > activity.location_radius:
            raise HTTPException(status_code=400, detail=f"您当前位置距离签到点太远（{int(distance)}米），请前往指定地点签到")
    
    if activity.enable_captcha:
        if not payload.captcha:
            raise HTTPException(status_code=400, detail="请输入验证码")
        
        current_captcha = db.execute(
            select(ActivityCaptcha).where(
                ActivityCaptcha.activity_id == activity.id,
                ActivityCaptcha.expires_at > now
            ).order_by(func.desc(ActivityCaptcha.created_at)).limit(1)
        ).scalar_one_or_none()
        
        if not current_captcha:
            raise HTTPException(status_code=400, detail="验证码已过期，请刷新页面")
        
        if current_captcha.captcha != payload.captcha:
            raise HTTPException(status_code=400, detail="验证码错误，请重新输入")
    
    existing = db.execute(
        select(CheckinRecord).where(
            CheckinRecord.activity_id == activity.id,
            CheckinRecord.student_id == payload.student_id
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=400, detail="您已完成签到，无需重复签到")
    
    record = CheckinRecord(
        user_name=payload.name,
        student_id=payload.student_id,
        activity_id=activity.id,
        checkin_time=now,
        checkin_method="code",
        ip=request.client.host if request.client else None
    )
    db.add(record)
    student = db.execute(select(Student).where(Student.student_id == payload.student_id)).scalar_one_or_none()
    if student:
        student.name = payload.name
    else:
        student = Student(student_id=payload.student_id, name=payload.name)
        db.add(student)
    db.commit()
    return {
        "message": "签到成功",
        "activity_name": activity.name,
        "checkin_time": now.strftime("%Y-%m-%d %H:%M:%S")
    }


@router.get("/activities")
def list_active_activities(db=Depends(get_db)):
    now = datetime.now()
    activities = db.execute(
        select(Activity).where(
            Activity.is_active == True,
            Activity.checkin_start <= now,
            Activity.checkin_end >= now
        ).order_by(func.desc(Activity.created_at))
    ).scalars().all()
    return {"total": len(activities), "items": [{
        "id": a.id, "name": a.name, "description": a.description,
        "location": a.location, "speaker": a.speaker, "department": a.department,
        "checkin_start": str(a.checkin_start), "checkin_end": str(a.checkin_end),
        "enable_location_check": a.enable_location_check,
        "enable_captcha": a.enable_captcha,
        "captcha_refresh_interval": a.captcha_refresh_interval
    } for a in activities]}


@router.get("/my/records")
def get_my_records(student_id: str = Query(...), db=Depends(get_db)):
    records = db.execute(
        select(CheckinRecord, Activity).join(Activity).where(
            CheckinRecord.student_id == student_id
        ).order_by(func.desc(CheckinRecord.checkin_time))
    ).all()
    return [{"activity_name": r[1].name, "checkin_time": str(r[0].checkin_time)} for r in records]


@router.post("/student/login")
def student_login(payload: dict, db=Depends(get_db)):
    student_id = str(payload.get('student_id', '')).strip()
    name = str(payload.get('name', '')).strip()
    if not student_id or not name:
        raise HTTPException(status_code=400, detail="请输入姓名和学号")
    
    student = db.execute(select(Student).where(Student.student_id == student_id)).scalar_one_or_none()
    if not student:
        raise HTTPException(status_code=404, detail="该学号不存在，请联系管理员")
    
    db_name = str(student.name).strip()
    if db_name != name and not db_name.startswith(name) and not name.startswith(db_name):
        raise HTTPException(status_code=400, detail=f"姓名与学号不匹配，系统中记录的姓名是: {db_name}")
    
    session_token = generate_session_token()
    student_sessions[session_token] = {
        "student_id": student_id,
        "name": student.name,
        "expire_time": datetime.now() + timedelta(hours=24)
    }
    
    return {
        "message": "登录成功",
        "token": session_token,
        "student_id": student_id,
        "name": student.name,
        "class_name": student.class_name
    }


@router.post("/student/logout")
def student_logout(session_token: str = Cookie(None)):
    if session_token and session_token in student_sessions:
        del student_sessions[session_token]
    
    response = JSONResponse({"message": "已退出登录"})
    response.delete_cookie(key="student_session", path="/")
    return response


@router.get("/student/me")
def get_student_info(student: Student = Depends(get_current_student)):
    return {
        "student_id": student.student_id,
        "name": student.name,
        "class_name": student.class_name
    }


@router.get("/student/profile")
def get_student_profile(student: Student = Depends(get_current_student)):
    return {
        "student_id": student.student_id,
        "name": student.name,
        "class_name": student.class_name
    }


@router.get("/student/current-checkin")
def get_current_checkin(student: Student = Depends(get_current_student), db=Depends(get_db)):
    now = datetime.now()
    activity = db.execute(
        select(Activity).where(
            Activity.is_active == True,
            Activity.checkin_start <= now,
            Activity.checkin_end >= now
        ).order_by(func.desc(Activity.created_at)).limit(1)
    ).scalar_one_or_none()
    
    if activity:
        return {
            "activity": {
                "id": activity.id,
                "name": activity.name,
                "location": activity.location,
                "checkin_start": str(activity.checkin_start),
                "checkin_end": str(activity.checkin_end),
                "enable_location_check": activity.enable_location_check,
                "enable_captcha": activity.enable_captcha,
                "captcha_refresh_interval": activity.captcha_refresh_interval,
                "location_latitude": activity.location_latitude,
                "location_longitude": activity.location_longitude,
                "location_radius": activity.location_radius
            },
            "code": activity.code
        }
    return {"activity": None, "code": None}


@router.get("/qr/{code}")
def get_qr_code(code: str, db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.code == code)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    return {
        "code": activity.code,
        "name": activity.name,
        "qr_data": f"CHECKIN:{activity.code}"
    }


@router.get("/student/activities")
def list_student_activities(student: Student = Depends(get_current_student), db=Depends(get_db)):
    now = datetime.now()
    activities = db.execute(
        select(Activity).where(
            Activity.is_active == True,
            Activity.checkin_start <= now,
            Activity.checkin_end >= now
        ).order_by(func.desc(Activity.created_at))
    ).scalars().all()
    return {"total": len(activities), "items": [{
        "id": a.id, "name": a.name, "description": a.description,
        "location": a.location, "department": a.department,
        "checkin_start": str(a.checkin_start), "checkin_end": str(a.checkin_end),
        "enable_location_check": a.enable_location_check,
        "enable_captcha": a.enable_captcha,
        "captcha_refresh_interval": a.captcha_refresh_interval,
        "location_latitude": a.location_latitude,
        "location_longitude": a.location_longitude,
        "location_radius": a.location_radius
    } for a in activities]}


@router.get("/student/records")
def get_student_records(student: Student = Depends(get_current_student), db=Depends(get_db)):
    records = db.execute(
        select(CheckinRecord, Activity).join(Activity).where(
            CheckinRecord.student_id == student.student_id
        ).order_by(func.desc(CheckinRecord.checkin_time))
    ).all()
    return [{"activity_name": r[1].name, "checkin_time": str(r[0].checkin_time)} for r in records]


@router.post("/student/checkin")
def student_checkin_with_login(student: Student = Depends(get_current_student), request: Request = None, db=Depends(get_db)):
    now = datetime.now()
    activity = db.execute(
        select(Activity).where(
            Activity.is_active == True,
            Activity.checkin_start <= now,
            Activity.checkin_end >= now
        ).order_by(func.desc(Activity.created_at)).limit(1)
    ).scalar_one_or_none()
    
    if not activity:
        raise HTTPException(status_code=404, detail="当前没有进行中的活动")
    if not activity.is_active:
        raise HTTPException(status_code=400, detail="活动已结束")
    if not activity.code:
        raise HTTPException(status_code=400, detail="活动签到码尚未发布")
    if now < activity.checkin_start:
        raise HTTPException(status_code=400, detail=f"签到还未开始，开始时间：{activity.checkin_start}")
    if now > activity.checkin_end:
        raise HTTPException(status_code=400, detail=f"签到已结束，结束时间：{activity.checkin_end}")
    existing = db.execute(
        select(CheckinRecord).where(
            CheckinRecord.activity_id == activity.id,
            CheckinRecord.student_id == student.student_id
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=400, detail="您已完成签到，无需重复签到")
    record = CheckinRecord(
        user_name=student.name,
        student_id=student.student_id,
        activity_id=activity.id,
        checkin_time=now,
        checkin_method="code",
        ip=request.client.host if request else None
    )
    db.add(record)
    db.commit()
    return {
        "message": "签到成功",
        "activity_name": activity.name,
        "checkin_time": now.strftime("%Y-%m-%d %H:%M:%S")
    }


@router.get("/activity/{activity_id}/captcha")
def get_activity_captcha(activity_id: int, db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    
    if not activity.enable_captcha:
        return {"captcha_enabled": False}
    
    now = datetime.now()
    
    current_captcha = db.execute(
        select(ActivityCaptcha).where(
            ActivityCaptcha.activity_id == activity_id,
            ActivityCaptcha.expires_at > now
        ).order_by(func.desc(ActivityCaptcha.created_at)).limit(1)
    ).scalar_one_or_none()
    
    if current_captcha:
        remaining_seconds = int((current_captcha.expires_at - now).total_seconds())
        return {
            "captcha_enabled": True,
            "captcha": current_captcha.captcha,
            "expires_in": remaining_seconds,
            "refresh_interval": activity.captcha_refresh_interval
        }
    
    new_captcha = generate_captcha(activity.captcha_length)
    expires_at = now + timedelta(seconds=activity.captcha_refresh_interval)
    
    captcha_record = ActivityCaptcha(
        activity_id=activity_id,
        captcha=new_captcha,
        expires_at=expires_at
    )
    db.add(captcha_record)
    db.commit()
    
    return {
        "captcha_enabled": True,
        "captcha": new_captcha,
        "expires_in": activity.captcha_refresh_interval,
        "refresh_interval": activity.captcha_refresh_interval
    }


@router.post("/activity/{activity_id}/refresh-captcha")
def refresh_activity_captcha(activity_id: int, db=Depends(get_db)):
    activity = db.execute(select(Activity).where(Activity.id == activity_id)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    
    if not activity.enable_captcha:
        raise HTTPException(status_code=400, detail="该活动未启用验证码")
    
    now = datetime.now()
    new_captcha = generate_captcha(activity.captcha_length)
    expires_at = now + timedelta(seconds=activity.captcha_refresh_interval)
    
    captcha_record = ActivityCaptcha(
        activity_id=activity_id,
        captcha=new_captcha,
        expires_at=expires_at
    )
    db.add(captcha_record)
    db.commit()
    
    return {
        "captcha": new_captcha,
        "expires_in": activity.captcha_refresh_interval,
        "refresh_interval": activity.captcha_refresh_interval
    }


@router.post("/checkin-with-location")
def checkin_with_location(
    activity_code: str = Query(...),
    student_id: str = Query(...),
    name: str = Query(...),
    latitude: float = Query(None),
    longitude: float = Query(None),
    captcha: str = Query(None),
    db=Depends(get_db)
):
    activity = db.execute(select(Activity).where(Activity.code == activity_code)).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="签到码错误，活动不存在")
    if not activity.is_active:
        raise HTTPException(status_code=400, detail="活动已结束")
    now = datetime.now()
    if now < activity.checkin_start:
        raise HTTPException(status_code=400, detail=f"签到还未开始，开始时间：{activity.checkin_start}")
    if now > activity.checkin_end:
        raise HTTPException(status_code=400, detail=f"签到已结束，结束时间：{activity.checkin_end}")
    
    if activity.enable_location_check:
        if not latitude or not longitude:
            raise HTTPException(status_code=400, detail="请授权获取位置信息")
        if not activity.location_latitude or not activity.location_longitude:
            raise HTTPException(status_code=400, detail="活动定位信息未设置")
        
        distance = haversine_distance(
            latitude, longitude,
            activity.location_latitude, activity.location_longitude
        )
        
        if distance > activity.location_radius:
            raise HTTPException(status_code=400, detail=f"您当前位置距离签到点太远（{int(distance)}米），请前往指定地点签到")
    
    if activity.enable_captcha:
        if not captcha:
            raise HTTPException(status_code=400, detail="请输入验证码")
        
        current_captcha = db.execute(
            select(ActivityCaptcha).where(
                ActivityCaptcha.activity_id == activity.id,
                ActivityCaptcha.expires_at > now
            ).order_by(func.desc(ActivityCaptcha.created_at)).limit(1)
        ).scalar_one_or_none()
        
        if not current_captcha:
            raise HTTPException(status_code=400, detail="验证码已过期，请刷新页面")
        
        if current_captcha.captcha != captcha:
            raise HTTPException(status_code=400, detail="验证码错误，请重新输入")
    
    existing = db.execute(
        select(CheckinRecord).where(
            CheckinRecord.activity_id == activity.id,
            CheckinRecord.student_id == student_id
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=400, detail="您已完成签到，无需重复签到")
    
    record = CheckinRecord(
        user_name=name,
        student_id=student_id,
        activity_id=activity.id,
        checkin_time=now,
        checkin_method="code"
    )
    db.add(record)
    student = db.execute(select(Student).where(Student.student_id == student_id)).scalar_one_or_none()
    if student:
        student.name = name
    else:
        student = Student(student_id=student_id, name=name)
        db.add(student)
    db.commit()
    return {
        "message": "签到成功",
        "activity_name": activity.name,
        "checkin_time": now.strftime("%Y-%m-%d %H:%M:%S")
    }
