"""完整学生签到页面 - 包含登录"""

COMPLETE_STUDENT_HTML = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>学生签到系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
            overflow-y: auto;
        }
        .bg-decoration {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            overflow: hidden;
            z-index: 0;
        }
        .bg-decoration::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -25%;
            width: 800px;
            height: 800px;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            border-radius: 50%;
        }
        .bg-decoration::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -20%;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 70%);
            border-radius: 50%;
        }
        .login-container {
            max-width: 420px;
            margin: 80px auto;
            padding: 0 20px;
            position: relative;
            z-index: 10;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 48px 36px;
            box-shadow: 0 25px 80px rgba(102, 126, 234, 0.35), 0 0 0 1px rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
        }
        .login-logo {
            width: 90px;
            height: 90px;
            margin: 0 auto 28px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 42px;
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.5);
            animation: float 3s ease-in-out infinite;
        }
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        .login-title {
            text-align: center;
            font-size: 28px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 10px;
            letter-spacing: 1px;
        }
        .login-desc {
            text-align: center;
            font-size: 14px;
            color: #666;
            margin-bottom: 36px;
        }

        .form-group { margin-bottom: 20px; }
        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
            letter-spacing: 0.5px;
        }
        input {
            width: 100%;
            padding: 16px 20px;
            border: 2px solid #e8e8e8;
            border-radius: 14px;
            font-size: 15px;
            outline: none;
            transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
            background: white;
            color: #333;
        }
        input::placeholder {
            color: #aaa;
        }
        input:focus {
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.12);
            transform: translateY(-1px);
        }
        .btn {
            width: 100%;
            padding: 18px;
            border: none;
            border-radius: 14px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
            letter-spacing: 1px;
        }
        .btn:hover { 
            transform: translateY(-3px); 
            box-shadow: 0 12px 35px rgba(102, 126, 234, 0.55); 
        }
        .btn:active {
            transform: translateY(-1px);
        }
        .result {
            padding: 16px;
            border-radius: 12px;
            margin-top: 16px;
            text-align: center;
            display: none;
        }
        .result-success { background: #e8f5e9; color: #2e7d32; border: 1px solid #c8e6c9; }
        .result-error { background: #ffebee; color: #c62828; border: 1px solid #ffcdd2; }
        .back-link {
            display: block;
            text-align: center;
            padding: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 24px;
            text-align: center;
            box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
        }
        .header h1 { font-size: 22px; margin-bottom: 4px; }
        .header p { font-size: 13px; opacity: 0.9; }

        .user-info {
            background: white;
            padding: 16px 24px;
            margin: 16px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .user-info .left { display: flex; align-items: center; gap: 12px; }
        .user-info .avatar {
            width: 44px; height: 44px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 18px;
        }
        .user-info .name { font-weight: 600; color: #333; }
        .user-info .class { font-size: 13px; color: #999; }
        .user-info .logout {
            color: #f44336;
            font-size: 13px;
            cursor: pointer;
            padding: 8px 16px;
            border-radius: 8px;
            transition: background 0.3s;
        }
        .user-info .logout:hover { background: #ffebee; }

        .tabs {
            display: flex;
            background: white;
            padding: 8px;
            margin: 16px;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }
        .tab {
            flex: 1;
            padding: 12px 16px;
            text-align: center;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            color: #666;
        }
        .tab.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .container { max-width: 500px; margin: 0 auto; padding: 0 16px; position: relative; z-index: 10; }
        .card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }
        .card-title {
            font-size: 17px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .activity-item {
            padding: 16px;
            border-radius: 12px;
            background: #f8f9fa;
            margin-bottom: 12px;
            border-left: 4px solid #667eea;
        }
        .activity-item h3 { font-size: 15px; color: #333; margin-bottom: 4px; }
        .activity-item p { font-size: 13px; color: #666; }

        .record-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px;
            border-bottom: 1px solid #eee;
        }
        .record-item:last-child { border-bottom: none; }
        .record-info h4 { font-size: 15px; color: #333; }
        .record-info p { font-size: 12px; color: #999; margin-top: 2px; }
        .record-time { font-size: 13px; color: #667eea; }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }
        .empty-state .icon { font-size: 48px; margin-bottom: 12px; opacity: 0.5; }
        .empty-state p { font-size: 14px; }

        .page { display: none; }
        .page.active { display: block; }
    </style>
</head>
<body>
    <div class="bg-decoration"></div>
    <div id="loginPage">
        <div class="login-container">
            <div class="login-card">
                <div class="login-logo">📱</div>
                <div class="login-title">学生登录</div>
                <div class="login-desc">请输入学号和姓名进行验证</div>

                <div class="form-group">
                    <label>姓名</label>
                    <input type="text" id="loginName" placeholder="请输入姓名">
                </div>
                <div class="form-group">
                    <label>学号</label>
                    <input type="text" id="loginStudentId" placeholder="请输入学号">
                </div>
                <button type="button" class="btn" onclick="login()">🔐 登录</button>
                <div id="loginResult" class="result"></div>
            </div>
            <a href="/" class="back-link">← 返回首页</a>
        </div>
    </div>

    <div id="mainPage" style="display: none;">
        <div class="header">
            <h1>📱 学生签到</h1>
            <p>便捷高效的校园活动签到</p>
        </div>

        <div class="container">
            <div class="user-info">
                <div class="left">
                    <div class="avatar" id="avatar">?</div>
                    <div>
                        <div class="name" id="userName">姓名</div>
                        <div class="class" id="userStudentId">学号</div>
                    </div>
                </div>
                <div class="logout" onclick="logout()">退出登录</div>
            </div>

            <div class="tabs">
                <div class="tab active" onclick="switchTab('checkin')">🔐 签到</div>
                <div class="tab" onclick="switchTab('activities')">📋 活动</div>
                <div class="tab" onclick="switchTab('records')">📊 记录</div>
            </div>

            <div id="checkinPage" class="page active">
                <div class="card">
                    <div class="card-title">📝 签到</div>
                    <div class="form-group">
                        <label>签到码</label>
                        <input type="text" id="code" placeholder="请输入6位签到码" maxlength="6">
                    </div>
                    <button type="button" class="btn" onclick="doCheckin()">✅ 立即签到</button>
                    <div id="checkinResult" class="result"></div>
                </div>
            </div>

            <div id="activitiesPage" class="page">
                <div class="card">
                    <div class="card-title">🎯 当前活动</div>
                    <div id="activitiesList">
                        <div class="empty-state">
                            <div class="icon">🔄</div>
                            <p>加载中...</p>
                        </div>
                    </div>
                </div>
            </div>

            <div id="recordsPage" class="page">
                <div class="card">
                    <div class="card-title">📈 我的签到记录</div>
                    <div id="recordsList">
                        <div class="empty-state">
                            <div class="icon">🔄</div>
                            <p>加载中...</p>
                        </div>
                    </div>
                </div>
            </div>

            <a href="/" class="back-link">← 返回首页</a>
        </div>
    </div>

    <script>
        let currentUser = null;

        async function checkLogin() {
            try {
                const response = await fetch('/api/student/me', { credentials: 'include' });
                if (response.ok) {
                    const data = await response.json();
                    currentUser = data;
                    showMainPage(data);
                } else {
                    showLoginPage();
                }
            } catch (error) {
                showLoginPage();
            }
        }

        function showLoginPage() {
            document.getElementById('loginPage').style.display = 'block';
            document.getElementById('mainPage').style.display = 'none';
        }

        function showMainPage(user) {
            document.getElementById('loginPage').style.display = 'none';
            document.getElementById('mainPage').style.display = 'block';

            document.getElementById('avatar').textContent = user.name.charAt(0);
            document.getElementById('userName').textContent = user.name;
            document.getElementById('userStudentId').textContent = user.student_id;

            loadActivities();
            loadRecords();
        }

        async function login() {
            const studentId = document.getElementById('loginStudentId').value.trim();
            const name = document.getElementById('loginName').value.trim();
            const result = document.getElementById('loginResult');

            if (!studentId || !name) {
                result.style.display = 'block';
                result.className = 'result result-error';
                result.textContent = '请填写学号和姓名';
                return;
            }

            if (!/^[0-9]+$/.test(studentId)) {
                result.style.display = 'block';
                result.className = 'result result-error';
                result.textContent = '学号只能包含数字';
                return;
            }

            if (!/^[\u4e00-\u9fa5]+$/.test(name)) {
                result.style.display = 'block';
                result.className = 'result result-error';
                result.textContent = '姓名只能使用中文';
                return;
            }

            try {
                const response = await fetch('/api/student/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ student_id: studentId, name: name }),
                    credentials: 'include'
                });
                const data = await response.json();
                if (response.ok) {
                    result.style.display = 'block';
                    result.className = 'result result-success';
                    result.textContent = '✅ 登录成功！';
                    setTimeout(() => {
                        currentUser = data;
                        showMainPage(data);
                    }, 1000);
                } else {
                    result.style.display = 'block';
                    result.className = 'result result-error';
                    result.textContent = data.detail || '登录失败';
                }
            } catch (error) {
                result.style.display = 'block';
                result.className = 'result result-error';
                result.textContent = '网络错误: ' + error.message;
            }
        }

        function switchTab(tabName) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
            event.target.classList.add('active');
            document.getElementById(tabName + 'Page').classList.add('active');

            if (tabName === 'activities') loadActivities();
            if (tabName === 'records') loadRecords();
        }

        async function loadActivities() {
            const list = document.getElementById('activitiesList');
            list.innerHTML = '<div class="empty-state"><div class="icon">🔄</div><p>加载中...</p></div>';
            try {
                const response = await fetch('/api/student/activities', { credentials: 'include' });
                const data = await response.json();
                if (data.items && data.items.length > 0) {
                    list.innerHTML = data.items.map(a => '<div class="activity-item"><h3>' + a.name + '</h3><p>📍 ' + (a.location || '未设置地点') + '</p></div>').join('');
                } else {
                    list.innerHTML = '<div class="empty-state"><div class="icon">🎭</div><p>暂无进行中的活动</p></div>';
                }
            } catch (error) {
                list.innerHTML = '<div class="empty-state"><div class="icon">❌</div><p>加载失败: ' + error.message + '</p></div>';
            }
        }

        async function loadRecords() {
            const list = document.getElementById('recordsList');
            list.innerHTML = '<div class="empty-state"><div class="icon">🔄</div><p>加载中...</p></div>';
            try {
                const response = await fetch('/api/student/records', { credentials: 'include' });
                const data = await response.json();
                if (data && data.length > 0) {
                    list.innerHTML = data.map(r => '<div class="record-item"><div class="record-info"><h4>' + r.activity_name + '</h4></div><div class="record-time">' + (r.checkin_time || '') + '</div></div>').join('');
                } else {
                    list.innerHTML = '<div class="empty-state"><div class="icon">📭</div><p>暂无签到记录</p></div>';
                }
            } catch (error) {
                list.innerHTML = '<div class="empty-state"><div class="icon">❌</div><p>加载失败: ' + error.message + '</p></div>';
            }
        }

        async function doCheckin() {
            const code = document.getElementById('code').value.trim();
            const result = document.getElementById('checkinResult');
            if (!code) {
                result.style.display = 'block';
                result.className = 'result result-error';
                result.textContent = '请输入签到码';
                return;
            }
            if (code.length !== 6) {
                result.style.display = 'block';
                result.className = 'result result-error';
                result.textContent = '签到码必须是6位数字';
                return;
            }
            try {
                const response = await fetch('/api/student/checkin', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ code: code }),
                    credentials: 'include'
                });
                const data = await response.json();
                if (response.ok) {
                    result.style.display = 'block';
                    result.className = 'result result-success';
                    result.textContent = '✅ 签到成功！';
                    document.getElementById('code').value = '';
                    loadRecords();
                } else {
                    result.style.display = 'block';
                    result.className = 'result result-error';
                    result.textContent = data.detail || '签到失败';
                }
            } catch (error) {
                result.style.display = 'block';
                result.className = 'result result-error';
                result.textContent = '网络错误: ' + error.message;
            }
        }

        async function logout() {
            try {
                await fetch('/api/student/logout', { method: 'POST', credentials: 'include' });
            } catch (e) {}
            currentUser = null;
            showLoginPage();
        }

        checkLogin();
    </script>
</body>
</html>'''
