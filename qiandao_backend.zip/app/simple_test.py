"""简单测试页面 - 登录后跳转"""

SIMPLE_TEST_HTML = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>测试登录</title>
    <script>
        async function doLogin() {
            const sid = document.getElementById('sid').value;
            const name = document.getElementById('name').value;
            
            console.log('登录按钮点击，学号:', sid, '姓名:', name);
            document.getElementById('result').innerHTML = '⏳ 正在登录...';
            
            try {
                const response = await fetch('/api/student/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ student_id: sid, name: name }),
                    credentials: 'include'
                });
                
                console.log('响应状态:', response.status);
                const data = await response.json();
                console.log('响应数据:', data);
                
                if (response.ok) {
                    document.getElementById('result').innerHTML = '✅ 登录成功！准备跳转...';
                    setTimeout(() => {
                        console.log('开始跳转');
                        window.location.replace('/student');
                    }, 800);
                } else {
                    document.getElementById('result').innerHTML = '❌ 登录失败: ' + data.detail;
                }
            } catch (error) {
                console.error('错误:', error);
                document.getElementById('result').innerHTML = '❌ 网络错误: ' + error.message;
            }
        }
    </script>
</head>
<body>
    <h1>测试登录</h1>
    <input type="text" id="sid" placeholder="学号" value="2502160608024"><br>
    <input type="text" id="name" placeholder="姓名" value="朱意婷"><br>
    <button onclick="doLogin()">登录</button>
    <div id="result"></div>
    
    <script>
        console.log('页面加载完成');
    </script>
</body>
</html>'''
