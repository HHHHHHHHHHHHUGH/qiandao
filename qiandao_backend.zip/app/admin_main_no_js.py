"""管理员主页面 - 无JS版本"""

ADMIN_MAIN_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员后台</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            min-height: 100vh;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: rgba(255, 255, 255, 0.95);
            padding: 24px;
        }
        .nav-link {
            display: block;
            padding: 12px 14px;
            border-radius: 12px;
            color: #666;
            font-size: 14px;
            margin-bottom: 4px;
            cursor: pointer;
        }
        .nav-link.active {
            background: rgba(102, 126, 234, 0.1);
            color: #667eea;
        }
        .main-content {
            margin-left: 260px;
            padding: 32px;
        }
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            display: inline-block;
            margin-right: 16px;
            margin-bottom: 16px;
        }
        .card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            margin-top: 16px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div style="font-size: 18px; font-weight: 700; margin-bottom: 24px;">签到管理</div>
        <div class="nav-link active">📊 数据概览</div>
        <div class="nav-link">📋 活动管理</div>
        <div class="nav-link">📝 签到记录</div>
        <div class="nav-link">👥 学生管理</div>
        <div class="nav-link">👤 管理员管理</div>
    </div>
    <div class="main-content">
        <h1>📊 数据概览</h1>
        <p style="color: rgba(255,255,255,0.7);">欢迎回来，查看系统运行状态</p>
        <div class="stat-card">
            <div style="font-size: 32px; font-weight: 700;">0</div>
            <div style="color: #888;">学生总数</div>
        </div>
        <div class="stat-card">
            <div style="font-size: 32px; font-weight: 700;">0</div>
            <div style="color: #888;">活动总数</div>
        </div>
        <div class="card">
            <h2>🎯 近期活动</h2>
            <button style="padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 10px;">+ 新建活动</button>
            <div style="text-align: center; color: #888; padding: 40px;">加载中...</div>
        </div>
    </div>
</body>
</html>
"""
