"""管理员主页面"""

ADMIN_MAIN_HTML = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员后台</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }
        .bg-decoration {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
        }
        .bg-decoration::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -25%;
            width: 800px;
            height: 800px;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            border-radius: 50%;
        }
        .bg-decoration::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -20%;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 70%);
            border-radius: 50%;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-right: 1px solid rgba(0,0,0,0.05);
            padding: 24px;
            z-index: 100;
            box-shadow: 2px 0 20px rgba(0,0,0,0.1);
        }
        .sidebar-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 32px;
            padding-bottom: 20px;
            border-bottom: 1px solid #f0f0f0;
        }
        .sidebar-brand .icon {
            width: 44px;
            height: 44px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        .sidebar-brand .text {
            color: #1a1a2e;
            font-size: 18px;
            font-weight: 700;
        }
        .nav-menu { list-style: none; }
        .nav-item { margin-bottom: 4px; }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 14px;
            border-radius: 12px;
            color: #666;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.25s;
            cursor: pointer;
        }
        .nav-link:hover, .nav-link.active {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            color: #667eea;
        }
        .nav-icon { font-size: 18px; }

        .user-panel {
            position: absolute;
            bottom: 24px;
            left: 24px;
            right: 24px;
            padding: 16px;
            background: #f8f9fa;
            border-radius: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        .user-info { flex: 1; }
        .user-name { color: #1a1a2e; font-weight: 600; font-size: 14px; }
        .user-role { color: #888; font-size: 12px; }
        .logout-btn {
            color: #e53935;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 8px;
            transition: background 0.25s;
        }
        .logout-btn:hover { background: #ffebee; }

        .main-content {
            margin-left: 260px;
            padding: 32px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        .page-header {
            margin-bottom: 32px;
        }
        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: white;
            margin-bottom: 4px;
        }
        .page-subtitle {
            color: rgba(255,255,255,0.7);
            font-size: 14px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 32px;
        }
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.2);
        }
        .stat-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 16px;
        }
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
        }
        .stat-label {
            color: #888;
            font-size: 14px;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 24px;
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .card-title {
            font-size: 18px;
            font-weight: 600;
            color: #1a1a2e;
        }
        .btn-primary {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            transition: all 0.25s;
        }
        .btn-primary:hover { transform: translateY(-1px); }
        .btn-danger { background: linear-gradient(135deg, #e53935 0%, #c62828 100%); }

        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 14px;
            text-align: left;
            border-bottom: 1px solid #f0f0f0;
        }
        th {
            color: #888;
            font-weight: 500;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        td {
            color: #333;
            font-size: 14px;
        }
        tr:hover { background: #fafafa; }
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge.active { background: #e8f5e9; color: #2e7d32; }
        .badge.inactive { background: #f5f5f5; color: #999; }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #aaa;
        }
        .empty-icon { font-size: 48px; margin-bottom: 12px; }
        .empty-text { font-size: 14px; }

        .page { display: none; }
        .page.active { display: block; }

        .search-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .search-bar input {
            flex: 1;
            padding: 12px 16px;
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            color: #333;
            font-size: 14px;
            outline: none;
            transition: border-color 0.25s;
        }
        .search-bar input:focus { border-color: #667eea; }

        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-overlay.active { display: flex; }
        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 32px;
            width: 90%;
            max-width: 480px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
        }
        .modal-header { margin-bottom: 20px; }
        .modal-title {
            font-size: 22px;
            font-weight: 600;
            color: #1a1a2e;
            margin-bottom: 4px;
        }
        .modal-desc {
            color: #888;
            font-size: 14px;
        }
        .modal-body { margin-bottom: 20px; }
        .modal-body input {
            width: 100%;
            padding: 14px;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            font-size: 14px;
            outline: none;
            margin-bottom: 12px;
            transition: border-color 0.25s;
        }
        .modal-body input:focus { border-color: #667eea; }
        .modal-footer {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="bg-decoration"></div>

    <div class="sidebar">
        <div class="sidebar-brand">
            <div class="icon">⚙️</div>
            <span class="text">签到管理</span>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item"><span class="nav-link active nav-dashboard"><span class="nav-icon">📊</span> 数据概览</span></li>
            <li class="nav-item"><span class="nav-link nav-activities"><span class="nav-icon">📋</span> 活动管理</span></li>
            <li class="nav-item"><span class="nav-link nav-records"><span class="nav-icon">📝</span> 签到记录</span></li>
            <li class="nav-item"><span class="nav-link nav-students"><span class="nav-icon">👥</span> 学生管理</span></li>
            <li class="nav-item"><span class="nav-link nav-admins"><span class="nav-icon">👤</span> 管理员管理</span></li>
        </ul>

        <div class="user-panel">
            <div class="user-avatar" id="adminAvatar">?</div>
            <div class="user-info">
                <div class="user-name" id="adminName">管理员</div>
                <div class="user-role" id="adminRole">超级管理员</div>
            </div>
            <div class="logout-btn" id="logoutBtn">退出</div>
        </div>
    </div>

    <div class="main-content">
        <div id="dashboardPage" class="page active">
            <div class="page-header">
                <h1 class="page-title">📊 数据概览</h1>
                <p class="page-subtitle">欢迎回来，查看系统运行状态</p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value" id="statStudents">0</div>
                    <div class="stat-label">学生总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📋</div>
                    <div class="stat-value" id="statActivities">0</div>
                    <div class="stat-label">活动总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">✅</div>
                    <div class="stat-value" id="statCheckins">0</div>
                    <div class="stat-label">签到总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🔄</div>
                    <div class="stat-value" id="statActive">0</div>
                    <div class="stat-label">进行中活动</div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">🎯 近期活动</h2>
                    <button class="btn-primary create-activity-btn">+ 新建活动</button>
                </div>
                <div id="recentActivities">
                    <div class="empty-state">
                        <div class="empty-icon">🔄</div>
                        <div class="empty-text">加载中...</div>
                    </div>
                </div>
            </div>
        </div>

        <div id="activitiesPage" class="page">
            <div class="page-header">
                <h1 class="page-title">📋 活动管理</h1>
                <p class="page-subtitle">管理所有签到活动</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">活动列表</h2>
                    <button class="btn-primary create-activity-btn">+ 新建活动</button>
                </div>
                <div class="search-bar">
                    <input type="text" id="activitySearch" placeholder="搜索活动名称...">
                </div>
                <div id="activitiesList">
                    <div class="empty-state">
                        <div class="empty-icon">🔄</div>
                        <div class="empty-text">加载中...</div>
                    </div>
                </div>
            </div>
        </div>

        <div id="recordsPage" class="page">
            <div class="page-header">
                <h1 class="page-title">📝 签到记录</h1>
                <p class="page-subtitle">查看所有签到记录</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">签到记录列表</h2>
                </div>
                <div class="search-bar">
                    <input type="text" id="recordSearch" placeholder="搜索学号或姓名...">
                </div>
                <div id="recordsList">
                    <div class="empty-state">
                        <div class="empty-icon">🔄</div>
                        <div class="empty-text">加载中...</div>
                    </div>
                </div>
            </div>
        </div>

        <div id="studentsPage" class="page">
            <div class="page-header">
                <h1 class="page-title">👥 学生管理</h1>
                <p class="page-subtitle">管理学生信息</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">学生列表</h2>
                    <button class="btn-primary import-students-btn">📥 导入学生</button>
                </div>
                <div class="search-bar">
                    <input type="text" id="studentSearch" placeholder="搜索学号、姓名或班级...">
                </div>
                <div id="studentsList">
                    <div class="empty-state">
                        <div class="empty-icon">🔄</div>
                        <div class="empty-text">加载中...</div>
                    </div>
                </div>
            </div>
        </div>

        <div id="adminsPage" class="page">
            <div class="page-header">
                <h1 class="page-title">👤 管理员管理</h1>
                <p class="page-subtitle">管理系统管理员</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">管理员列表</h2>
                    <button class="btn-primary create-admin-btn">+ 新建管理员</button>
                </div>
                <div id="adminsList">
                    <div class="empty-state">
                        <div class="empty-icon">🔄</div>
                        <div class="empty-text">加载中...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var currentToken = localStorage.getItem('admin_token');
        var currentUser = null;

        function init() {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', function() {
                    checkAuth();
                    bindEvents();
                });
            } else {
                checkAuth();
                bindEvents();
            }
        }

        function bindEvents() {
            document.querySelectorAll('.nav-link').forEach(function(el) {
                el.addEventListener('click', function() {
                    var page = el.classList[1].replace('nav-', '');
                    navigate(page);
                });
            });
            
            document.querySelectorAll('.create-activity-btn').forEach(function(btn) {
                btn.addEventListener('click', showCreateActivity);
            });
            
            document.querySelector('.import-students-btn').addEventListener('click', showImportStudents);
            document.querySelector('.create-admin-btn').addEventListener('click', showCreateAdmin);
            document.getElementById('logoutBtn').addEventListener('click', logout);
            
            document.getElementById('activitySearch').addEventListener('keyup', filterActivities);
            document.getElementById('recordSearch').addEventListener('keyup', filterRecords);
            document.getElementById('studentSearch').addEventListener('keyup', filterStudents);
        }

        function checkAuth() {
            if (!currentToken) {
                window.location.href = '/admin/login';
                return;
            }
            loadUserInfo();
            loadDashboard();
        }

        function loadUserInfo() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/admin/admins?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (data.items && data.items.length > 0) {
                        currentUser = data.items[0];
                        document.getElementById('adminAvatar').textContent = currentUser.real_name.charAt(0);
                        document.getElementById('adminName').textContent = currentUser.real_name;
                        document.getElementById('adminRole').textContent = currentUser.is_super ? '超级管理员' : '管理员';
                    }
                }
            };
            xhr.send();
        }

        function logout() {
            localStorage.removeItem('admin_token');
            window.location.href = '/admin/login';
        }

        function navigate(page) {
            document.querySelectorAll('.nav-link').forEach(function(a) { a.classList.remove('active'); });
            document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
            
            document.querySelector('.nav-' + page).classList.add('active');
            document.getElementById(page + 'Page').classList.add('active');
            
            if (page === 'dashboard') loadDashboard();
            if (page === 'activities') loadActivities();
            if (page === 'records') loadRecords();
            if (page === 'students') loadStudents();
            if (page === 'admins') loadAdmins();
        }

        function loadDashboard() {
            var activitiesXhr = new XMLHttpRequest();
            var recordsXhr = new XMLHttpRequest();
            var studentsXhr = new XMLHttpRequest();
            var completed = 0;

            activitiesXhr.open('GET', '/api/admin/activities?token=' + currentToken, true);
            activitiesXhr.onreadystatechange = function() {
                if (activitiesXhr.readyState === 4 && activitiesXhr.status === 200) {
                    completed++;
                    processData();
                }
            };
            activitiesXhr.send();

            recordsXhr.open('GET', '/api/admin/records?token=' + currentToken, true);
            recordsXhr.onreadystatechange = function() {
                if (recordsXhr.readyState === 4 && recordsXhr.status === 200) {
                    completed++;
                    processData();
                }
            };
            recordsXhr.send();

            studentsXhr.open('GET', '/api/admin/students?token=' + currentToken, true);
            studentsXhr.onreadystatechange = function() {
                if (studentsXhr.readyState === 4 && studentsXhr.status === 200) {
                    completed++;
                    processData();
                }
            };
            studentsXhr.send();

            function processData() {
                if (completed < 3) return;
                
                var activities = JSON.parse(activitiesXhr.responseText);
                var records = JSON.parse(recordsXhr.responseText);
                var students = JSON.parse(studentsXhr.responseText);
                
                document.getElementById('statStudents').textContent = students.total || 0;
                document.getElementById('statActivities').textContent = activities.total || 0;
                document.getElementById('statCheckins').textContent = records.total || 0;
                
                var activeCount = 0;
                if (activities.items) {
                    activeCount = activities.items.filter(function(a) { return a.is_active; }).length;
                }
                document.getElementById('statActive').textContent = activeCount;

                var recent = activities.items ? activities.items.slice(0, 5) : [];
                if (recent.length > 0) {
                    var html = '<table><thead><tr><th>活动名称</th><th>状态</th><th>签到数</th><th>操作</th></tr></thead><tbody>';
                    recent.forEach(function(a) {
                        html += '<tr><td>' + a.name + '</td><td><span class="badge ' + (a.is_active ? 'active' : 'inactive') + '">' + a.status + '</span></td><td>' + a.checkin_count + '</td><td>';
                        if (a.is_active) {
                            html += '<button class="btn-primary btn-danger" style="padding:5px 14px;font-size:12px" data-id="' + a.id + '" class="btn-end">结束</button>';
                        } else {
                            html += '<button class="btn-primary" style="padding:5px 14px;font-size:12px" data-id="' + a.id + '" class="btn-start">开始</button>';
                        }
                        html += '</td></tr>';
                    });
                    html += '</tbody></table>';
                    document.getElementById('recentActivities').innerHTML = html;
                    
                    document.querySelectorAll('.btn-start').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            startActivity(parseInt(this.getAttribute('data-id')));
                        });
                    });
                    document.querySelectorAll('.btn-end').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            endActivity(parseInt(this.getAttribute('data-id')));
                        });
                    });
                } else {
                    document.getElementById('recentActivities').innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">暂无活动</div></div>';
                }
            }
        }

        function loadActivities() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/admin/activities?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (data.items && data.items.length > 0) {
                        var html = '<table><thead><tr><th>活动名称</th><th>地点</th><th>状态</th><th>签到数</th><th>签到码</th><th>操作</th></tr></thead><tbody>';
                        data.items.forEach(function(a) {
                            html += '<tr><td><span class="activity-detail" data-id="' + a.id + '" style="color:#667eea;text-decoration:underline;cursor:pointer;">' + a.name + '</span></td><td>' + (a.location || '-') + '</td><td><span class="badge ' + (a.is_active ? 'active' : 'inactive') + '">' + a.status + '</span></td><td>' + a.checkin_count + '</td><td>' + (a.code || '<span style="color:#999;">未发布</span>') + '</td><td>';
                            html += '<button class="btn-primary" style="padding:5px 14px;font-size:12px;margin-right:6px" data-id="' + a.id + '" class="btn-detail">详情</button>';
                            if (a.is_active) {
                                if (!a.code) {
                                    html += '<button class="btn-primary" style="padding:5px 14px;font-size:12px;margin-right:6px" data-id="' + a.id + '" class="btn-publish">发布签到码</button>';
                                } else {
                                    html += '<button class="btn-primary" style="padding:5px 14px;font-size:12px;margin-right:6px" data-id="' + a.id + '" class="btn-refresh">刷新签到码</button>';
                                }
                                html += '<button class="btn-primary btn-danger" style="padding:5px 14px;font-size:12px" data-id="' + a.id + '" class="btn-end">结束</button>';
                            } else {
                                html += '<button class="btn-primary" style="padding:5px 14px;font-size:12px" data-id="' + a.id + '" class="btn-start">开始</button>';
                            }
                            html += '</td></tr>';
                        });
                        html += '</tbody></table>';
                        document.getElementById('activitiesList').innerHTML = html;
                        
                        document.querySelectorAll('.btn-detail, .activity-detail').forEach(function(btn) {
                            btn.addEventListener('click', function() {
                                showActivityDetail(parseInt(this.getAttribute('data-id')));
                            });
                        });
                        document.querySelectorAll('.btn-start').forEach(function(btn) {
                            btn.addEventListener('click', function() {
                                startActivity(parseInt(this.getAttribute('data-id')));
                            });
                        });
                        document.querySelectorAll('.btn-end').forEach(function(btn) {
                            btn.addEventListener('click', function() {
                                endActivity(parseInt(this.getAttribute('data-id')));
                            });
                        });
                        document.querySelectorAll('.btn-publish').forEach(function(btn) {
                            btn.addEventListener('click', function() {
                                publishCode(parseInt(this.getAttribute('data-id')));
                            });
                        });
                        document.querySelectorAll('.btn-refresh').forEach(function(btn) {
                            btn.addEventListener('click', function() {
                                refreshCode(parseInt(this.getAttribute('data-id')));
                            });
                        });
                    } else {
                        document.getElementById('activitiesList').innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">暂无活动</div></div>';
                    }
                }
            };
            xhr.send();
        }

        function loadRecords() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/admin/records?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (data.items && data.items.length > 0) {
                        var html = '<table><thead><tr><th>活动名称</th><th>学号</th><th>姓名</th><th>班级</th><th>签到时间</th></tr></thead><tbody>';
                        data.items.forEach(function(r) {
                            html += '<tr><td>' + r.activity_name + '</td><td>' + r.student_id + '</td><td>' + r.user_name + '</td><td>' + (r.class_name || '-') + '</td><td>' + r.checkin_time + '</td></tr>';
                        });
                        html += '</tbody></table>';
                        document.getElementById('recordsList').innerHTML = html;
                    } else {
                        document.getElementById('recordsList').innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">暂无签到记录</div></div>';
                    }
                }
            };
            xhr.send();
        }

        function loadStudents() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/admin/students?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (data.items && data.items.length > 0) {
                        var html = '<table><thead><tr><th>学号</th><th>姓名</th><th>班级</th><th>创建时间</th></tr></thead><tbody>';
                        data.items.forEach(function(s) {
                            html += '<tr><td>' + s.student_id + '</td><td>' + s.name + '</td><td>' + (s.class_name || '-') + '</td><td>' + s.created_at + '</td></tr>';
                        });
                        html += '</tbody></table>';
                        document.getElementById('studentsList').innerHTML = html;
                    } else {
                        document.getElementById('studentsList').innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">暂无学生</div></div>';
                    }
                }
            };
            xhr.send();
        }

        function loadAdmins() {
            if (!currentUser || !currentUser.is_super) {
                document.getElementById('adminsList').innerHTML = '<div class="empty-state"><div class="empty-icon">🔒</div><div class="empty-text">需要超级管理员权限</div></div>';
                return;
            }
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/admin/admins?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (data.items && data.items.length > 0) {
                        var html = '<table><thead><tr><th>用户名</th><th>姓名</th><th>角色</th><th>部门</th><th>操作</th></tr></thead><tbody>';
                        data.items.forEach(function(a) {
                            html += '<tr><td>' + a.username + '</td><td>' + a.real_name + '</td><td>' + (a.is_super ? '超级管理员' : a.role) + '</td><td>' + a.department + '</td><td>';
                            if (a.id !== currentUser.id) {
                                html += '<button class="btn-primary btn-danger" style="padding:5px 14px;font-size:12px" data-id="' + a.id + '" class="btn-delete-admin">删除</button>';
                            } else {
                                html += '-';
                            }
                            html += '</td></tr>';
                        });
                        html += '</tbody></table>';
                        document.getElementById('adminsList').innerHTML = html;
                        
                        document.querySelectorAll('.btn-delete-admin').forEach(function(btn) {
                            btn.addEventListener('click', function() {
                                deleteAdmin(parseInt(this.getAttribute('data-id')));
                            });
                        });
                    } else {
                        document.getElementById('adminsList').innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">暂无管理员</div></div>';
                    }
                }
            };
            xhr.send();
        }

        function showCreateActivity() {
            var modal = document.createElement('div');
            modal.className = 'modal-overlay active';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">+ 新建活动</h3>
                        <p class="modal-desc">创建一个新的签到活动</p>
                    </div>
                    <div class="modal-body">
                        <input type="text" placeholder="活动名称" id="actName" style="width:100%;padding:14px;border:2px solid #e9ecef;border-radius:10px;margin-bottom:12px;">
                        <input type="text" placeholder="活动描述（可选）" id="actDesc" style="width:100%;padding:14px;border:2px solid #e9ecef;border-radius:10px;margin-bottom:12px;">
                        <input type="text" placeholder="活动地点（可选）" id="actLocation" style="width:100%;padding:14px;border:2px solid #e9ecef;border-radius:10px;margin-bottom:12px;">
                        <input type="text" placeholder="所属部门（可选）" id="actDept" style="width:100%;padding:14px;border:2px solid #e9ecef;border-radius:10px;margin-bottom:12px;">
                        <input type="number" placeholder="签到时长（分钟）" id="actDuration" value="30" min="1" style="width:100%;padding:14px;border:2px solid #e9ecef;border-radius:10px;">
                    </div>
                    <div class="modal-footer" style="display:flex;gap:10px;margin-top:20px;">
                        <button style="flex:1;padding:12px;border:2px solid #e9ecef;border-radius:10px;background:white;color:#666;cursor:pointer;" class="modal-cancel">取消</button>
                        <button style="flex:2;padding:12px;border:none;border-radius:10px;background:linear-gradient(135deg,#667eea,#764ba2);color:white;cursor:pointer;" class="modal-create">创建</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            
            modal.querySelector('.modal-cancel').addEventListener('click', function() {
                modal.remove();
            });
            modal.querySelector('.modal-create').addEventListener('click', createActivity);
        }

        function createActivity() {
            var name = document.getElementById('actName').value.trim();
            var desc = document.getElementById('actDesc').value.trim();
            var location = document.getElementById('actLocation').value.trim();
            var dept = document.getElementById('actDept').value.trim();
            var duration = parseInt(document.getElementById('actDuration').value) || 30;

            if (!name) {
                alert('请输入活动名称');
                return;
            }

            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/activities?token=' + currentToken, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        alert('✅ 活动创建成功！');
                        document.querySelector('.modal-overlay').remove();
                        loadDashboard();
                        loadActivities();
                    } else {
                        alert('❌ 创建失败');
                    }
                }
            };
            xhr.send(JSON.stringify({
                name: name,
                description: desc,
                location: location,
                department: dept,
                checkin_duration: duration,
                code_refresh_interval: 0
            }));
        }

        function showActivityDetail(id) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/admin/activities/' + id + '?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    var modal = document.createElement('div');
                    modal.className = 'modal-overlay active';
                    modal.innerHTML = `
                        <div class="modal-content" style="max-width:700px;">
                            <div class="modal-header">
                                <h3 class="modal-title">📋 ${data.name}</h3>
                                <p class="modal-desc">活动详情</p>
                            </div>
                            <div class="modal-body">
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;margin-bottom:20px;">
                                    <div style="padding:15px;background:#f8f9fa;border-radius:10px;">
                                        <div style="font-size:12px;color:#888;margin-bottom:5px;">状态</div>
                                        <span class="badge ${data.is_active ? 'active' : 'inactive'}">${data.is_active ? '进行中' : '未开始'}</span>
                                    </div>
                                    <div style="padding:15px;background:#f8f9fa;border-radius:10px;">
                                        <div style="font-size:12px;color:#888;margin-bottom:5px;">签到数</div>
                                        <div style="font-size:24px;font-weight:bold;color:#667eea;">${data.checkin_count || 0}</div>
                                    </div>
                                    <div style="padding:15px;background:#f8f9fa;border-radius:10px;">
                                        <div style="font-size:12px;color:#888;margin-bottom:5px;">签到码</div>
                                        <div style="font-size:18px;font-family:monospace;">${data.code || '-'}</div>
                                    </div>
                                    <div style="padding:15px;background:#f8f9fa;border-radius:10px;">
                                        <div style="font-size:12px;color:#888;margin-bottom:5px;">签到时长</div>
                                        <div>${data.checkin_duration || 30}分钟</div>
                                    </div>
                                </div>
                                <div style="padding:15px;background:#f8f9fa;border-radius:10px;margin-bottom:20px;">
                                    <div style="font-size:12px;color:#888;margin-bottom:5px;">活动描述</div>
                                    <div>${data.description || '-'}</div>
                                </div>
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;margin-bottom:20px;">
                                    <div style="padding:15px;background:#f8f9fa;border-radius:10px;">
                                        <div style="font-size:12px;color:#888;margin-bottom:5px;">活动地点</div>
                                        <div>${data.location || '-'}</div>
                                    </div>
                                    <div style="padding:15px;background:#f8f9fa;border-radius:10px;">
                                        <div style="font-size:12px;color:#888;margin-bottom:5px;">所属部门</div>
                                        <div>${data.department || '-'}</div>
                                    </div>
                                </div>
                                <div style="padding:20px;border:2px dashed #ddd;border-radius:10px;margin-bottom:20px;">
                                    <div style="font-size:14px;font-weight:bold;margin-bottom:10px;">📥 导入学生名单</div>
                                    <div style="font-size:12px;color:#888;margin-bottom:10px;">支持格式：学号,姓名,班级（每行一个学生）</div>
                                    <textarea id="importStudents" rows="6" placeholder="2502160608024,朱意婷,计算机2班\n2502160608025,张三,计算机2班" style="width:100%;padding:12px;border:2px solid #e9ecef;border-radius:10px;font-family:monospace;font-size:12px;"></textarea>
                                    <button style="margin-top:10px;padding:12px 24px;border:none;border-radius:10px;background:linear-gradient(135deg,#667eea,#764ba2);color:white;cursor:pointer;" class="btn-import-students" data-id="${id}">导入名单</button>
                                </div>
                                <div style="padding:15px;background:#f8f9fa;border-radius:10px;">
                                    <div style="font-size:14px;font-weight:bold;margin-bottom:10px;">📝 签到记录</div>
                                    <div id="activityRecords">加载中...</div>
                                </div>
                            </div>
                            <div class="modal-footer" style="display:flex;gap:10px;margin-top:20px;">
                                <button style="flex:1;padding:12px;border:2px solid #e9ecef;border-radius:10px;background:white;color:#666;cursor:pointer;" class="modal-close">关闭</button>
                            </div>
                        </div>
                    `;
                    document.body.appendChild(modal);
                    
                    modal.querySelector('.btn-import-students').addEventListener('click', function() {
                        importStudentList(id);
                    });
                    modal.querySelector('.modal-close').addEventListener('click', function() {
                        modal.remove();
                    });
                    
                    loadActivityRecords(id);
                }
            };
            xhr.send();
        }

        function loadActivityRecords(activityId) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/admin/activities/' + activityId + '/records?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    var html = '';
                    if (data.items && data.items.length > 0) {
                        html = '<table style="width:100%;font-size:12px;"><thead><tr><th>学号</th><th>姓名</th><th>班级</th><th>签到时间</th></tr></thead><tbody>';
                        data.items.forEach(function(r) {
                            html += '<tr><td>' + r.student_id + '</td><td>' + r.user_name + '</td><td>' + (r.class_name || '-') + '</td><td>' + r.checkin_time + '</td></tr>';
                        });
                        html += '</tbody></table>';
                    } else {
                        html = '<div style="text-align:center;color:#888;padding:20px;">暂无签到记录</div>';
                    }
                    document.getElementById('activityRecords').innerHTML = html;
                }
            };
            xhr.send();
        }

        function importStudentList(activityId) {
            var content = document.getElementById('importStudents').value.trim();
            if (!content) {
                alert('请输入学生名单');
                return;
            }
            var students = [];
            var lines = content.split('\n');
            lines.forEach(function(line) {
                line = line.trim();
                if (line) {
                    var parts = line.split(',');
                    students.push({
                        student_id: parts[0] || '',
                        name: parts[1] || '',
                        class_name: parts[2] || ''
                    });
                }
            });
            if (students.length === 0) {
                alert('请输入有效的学生名单');
                return;
            }
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/activities/' + activityId + '/import-students?token=' + currentToken, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        alert('✅ 学生名单导入成功！');
                        loadActivityRecords(activityId);
                        document.getElementById('importStudents').value = '';
                    } else {
                        alert('❌ 导入失败');
                    }
                }
            };
            xhr.send(JSON.stringify({ students: students }));
        }

        function showEditActivity(id) {
            alert('编辑活动功能即将开放');
        }

        function showCreateAdmin() {
            if (!currentUser || !currentUser.is_super) {
                alert('需要超级管理员权限');
                return;
            }
            alert('新建管理员功能即将开放');
        }

        function showImportStudents() {
            alert('导入学生功能即将开放');
        }

        function startActivity(id) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/activities/' + id + '/start?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        alert('✅ 活动已开始！');
                        loadDashboard();
                        loadActivities();
                    } else {
                        alert('❌ 操作失败');
                    }
                }
            };
            xhr.send();
        }

        function endActivity(id) {
            if (!confirm('确定要结束这个活动吗？')) return;
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/activities/' + id + '/end?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        alert('✅ 活动已结束！');
                        loadDashboard();
                        loadActivities();
                    } else {
                        alert('❌ 操作失败');
                    }
                }
            };
            xhr.send();
        }

        function publishCode(id) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/activities/' + id + '/publish?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        var data = JSON.parse(xhr.responseText);
                        alert('✅ 签到码已发布！\n签到码：' + data.code);
                        loadDashboard();
                        loadActivities();
                    } else {
                        alert('❌ 发布失败');
                    }
                }
            };
            xhr.send();
        }

        function refreshCode(id) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/activities/' + id + '/refresh-code?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        var data = JSON.parse(xhr.responseText);
                        alert('✅ 签到码已刷新！\n新签到码：' + data.code);
                        loadDashboard();
                        loadActivities();
                    } else {
                        alert('❌ 刷新失败');
                    }
                }
            };
            xhr.send();
        }

        function deleteAdmin(id) {
            if (!confirm('确定要删除这个管理员吗？')) return;
            var xhr = new XMLHttpRequest();
            xhr.open('DELETE', '/api/admin/admins/' + id + '?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        alert('✅ 删除成功！');
                        loadAdmins();
                    } else {
                        alert('❌ 删除失败');
                    }
                }
            };
            xhr.send();
        }

        function filterActivities() {
            var keyword = document.getElementById('activitySearch').value.toLowerCase();
            document.querySelectorAll('#activitiesList table tbody tr').forEach(function(tr) {
                tr.style.display = tr.textContent.toLowerCase().includes(keyword) ? '' : 'none';
            });
        }

        function filterRecords() {
            var keyword = document.getElementById('recordSearch').value.toLowerCase();
            document.querySelectorAll('#recordsList table tbody tr').forEach(function(tr) {
                tr.style.display = tr.textContent.toLowerCase().includes(keyword) ? '' : 'none';
            });
        }

        function filterStudents() {
            var keyword = document.getElementById('studentSearch').value.toLowerCase();
            document.querySelectorAll('#studentsList table tbody tr').forEach(function(tr) {
                tr.style.display = tr.textContent.toLowerCase().includes(keyword) ? '' : 'none';
            });
        }

        init();
    </script>
</body>
</html>'''