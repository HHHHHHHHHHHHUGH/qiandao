"""学生首页 - 精简版"""

STUDENT_SIMPLE_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>讲座签到</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 15px;
        }
        .container { max-width: 400px; margin:0 auto; }
        
        .user-section {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px;
            background: rgba(255,255,255,0.95);
            border-radius: 16px;
            margin-bottom: 40px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: white;
            font-weight: 600;
        }
        .user-info { flex:1; }
        .user-name { font-size:16px; font-weight:600; color:#1a1a2e; margin-bottom:2px; }
        .user-id { font-size:12px; color:#888; }
        
        .checkin-section { text-align:center; margin-bottom:30px; }
        .checkin-btn {
            width: 160px;
            height: 160px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            font-size: 20px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 8px 30px rgba(240,147,251,0.4);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            margin:0 auto;
        }
        .checkin-btn:active { transform:scale(0.95); }
        .checkin-icon { font-size:36px; }
        .checkin-status { font-size:12px; color:rgba(255,255,255,0.8); margin-top:12px; }
        
        .activities-btn {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 12px;
            background: rgba(255,255,255,0.95);
            color: #333;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .modal-overlay {
            display:none;
            position:fixed;
            top:0; left:0;
            width:100%; height:100%;
            background:rgba(0,0,0,0.5);
            justify-content:center;
            align-items:center;
            z-index:1000;
        }
        .modal-overlay.active { display:flex; }
        .modal-content {
            background:white;
            width:90%; max-width:360px;
            border-radius:20px;
            padding:25px;
            position:relative;
        }
        .modal-close {
            position:absolute;
            top:15px; right:15px;
            width:32px; height:32px;
            border:none;
            border-radius:50%;
            background:#f0f0f0;
            font-size:18px;
            cursor:pointer;
        }
        .modal-title {
            font-size:20px; font-weight:700;
            color:#1a1a2e;
            text-align:center;
            margin-bottom:20px;
        }
        .checkin-options { display:flex; flex-direction:column; gap:12px; }
        .checkin-option {
            padding:16px;
            border:2px solid #e9ecef;
            border-radius:12px;
            cursor:pointer;
            display:flex;
            align-items:center;
            gap:12px;
        }
        .checkin-option.active {
            border-color:#667eea;
            background:rgba(102,126,234,0.1);
        }
        .option-icon {
            width:40px; height:40px;
            border-radius:10px;
            background:linear-gradient(135deg,#667eea,#764ba2);
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:20px;
            color:white;
        }
        .option-title { font-size:15px; font-weight:600; color:#1a1a2e; }
        .option-desc { font-size:12px; color:#888; }
        
        .code-input-area { display:none; margin-top:15px; }
        .code-input-area.active { display:block; }
        .code-input {
            width:100%;
            padding:14px;
            border:2px solid #e9ecef;
            border-radius:10px;
            font-size:16px;
            font-weight:600;
            text-align:center;
            letter-spacing:3px;
            outline:none;
            margin-bottom:12px;
        }
        .code-input:focus { border-color:#667eea; }
        .confirm-btn {
            width:100%;
            padding:14px;
            border:none;
            border-radius:10px;
            background:linear-gradient(135deg,#667eea,#764ba2);
            color:white;
            font-size:16px;
            font-weight:600;
            cursor:pointer;
        }
        
        .success-toast {
            display:none;
            position:fixed;
            top:50%; left:50%;
            transform:translate(-50%,-50%);
            background:rgba(0,0,0,0.8);
            color:white;
            padding:16px 32px;
            border-radius:10px;
            font-size:15px;
            z-index:2000;
        }
        .success-toast.active { display:block; }
        
        .activities-modal {
            display:none;
            position:fixed;
            top:0; left:0;
            width:100%; height:100%;
            background:rgba(0,0,0,0.5);
            justify-content:center;
            align-items:flex-end;
            z-index:1000;
        }
        .activities-modal.active { display:flex; }
        .activities-content {
            background:white;
            width:100%;
            border-radius:20px 20px 0 0;
            padding:25px;
            max-height:70vh;
            overflow-y:auto;
        }
        .activities-title {
            font-size:18px; font-weight:700;
            color:#1a1a2e;
            margin-bottom:15px;
        }
        .activity-item {
            padding:15px;
            background:#f8f9fa;
            border-radius:10px;
            margin-bottom:10px;
        }
        .activity-name { font-size:15px; font-weight:600; color:#1a1a2e; margin-bottom:4px; }
        .activity-meta { font-size:12px; color:#888; }
        .activity-status {
            display:inline-block;
            padding:3px 10px;
            border-radius:12px;
            font-size:11px;
            font-weight:600;
            margin-top:6px;
        }
        .activity-status.ongoing { background:#e8f5e9; color:#2e7d32; }
        .activity-status.upcoming { background:#e3f2fd; color:#1976d2; }
        .activity-status.completed { background:#f5f5f5; color:#999; }
        .empty-state { text-align:center; padding:30px; color:#999; font-size:14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="user-section">
            <div class="avatar" id="avatar">?</div>
            <div class="user-info">
                <div class="user-name" id="name">学生</div>
                <div class="user-id" id="sid">学号</div>
            </div>
        </div>
        
        <div class="checkin-section">
            <button class="checkin-btn" id="checkinBtn">
                <span class="checkin-icon">📝</span>
                <span>签到</span>
            </button>
            <div class="checkin-status" id="status">点击签到</div>
        </div>
        
        <button class="activities-btn" id="activitiesBtn">
            <span>📋</span>
            <span>我的活动</span>
        </button>
    </div>
    
    <div class="modal-overlay" id="checkinModal">
        <div class="modal-content">
            <button class="modal-close" id="closeBtn">×</button>
            <div class="modal-title">📝 签到</div>
            <div class="checkin-options">
                <div class="checkin-option" id="scanOpt">
                    <div class="option-icon">📷</div>
                    <div>
                        <div class="option-title">扫码签到</div>
                        <div class="option-desc">扫描二维码签到</div>
                    </div>
                </div>
                <div class="checkin-option" id="codeOpt">
                    <div class="option-icon">🔢</div>
                    <div>
                        <div class="option-title">输入签到码</div>
                        <div class="option-desc">手动输入签到码</div>
                    </div>
                </div>
            </div>
            <div class="code-input-area" id="codeArea">
                <input type="text" class="code-input" id="codeInput" placeholder="签到码">
                <button class="confirm-btn" id="confirmBtn">确认签到</button>
            </div>
        </div>
    </div>
    
    <div class="activities-modal" id="activitiesModal">
        <div class="activities-content">
            <div class="activities-title">我的活动</div>
            <div id="activityList">
                <div class="empty-state">暂无活动</div>
            </div>
        </div>
    </div>
    
    <div class="success-toast" id="toast">✅ 签到成功</div>
    
    <script>
        var token = localStorage.getItem('student_token');
        var user = null;
        
        function init() {
            if (!token) { window.location.href='/student'; return; }
            loadUser();
            loadActivities();
            bindEvents();
        }
        
        function loadUser() {
            fetch('/api/student/profile?token='+token)
            .then(r=>r.json())
            .then(d=>{
                user=d;
                document.getElementById('avatar').textContent=d.name.charAt(0);
                document.getElementById('name').textContent=d.name;
                document.getElementById('sid').textContent='学号: '+d.student_id;
            });
        }
        
        function loadActivities() {
            fetch('/api/student/activities?token='+token)
            .then(r=>r.json())
            .then(d=>{
                if(!d.items || d.items.length==0){
                    document.getElementById('activityList').innerHTML='<div class="empty-state">暂无活动</div>';
                    return;
                }
                var html='';
                d.items.forEach(a=>{
                    var cls=a.is_active?'ongoing':(new Date(a.checkin_start)>new Date()?'upcoming':'completed');
                    var txt=a.is_active?'进行中':(new Date(a.checkin_start)>new Date()?'即将开始':'已结束');
                    html+=`<div class="activity-item"><div class="activity-name">${a.name}</div><div class="activity-meta">${a.location||''}</div><span class="activity-status ${cls}">${txt}</span></div>`;
                });
                document.getElementById('activityList').innerHTML=html;
            });
        }
        
        function bindEvents() {
            document.getElementById('checkinBtn').onclick=showCheckin;
            document.getElementById('closeBtn').onclick=closeCheckin;
            document.getElementById('checkinModal').onclick=e=>{ if(e.target==this) closeCheckin(); };
            document.getElementById('scanOpt').onclick=()=>selectOpt('scan');
            document.getElementById('codeOpt').onclick=()=>selectOpt('code');
            document.getElementById('confirmBtn').onclick=submitCheckin;
            document.getElementById('codeInput').onkeyup=e=>{ if(e.key=='Enter') submitCheckin(); };
            document.getElementById('activitiesBtn').onclick=showActivities;
            document.getElementById('activitiesModal').onclick=e=>{ if(e.target==this) closeActivities(); };
        }
        
        function showCheckin() {
            document.getElementById('checkinModal').classList.add('active');
            document.getElementById('scanOpt').classList.remove('active');
            document.getElementById('codeOpt').classList.remove('active');
            document.getElementById('codeArea').classList.remove('active');
        }
        
        function closeCheckin() {
            document.getElementById('checkinModal').classList.remove('active');
        }
        
        function selectOpt(opt) {
            document.getElementById('scanOpt').classList.remove('active');
            document.getElementById('codeOpt').classList.remove('active');
            document.getElementById('codeArea').classList.remove('active');
            document.getElementById(opt+'Opt').classList.add('active');
            if(opt=='code'){
                document.getElementById('codeArea').classList.add('active');
                document.getElementById('codeInput').focus();
            }
        }
        
        function submitCheckin() {
            var code=document.getElementById('codeInput').value.trim();
            if(!code){ alert('请输入签到码'); return; }
            if(!user){ alert('请登录'); return; }
            
            fetch('/api/checkin',{
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body:JSON.stringify({activity_code:code, student_id:user.student_id, name:user.name})
            }).then(r=>r.json())
            .then(d=>{
                showToast('✅ 签到成功');
                closeCheckin();
                loadActivities();
            }).catch(e=>{
                alert('签到失败');
            });
        }
        
        function showActivities() {
            document.getElementById('activitiesModal').classList.add('active');
        }
        
        function closeActivities() {
            document.getElementById('activitiesModal').classList.remove('active');
        }
        
        function showToast(msg) {
            var t=document.getElementById('toast');
            t.textContent=msg;
            t.classList.add('active');
            setTimeout(()=>t.classList.remove('active'),2000);
        }
        
        init();
    </script>
</body>
</html>
"""
