"""管理员主页面 - 简化版"""

ADMIN_MAIN_HTML = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员后台</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: sans-serif; background: #f0f0f0; }
        .sidebar { width: 200px; height: 100vh; background: white; padding: 20px; }
        .nav-link { display: block; padding: 10px; margin-bottom: 5px; cursor: pointer; }
        .nav-link.active { background: #667eea; color: white; }
        .main-content { margin-left: 200px; padding: 20px; }
        .page { display: none; }
        .page.active { display: block; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="nav-link active nav-dashboard">数据概览</div>
        <div class="nav-link nav-activities">活动管理</div>
        <div class="nav-link nav-records">签到记录</div>
        <div class="nav-link nav-students">学生管理</div>
        <div class="nav-link nav-admins">管理员管理</div>
    </div>
    <div class="main-content">
        <div id="dashboardPage" class="page active">数据概览页面</div>
        <div id="activitiesPage" class="page">活动管理页面</div>
        <div id="recordsPage" class="page">签到记录页面</div>
        <div id="studentsPage" class="page">学生管理页面</div>
        <div id="adminsPage" class="page">管理员管理页面</div>
    </div>
    <script>
        function init() {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', bindEvents);
            } else {
                bindEvents();
            }
        }
        function bindEvents() {
            document.querySelectorAll('.nav-link').forEach(function(el) {
                el.addEventListener('click', function() {
                    var page = el.classList[1].replace('nav-', '');
                    navigate(page);
                });
            });
        }
        function navigate(page) {
            document.querySelectorAll('.nav-link').forEach(function(a) { a.classList.remove('active'); });
            document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
            document.querySelector('.nav-' + page).classList.add('active');
            document.getElementById(page + 'Page').classList.add('active');
        }
        init();
    </script>
</body>
</html>'''
