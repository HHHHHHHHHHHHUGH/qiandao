"""数据库 ORM 模型。"""
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Boolean, Float
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


class Admin(Base):
    """管理员模型。"""

    __tablename__ = "admins"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    password: Mapped[str] = mapped_column(String(256), nullable=False)
    real_name: Mapped[str] = mapped_column(String(64), nullable=False)
    role: Mapped[str] = mapped_column(String(32), default="admin")
    department: Mapped[str] = mapped_column(String(64), nullable=True)
    is_super: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.now)


class Activity(Base):
    """活动模型。"""

    __tablename__ = "activities"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    description: Mapped[str] = mapped_column(String(512), nullable=True)
    location: Mapped[str] = mapped_column(String(128), nullable=True)
    speaker: Mapped[str] = mapped_column(String(64), nullable=True)
    department: Mapped[str] = mapped_column(String(64), nullable=True)
    code: Mapped[str] = mapped_column(String(16), nullable=True, unique=True, index=True)
    qr_code: Mapped[str] = mapped_column(String(256), nullable=True)
    checkin_duration: Mapped[int] = mapped_column(Integer, default=30)
    checkin_start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    checkin_end: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    code_refresh_interval: Mapped[int] = mapped_column(Integer, default=60)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[int] = mapped_column(ForeignKey("admins.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.now)
    
    # 定位签到相关字段
    enable_location_check: Mapped[bool] = mapped_column(Boolean, default=False)
    location_latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    location_longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    location_radius: Mapped[int] = mapped_column(Integer, default=100)
    
    # 验证码相关字段
    enable_captcha: Mapped[bool] = mapped_column(Boolean, default=False)
    captcha_length: Mapped[int] = mapped_column(Integer, default=4)
    captcha_refresh_interval: Mapped[int] = mapped_column(Integer, default=60)

    checkins: Mapped[list["CheckinRecord"]] = relationship("CheckinRecord", back_populates="activity", cascade="all, delete-orphan")


class ActivityCaptcha(Base):
    """活动实时验证码模型。"""

    __tablename__ = "activity_captchas"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    activity_id: Mapped[int] = mapped_column(ForeignKey("activities.id"))
    captcha: Mapped[str] = mapped_column(String(16), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.now)


class CheckinRecord(Base):
    """签到记录模型。"""

    __tablename__ = "checkin_records"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_name: Mapped[str] = mapped_column(String(64), nullable=False)
    student_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    class_name: Mapped[str] = mapped_column(String(64), nullable=True)
    activity_id: Mapped[int] = mapped_column(ForeignKey("activities.id"))
    checkin_time: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.now)
    checkin_method: Mapped[str] = mapped_column(String(32), default="code")
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)

    activity: Mapped["Activity"] = relationship("Activity", back_populates="checkins")


class Student(Base):
    """学生模型（免注册，通过学号+姓名识别）。"""

    __tablename__ = "students"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(64), nullable=False)
    class_name: Mapped[str] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.now)


class ActivityEnrollment(Base):
    """活动报名人员模型（预报名名单）。"""

    __tablename__ = "activity_enrollments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    activity_id: Mapped[int] = mapped_column(ForeignKey("activities.id"))
    student_id: Mapped[str] = mapped_column(String(64), nullable=False)
    student_name: Mapped[str] = mapped_column(String(64), nullable=False)
    class_name: Mapped[str] = mapped_column(String(64), nullable=True)
    enrolled_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.now)
    is_checked_in: Mapped[bool] = mapped_column(Boolean, default=False)

    __table_args__ = (
        {"extend_existing": True},
    )
