"""测试页面 - 无脚本"""

TEST_HTML = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Test</title></head><body><h1>Hello World</h1><div id="test">Click me</div></body></html>'
