"""简化版管理员页面"""

from fastapi import APIRouter

router = APIRouter()

@router.get("/admin/simple")
async def simple_admin():
    return """
<!DOCTYPE html>
<html>
<head>
    <title>管理员后台</title>
    <meta charset="utf-8">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 30px; }
        .container { max-width: 1200px; margin: 0 auto; }
        .card { background: white; border-radius: 16px; padding: 24px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .btn-primary {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            transition: all 0.25s;
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 5px 20px rgba(102,126,234,0.4); }
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            display: none;
        }
        .modal-overlay.show { display: flex; }
        .modal-content {
            background: white;
            border-radius: 16px;
            padding: 30px;
            width: 90%;
            max-width: 450px;
            animation: fadeIn 0.2s;
        }
        @keyframes fadeIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        input {
            width: 100%;
            padding: 14px;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            margin-bottom: 12px;
            font-size: 14px;
            transition: border-color 0.2s;
        }
        input:focus { outline: none; border-color: #667eea; }
        .modal-footer { display: flex; gap: 10px; margin-top: 20px; }
        .modal-footer button { flex: 1; padding: 12px; border-radius: 10px; cursor: pointer; border: none; }
        .btn-cancel { background: #f5f5f5; color: #666; }
        .btn-create { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }
        .message { padding: 12px; border-radius: 8px; margin-bottom: 12px; display: none; }
        .message.success { background: #d4edda; color: #155724; }
        .message.error { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>📋 活动管理</h2>
                <a href="/create-activity" class="btn-primary" style="text-decoration:none;">+ 新建活动</a>
            </div>
            <div id="activitiesList">
                <div style="text-align:center; padding:40px; color:#999;">加载中...</div>
            </div>
        </div>
    </div>

    <div class="modal-overlay" id="createModal">
        <div class="modal-content">
            <h3 style="margin-bottom:8px;">新建活动</h3>
            <p style="color:#666; margin-bottom:20px;">创建一个新的签到活动</p>
            <div class="message" id="modalMessage"></div>
            <input type="text" id="actName" placeholder="活动名称">
            <input type="text" id="actDesc" placeholder="活动描述（可选）">
            <input type="text" id="actLocation" placeholder="活动地点（可选）">
            <input type="text" id="actDept" placeholder="所属部门（可选）">
            <input type="number" id="actDuration" placeholder="签到时长（分钟）" value="30" min="1">
            <div class="modal-footer">
                <button class="btn-cancel" onclick="closeModal()">取消</button>
                <button class="btn-create" onclick="createActivity()">创建</button>
            </div>
        </div>
    </div>

    <script>
        var token = localStorage.getItem('admin_token');
        
        function openCreateModal() {
            document.getElementById('createModal').classList.add('show');
            document.getElementById('modalMessage').style.display = 'none';
        }
        
        function closeModal() {
            document.getElementById('createModal').classList.remove('show');
        }
        
        function createActivity() {
            var name = document.getElementById('actName').value.trim();
            var desc = document.getElementById('actDesc').value.trim();
            var location = document.getElementById('actLocation').value.trim();
            var dept = document.getElementById('actDept').value.trim();
            var duration = document.getElementById('actDuration').value;
            
            if (!name) {
                showModalMessage('请输入活动名称', 'error');
                return;
            }
            
            var data = {
                name: name,
                description: desc,
                location: location,
                department: dept,
                checkin_duration: parseInt(duration) || 30
            };
            
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/activities?token=' + token);
            xhr.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    showModalMessage('创建成功！', 'success');
                    setTimeout(function() {
                        closeModal();
                        loadActivities();
                    }, 1500);
                } else {
                    showModalMessage('创建失败: ' + xhr.responseText, 'error');
                }
            };
            xhr.send(JSON.stringify(data));
        }
        
        function showModalMessage(msg, type) {
            var el = document.getElementById('modalMessage');
            el.textContent = msg;
            el.className = 'message ' + type;
            el.style.display = 'block';
        }
        
        function loadActivities() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/admin/activities?token=' + token);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    var activities = JSON.parse(xhr.responseText);
                    var html = '';
                    if (activities.length > 0) {
                        html = '<table style="width:100%;border-collapse:collapse;">';
                        html += '<tr style="border-bottom:2px solid #f0f0f0;"><th style="text-align:left;padding:12px;">活动名称</th><th style="text-align:left;padding:12px;">状态</th><th style="text-align:right;padding:12px;">操作</th></tr>';
                        activities.forEach(function(a) {
                            html += '<tr style="border-bottom:1px solid #f0f0f0;">';
                            html += '<td style="padding:12px;">' + a.name + '</td>';
                            html += '<td style="padding:12px;">' + (a.is_active ? '<span style="color:green;">进行中</span>' : '<span style="color:gray;">未开始</span>') + '</td>';
                            html += '<td style="padding:12px;text-align:right;">';
                            html += '<button style="padding:6px 12px;background:#667eea;color:white;border:none;border-radius:6px;cursor:pointer;margin-right:6px;" onclick="startActivity(' + a.id + ')">开始</button>';
                            html += '<button style="padding:6px 12px;background:#e53935;color:white;border:none;border-radius:6px;cursor:pointer;" onclick="endActivity(' + a.id + ')">结束</button>';
                            html += '</td></tr>';
                        });
                        html += '</table>';
                    } else {
                        html = '<div style="text-align:center; padding:40px; color:#999;">暂无活动</div>';
                    }
                    document.getElementById('activitiesList').innerHTML = html;
                }
            };
            xhr.send();
        }
        
        function startActivity(id) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/activities/' + id + '/start?token=' + token);
            xhr.onload = function() {
                if (xhr.status === 200) loadActivities();
            };
            xhr.send();
        }
        
        function endActivity(id) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/activities/' + id + '/end?token=' + token);
            xhr.onload = function() {
                if (xhr.status === 200) loadActivities();
            };
            xhr.send();
        }
        
        if (!token) {
            window.location.href = '/admin/login';
        } else {
            loadActivities();
        }
    </script>
</body>
</html>
"""
