"""管理员页面"""

ADMIN_HTML = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员登录</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .bg-decoration {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
        }
        .bg-decoration::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -25%;
            width: 800px;
            height: 800px;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            border-radius: 50%;
        }
        .bg-decoration::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -20%;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 70%);
            border-radius: 50%;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 52px 40px;
            box-shadow: 0 25px 80px rgba(102, 126, 234, 0.35);
            border: 1px solid rgba(255,255,255,0.3);
            width: 100%;
            max-width: 420px;
            position: relative;
            z-index: 10;
        }
        .login-logo {
            width: 90px;
            height: 90px;
            margin: 0 auto 28px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 42px;
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.5);
        }
        .login-title {
            text-align: center;
            font-size: 28px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 8px;
        }
        .login-desc {
            text-align: center;
            font-size: 14px;
            color: #888;
            margin-bottom: 36px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }
        .form-input {
            width: 100%;
            padding: 15px 18px;
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 14px;
            color: #333;
            font-size: 15px;
            outline: none;
            transition: all 0.3s;
        }
        .form-input:focus {
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .btn {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 14px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            transition: all 0.3s;
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.35);
            margin-top: 8px;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(102, 126, 234, 0.45);
        }
        .btn:active { transform: translateY(-1px); }
        .btn:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
        .alert {
            padding: 14px;
            border-radius: 10px;
            margin-top: 16px;
            text-align: center;
            display: none;
        }
        .alert.success {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }
        .alert.error {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }
        .back-link {
            display: block;
            text-align: center;
            padding: 20px;
            color: #667eea;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="bg-decoration"></div>
    <div class="login-card">
        <div class="login-logo">🔐</div>
        <h1 class="login-title">管理员登录</h1>
        <p class="login-desc">请输入管理员账号和密码</p>
        
        <div class="form-group">
            <label class="form-label">用户名</label>
            <input type="text" id="username" class="form-input" placeholder="请输入用户名">
        </div>
        <div class="form-group">
            <label class="form-label">密码</label>
            <input type="password" id="password" class="form-input" placeholder="请输入密码">
        </div>
        
        <button type="button" id="loginBtn" class="btn" onclick="doLogin()">🔐 登录</button>
        <div id="alertBox" class="alert"></div>
        <a href="/" class="back-link">← 返回首页</a>
    </div>

    <script>
        function doLogin() {
            var username = document.getElementById('username').value.trim();
            var password = document.getElementById('password').value.trim();
            var btn = document.getElementById('loginBtn');
            var alertBox = document.getElementById('alertBox');

            if (!username || !password) {
                showAlert('请填写用户名和密码', 'error');
                return;
            }

            btn.disabled = true;
            btn.innerHTML = '⏳ 登录中...';

            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/admin/login', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    btn.disabled = false;
                    btn.innerHTML = '🔐 登录';
                    
                    if (xhr.status === 200) {
                        var data = JSON.parse(xhr.responseText);
                        if (data.access_token) {
                            localStorage.setItem('admin_token', data.access_token);
                            showAlert('✅ 登录成功！', 'success');
                            setTimeout(function() {
                                window.location.href = '/admin/main';
                            }, 1000);
                        } else {
                            showAlert('登录失败', 'error');
                        }
                    } else {
                        try {
                            var errorData = JSON.parse(xhr.responseText);
                            showAlert(errorData.detail || '登录失败', 'error');
                        } catch (e) {
                            showAlert('登录失败', 'error');
                        }
                    }
                }
            };
            xhr.onerror = function() {
                btn.disabled = false;
                btn.innerHTML = '🔐 登录';
                showAlert('网络错误', 'error');
            };
            xhr.send(JSON.stringify({ username: username, password: password }));
        }

        function showAlert(message, type) {
            var alertBox = document.getElementById('alertBox');
            alertBox.textContent = message;
            alertBox.className = 'alert ' + type;
            alertBox.style.display = 'block';
        }

        document.getElementById('username').addEventListener('keydown', function(e) {
            if (e.key === 'Enter') doLogin();
        });
        document.getElementById('password').addEventListener('keydown', function(e) {
            if (e.key === 'Enter') doLogin();
        });
    </script>
</body>
</html>'''
