"""管理员主页面 - 修复版"""

ADMIN_MAIN_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员后台</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-right: 1px solid rgba(0,0,0,0.05);
            padding: 24px;
            z-index: 100;
            box-shadow: 2px 0 20px rgba(0,0,0,0.1);
        }
        .sidebar-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 32px;
            padding-bottom: 20px;
            border-bottom: 1px solid #f0f0f0;
        }
        .sidebar-brand .icon {
            width: 44px;
            height: 44px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        .sidebar-brand .text {
            color: #1a1a2e;
            font-size: 18px;
            font-weight: 700;
        }
        .nav-menu { list-style: none; }
        .nav-item { margin-bottom: 4px; }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 14px;
            border-radius: 12px;
            color: #666;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.25s;
            cursor: pointer;
        }
        .nav-link:hover, .nav-link.active {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            color: #667eea;
        }
        .nav-icon { font-size: 18px; }
        .main-content {
            margin-left: 260px;
            padding: 32px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        .page-header { margin-bottom: 32px; }
        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: white;
            margin-bottom: 4px;
        }
        .page-subtitle {
            color: rgba(255,255,255,0.7);
            font-size: 14px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 32px;
        }
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.2);
        }
        .stat-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 16px;
        }
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
        }
        .stat-label { color: #888; font-size: 14px; }
        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 24px;
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .card-title {
            font-size: 18px;
            font-weight: 600;
            color: #1a1a2e;
        }
        .btn-primary {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            transition: all 0.25s;
        }
        .btn-primary:hover { transform: translateY(-1px); }
        .page { display: none; }
        .page.active { display: block; }
    </style>
</head>
<body>
    <div class=\"sidebar\">
        <div class=\"sidebar-brand\">
            <div class=\"icon\">⚙️</div>
            <span class=\"text\">签到管理</span>
        </div>
        <ul class=\"nav-menu\">
            <li class=\"nav-item\"><span class=\"nav-link active nav-dashboard\"><span class=\"nav-icon\">📊</span> 数据概览</span></li>
            <li class=\"nav-item\"><span class=\"nav-link nav-activities\"><span class=\"nav-icon\">📋</span> 活动管理</span></li>
            <li class=\"nav-item\"><span class=\"nav-link nav-records\"><span class=\"nav-icon\">📝</span> 签到记录</span></li>
            <li class=\"nav-item\"><span class=\"nav-link nav-students\"><span class=\"nav-icon\">👥</span> 学生管理</span></li>
            <li class=\"nav-item\"><span class=\"nav-link nav-admins\"><span class=\"nav-icon\">👤</span> 管理员管理</span></li>
        </ul>
    </div>
    <div class=\"main-content\">
        <div id=\"dashboardPage\" class=\"page active\">
            <div class=\"page-header\">
                <h1 class=\"page-title\">📊 数据概览</h1>
                <p class=\"page-subtitle\">欢迎回来，查看系统运行状态</p>
            </div>
            <div class=\"stats-grid\">
                <div class=\"stat-card\">
                    <div class=\"stat-icon\">👥</div>
                    <div class=\"stat-value\" id=\"statStudents\">0</div>
                    <div class=\"stat-label\">学生总数</div>
                </div>
                <div class=\"stat-card\">
                    <div class=\"stat-icon\">📋</div>
                    <div class=\"stat-value\" id=\"statActivities\">0</div>
                    <div class=\"stat-label\">活动总数</div>
                </div>
                <div class=\"stat-card\">
                    <div class=\"stat-icon\">✅</div>
                    <div class=\"stat-value\" id=\"statCheckins\">0</div>
                    <div class=\"stat-label\">签到总数</div>
                </div>
                <div class=\"stat-card\">
                    <div class=\"stat-icon\">🔄</div>
                    <div class=\"stat-value\" id=\"statActive\">0</div>
                    <div class=\"stat-label\">进行中活动</div>
                </div>
            </div>
            <div class=\"card\">
                <div class=\"card-header\">
                    <h2 class=\"card-title\">🎯 近期活动</h2>
                    <button class=\"btn-primary create-activity-btn\">+ 新建活动</button>
                </div>
                <div id=\"recentActivities\">
                    <div style=\"text-align:center;color:#888;padding:40px;\">加载中...</div>
                </div>
            </div>
        </div>
        <div id=\"activitiesPage\" class=\"page\">
            <div class=\"page-header\">
                <h1 class=\"page-title\">📋 活动管理</h1>
                <p class=\"page-subtitle\">管理所有签到活动</p>
            </div>
            <div class=\"card\">活动管理内容</div>
        </div>
        <div id=\"recordsPage\" class=\"page\">
            <div class=\"page-header\">
                <h1 class=\"page-title\">📝 签到记录</h1>
                <p class=\"page-subtitle\">查看所有签到记录</p>
            </div>
            <div class=\"card\">签到记录内容</div>
        </div>
        <div id=\"studentsPage\" class=\"page\">
            <div class=\"page-header\">
                <h1 class=\"page-title\">👥 学生管理</h1>
                <p class=\"page-subtitle\">管理学生信息</p>
            </div>
            <div class=\"card\">学生管理内容</div>
        </div>
        <div id=\"adminsPage\" class=\"page\">
            <div class=\"page-header\">
                <h1 class=\"page-title\">👤 管理员管理</h1>
                <p class=\"page-subtitle\">管理系统管理员</p>
            </div>
            <div class=\"card\">管理员管理内容</div>
        </div>
    </div>
    <script>
        var currentToken = localStorage.getItem('admin_token');
        function init() {
            bindEvents();
        }
        function bindEvents() {
            document.querySelectorAll('.nav-link').forEach(function(el) {
                el.addEventListener('click', function() {
                    var cls = el.className.split(' ');
                    var navClass = cls.find(function(c) { return c.startsWith('nav-'); });
                    var page = navClass.replace('nav-', '');
                    navigate(page);
                });
            });
        }
        function navigate(page) {
            document.querySelectorAll('.nav-link').forEach(function(a) { a.classList.remove('active'); });
            document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
            document.querySelector('.nav-' + page).classList.add('active');
            document.getElementById(page + 'Page').classList.add('active');
        }
        init();
    <\/script>
</body>
</html>
"""
