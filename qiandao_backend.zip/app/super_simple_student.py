"""超级简单的学生页面"""

SUPER_SIMPLE_STUDENT_HTML = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>学生主页</title>
    <script>
        async function checkLogin() {
            try {
                const response = await fetch('/api/student/me', { credentials: 'include' });
                if (response.ok) {
                    const data = await response.json();
                    document.getElementById('content').innerHTML =
                        '<h1>✅ 欢迎 ' + data.name + '!</h1>' +
                        '<p>班级: ' + data.class_name + '</p>' +
                        '<p>学号: ' + data.student_id + '</p>' +
                        '<button onclick="logout()">退出登录</button>';
                } else {
                    document.getElementById('content').innerHTML =
                        '<h1>❌ 未登录</h1>' +
                        '<a href="/simple-test">去登录</a>';
                }
            } catch (error) {
                document.getElementById('content').innerHTML =
                    '<h1>❌ 错误</h1>' +
                    '<p>' + error.message + '</p>';
            }
        }
        
        async function logout() {
            try {
                await fetch('/api/student/logout', { method: 'POST', credentials: 'include' });
            } catch (e) {}
            window.location.href = '/simple-test';
        }
    </script>
</head>
<body>
    <div id="content">加载中...</div>
    <script>checkLogin();</script>
</body>
</html>'''
