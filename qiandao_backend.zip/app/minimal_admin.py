"""极简版管理员页面"""

from fastapi import APIRouter, Form
from fastapi.responses import HTMLResponse
from sqlalchemy import select
from .database import get_db
from .models import Activity
from .config import generate_checkin_code

router = APIRouter()

@router.get("/minimal")
async def minimal_admin():
    db = next(get_db())
    activities = db.execute(select(Activity)).scalars().all()
    
    activities_html = "<table border='1' width='100%'><tr><th>活动名称</th><th>状态</th><th>签到码</th><th>操作</th></tr>"
    for a in activities:
        status = "进行中" if a.is_active else "未开始"
        code = a.code or "(未发布)"
        actions = ""
        if a.is_active:
            if a.code:
                actions += f"<a href='/minimal/refresh/{a.id}'>刷新签到码</a> | "
            else:
                actions += f"<a href='/minimal/publish/{a.id}'>发布签到码</a> | "
            actions += f"<a href='/minimal/end/{a.id}'>结束</a>"
        else:
            actions += f"<a href='/minimal/start/{a.id}'>开始</a>"
        activities_html += f"<tr><td>{a.name}</td><td>{status}</td><td>{code}</td><td>{actions}</td></tr>"
    activities_html += "</table>"
    
    return HTMLResponse(content=f"""
<html>
<head>
    <meta charset='utf-8'>
    <title>极简管理</title>
</head>
<body style='padding: 40px;'>
    <h1>活动管理</h1>
    <p><a href='/minimal/create' style='background: #667eea; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>+ 新建活动</a></p>
    <br>
    {activities_html}
</body>
</html>
""")

@router.get("/minimal/create")
async def create_page():
    return HTMLResponse(content="""
<html>
<head>
    <meta charset='utf-8'>
    <title>创建活动</title>
</head>
<body style='padding: 40px;'>
    <h1>创建活动</h1>
    <form method='POST'>
        <p>活动名称: <input type='text' name='name' required></p>
        <p>活动描述: <input type='text' name='description'></p>
        <p>活动地点: <input type='text' name='location'></p>
        <p>所属部门: <input type='text' name='department'></p>
        <p>签到时长(分钟): <input type='number' name='duration' value='30' min='1'></p>
        <p><button type='submit'>创建活动</button></p>
    </form>
    <p><a href='/minimal'>返回</a></p>
</body>
</html>
""")

@router.post("/minimal/create")
async def create_activity(name: str = Form(...), description: str = Form(""),
                          location: str = Form(""), department: str = Form(""),
                          duration: int = Form(30)):
    db = next(get_db())
    activity = Activity(
        name=name,
        description=description,
        location=location,
        department=department,
        code=None,
        checkin_duration=duration,
        created_by=1
    )
    db.add(activity)
    db.commit()
    
    return HTMLResponse(content=f"""
<html>
<head>
    <meta charset='utf-8'>
    <title>创建成功</title>
</head>
<body style='padding: 40px;'>
    <h1>创建成功！</h1>
    <p>活动名称: {name}</p>
    <p>签到码: (创建活动后可在进行发布</p>
    <p><a href='/minimal'>返回活动列表</a></p>
</body>
</html>
""")

@router.get("/minimal/start/{activity_id}")
async def start_activity(activity_id: int):
    db = next(get_db())
    activity = db.get(Activity, activity_id)
    if activity:
        activity.is_active = True
        db.commit()
    return HTMLResponse(content=f"""
<html>
<head>
    <meta charset='utf-8'>
</head>
<body>
    <script>window.location.href='/minimal';</script>
</body>
</html>
""")

@router.get("/minimal/end/{activity_id}")
async def end_activity(activity_id: int):
    db = next(get_db())
    activity = db.get(Activity, activity_id)
    if activity:
        activity.is_active = False
        db.commit()
    return HTMLResponse(content=f"""
<html>
<head>
    <meta charset='utf-8'>
</head>
<body>
    <script>window.location.href='/minimal';</script>
</body>
</html>
""")

@router.get("/minimal/publish/{activity_id}")
async def publish_code(activity_id: int):
    db = next(get_db())
    activity = db.get(Activity, activity_id)
    if activity:
        code = generate_checkin_code()
        activity.code = code
        db.commit()
    return HTMLResponse(content=f"""
<html>
<head>
    <meta charset='utf-8'>
</head>
<body>
    <script>window.location.href='/minimal';</script>
</body>
</html>
""")

@router.get("/minimal/refresh/{activity_id}")
async def refresh_code(activity_id: int):
    db = next(get_db())
    activity = db.get(Activity, activity_id)
    if activity:
        code = generate_checkin_code()
        activity.code = code
        db.commit()
    return HTMLResponse(content=f"""
<html>
<head>
    <meta charset='utf-8'>
</head>
<body>
    <script>window.location.href='/minimal';</script>
</body>
</html>
""")
