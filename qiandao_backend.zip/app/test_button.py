"""测试按钮功能"""

from fastapi import APIRouter

router = APIRouter()

@router.get("/test-button")
async def test_button():
    return """
<!DOCTYPE html>
<html>
<head>
    <title>测试按钮</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 50px; }
        button {
            padding: 15px 30px;
            font-size: 18px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
        }
        button:hover { transform: translateY(-2px); }
    </style>
</head>
<body>
    <h1>测试按钮点击</h1>
    <button onclick="testClick()">点击测试</button>
    <p id="result"></p>
    <script>
        function testClick() {
            alert('按钮点击成功！');
            document.getElementById('result').textContent = '按钮点击成功！';
        }
    </script>
</body>
</html>
"""
