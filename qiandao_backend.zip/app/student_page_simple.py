"""学生签到页面 - 不使用表单版本"""

STUDENT_HTML_SIMPLE = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>学生签到系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #f0f2f5;
            min-height: 100vh;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 24px;
            text-align: center;
            box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
        }
        .header h1 { font-size: 22px; margin-bottom: 4px; }
        .header p { font-size: 13px; opacity: 0.9; }

        .user-info {
            background: white;
            padding: 16px 24px;
            margin: 16px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .user-info .left { display: flex; align-items: center; gap: 12px; }
        .user-info .avatar {
            width: 44px; height: 44px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 18px;
        }
        .user-info .name { font-weight: 600; color: #333; }
        .user-info .class { font-size: 13px; color: #999; }
        .user-info .logout {
            color: #f44336;
            font-size: 13px;
            cursor: pointer;
            padding: 8px 16px;
            border-radius: 8px;
            transition: background 0.3s;
        }
        .user-info .logout:hover { background: #ffebee; }

        .tabs {
            display: flex;
            background: white;
            padding: 8px;
            margin: 16px;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }
        .tab {
            flex: 1;
            padding: 12px 16px;
            text-align: center;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            color: #666;
        }
        .tab.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .container { max-width: 500px; margin: 0 auto; padding: 0 16px; }
        .card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }
        .card-title {
            font-size: 17px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group { margin-bottom: 16px; }
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 14px;
        }
        input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 15px;
            outline: none;
            transition: all 0.3s;
            background: #fafafa;
        }
        input:focus {
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .btn {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4); }
        .btn:active { transform: translateY(0); }

        .result {
            padding: 16px;
            border-radius: 12px;
            margin-top: 16px;
            text-align: center;
            display: none;
            animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .result-success { background: #e8f5e9; color: #2e7d32; border: 1px solid #c8e6c9; }
        .result-error { background: #ffebee; color: #c62828; border: 1px solid #ffcdd2; }

        .activity-item {
            padding: 16px;
            border-radius: 12px;
            background: #f8f9fa;
            margin-bottom: 12px;
            border-left: 4px solid #667eea;
        }
        .activity-item h3 { font-size: 15px; color: #333; margin-bottom: 4px; }
        .activity-item p { font-size: 13px; color: #666; }

        .record-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px;
            border-bottom: 1px solid #eee;
        }
        .record-item:last-child { border-bottom: none; }
        .record-info h4 { font-size: 15px; color: #333; }
        .record-info p { font-size: 12px; color: #999; margin-top: 2px; }
        .record-time { font-size: 13px; color: #667eea; }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }
        .empty-state .icon { font-size: 48px; margin-bottom: 12px; opacity: 0.5; }
        .empty-state p { font-size: 14px; }

        .back-link {
            display: block;
            text-align: center;
            padding: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
        }

        .page { display: none; }
        .page.active { display: block; }

        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 0 16px;
        }

        .login-card {
            background: white;
            border-radius: 20px;
            padding: 40px 32px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
        }

        .login-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
        }

        .login-title {
            text-align: center;
            font-size: 24px;
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }

        .login-desc {
            text-align: center;
            font-size: 14px;
            color: #999;
            margin-bottom: 32px;
        }
    </style>
</head>
<body>
    <div id="loginPage">
        <div class="login-container">
            <div class="login-card">
                <div class="login-logo">📱</div>
                <div class="login-title">学生登录</div>
                <div class="login-desc">请输入学号和姓名进行验证</div>

                <div class="form-group">
                    <label>学号</label>
                    <input type="text" id="loginStudentId" placeholder="请输入学号">
                </div>
                <div class="form-group">
                    <label>姓名</label>
                    <input type="text" id="loginName" placeholder="请输入姓名">
                </div>
                <button type="button" class="btn" id="loginBtn">
                    <span>🔐</span> 登录
                </button>
                <div id="loginResult" class="result"></div>
            </div>
            <a href="/" class="back-link">← 返回首页</a>
        </div>
    </div>

    <div id="mainPage" style="display: none;">
        <div class="header">
            <h1>📱 学生签到</h1>
            <p>便捷高效的校园活动签到</p>
        </div>

        <div class="container">
            <div class="user-info">
                <div class="left">
                    <div class="avatar" id="avatar">?</div>
                    <div>
                        <div class="name" id="userName">姓名</div>
                        <div class="class" id="userClass">班级</div>
                    </div>
                </div>
                <div class="logout" id="logoutBtn">退出登录</div>
            </div>

            <div class="tabs">
                <div class="tab active" data-page="checkin">🔐 签到</div>
                <div class="tab" data-page="activities">📋 活动</div>
                <div class="tab" data-page="records">📊 记录</div>
            </div>

            <div id="checkinPage" class="page active">
                <div class="card">
                    <div class="card-title">📝 签到</div>
                    <div class="form-group">
                        <label>签到码</label>
                        <input type="text" id="code" placeholder="请输入6位签到码" maxlength="6">
                    </div>
                    <button type="button" class="btn" id="checkinBtn">
                        <span>✅</span> 立即签到
                    </button>
                    <div id="checkinResult" class="result"></div>
                </div>
            </div>

            <div id="activitiesPage" class="page">
                <div class="card">
                    <div class="card-title">🎯 当前活动</div>
                    <div id="activitiesList">
                        <div class="empty-state">
                            <div class="icon">🔄</div>
                            <p>加载中...</p>
                        </div>
                    </div>
                </div>
            </div>

            <div id="recordsPage" class="page">
                <div class="card">
                    <div class="card-title">📈 我的签到记录</div>
                    <div id="recordsList">
                        <div class="empty-state">
                            <div class="icon">🔄</div>
                            <p>加载中...</p>
                        </div>
                    </div>
                </div>
            </div>

            <a href="/" class="back-link">← 返回首页</a>
        </div>
    </div>

    <script>
        let currentUser = null;

        async function checkLogin() {
            try {
                const response = await fetch("/api/student/me", { credentials: "include" });
                if (response.ok) {
                    const data = await response.json();
                    currentUser = data;
                    showMainPage(data);
                } else {
                    showLoginPage();
                }
            } catch (error) {
                showLoginPage();
            }
        }

        function showLoginPage() {
            document.getElementById("loginPage").style.display = "block";
            document.getElementById("mainPage").style.display = "none";
        }

        function showMainPage(user) {
            document.getElementById("loginPage").style.display = "none";
            document.getElementById("mainPage").style.display = "block";

            document.getElementById("avatar").textContent = user.name.charAt(0);
            document.getElementById("userName").textContent = user.name;
            document.getElementById("userClass").textContent = user.class_name || '未分配班级';

            loadActivities();
            loadRecords();
        }

        document.getElementById("loginBtn").addEventListener("click", async function() {
            const studentId = document.getElementById("loginStudentId").value.trim();
            const name = document.getElementById("loginName").value.trim();

            if (!studentId || !name) {
                showLoginResult("请填写学号和姓名", false);
                return;
            }

            if (!/^[0-9]+$/.test(studentId)) {
                showLoginResult("学号只能包含数字", false);
                return;
            }

            if (!/^[\u4e00-\u9fa5]+$/.test(name)) {
                showLoginResult("姓名只能使用中文", false);
                return;
            }

            try {
                const response = await fetch("/api/student/login", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ student_id: studentId, name: name }),
                    credentials: "include"
                });
                const data = await response.json();
                if (response.ok) {
                    showLoginResult("登录成功！", true);
                    setTimeout(() => {
                        currentUser = data;
                        showMainPage(data);
                    }, 1000);
                } else {
                    showLoginResult(data.detail || "登录失败", false);
                }
            } catch (error) {
                showLoginResult("网络错误，请重试", false);
            }
        });

        function showLoginResult(message, isSuccess) {
            const result = document.getElementById("loginResult");
            result.style.display = "block";
            result.className = "result " + (isSuccess ? "result-success" : "result-error");
            result.textContent = message;
        }

        document.getElementById("logoutBtn").addEventListener("click", async function() {
            try {
                await fetch("/api/student/logout", { method: "POST", credentials: "include" });
            } catch (e) {}
            currentUser = null;
            showLoginPage();
        });

        document.querySelectorAll(".tab").forEach(function(tab) {
            tab.addEventListener("click", function() {
                document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
                document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
                this.classList.add("active");
                const pageId = this.getAttribute("data-page");
                document.getElementById(pageId + "Page").classList.add("active");

                if (pageId === "activities") loadActivities();
                if (pageId === "records") loadRecords();
            });
        });

        async function loadActivities() {
            const list = document.getElementById("activitiesList");
            list.innerHTML = '<div class="empty-state"><div class="icon">🔄</div><p>加载中...</p></div>';
            try {
                const response = await fetch("/api/student/activities", { credentials: "include" });
                if (!response.ok) {
                    throw new Error("未登录");
                }
                const data = await response.json();
                if (data.items && data.items.length > 0) {
                    list.innerHTML = data.items.map(a => '<div class="activity-item"><h3>' + a.name + '</h3><p>📍 ' + (a.location || '未设置地点') + '</p></div>').join('');
                } else {
                    list.innerHTML = '<div class="empty-state"><div class="icon">🎭</div><p>暂无进行中的活动</p></div>';
                }
            } catch (error) {
                list.innerHTML = '<div class="empty-state"><div class="icon">❌</div><p>加载失败，请重试</p></div>';
            }
        }

        async function loadRecords() {
            const list = document.getElementById("recordsList");
            list.innerHTML = '<div class="empty-state"><div class="icon">🔄</div><p>加载中...</p></div>';
            try {
                const response = await fetch("/api/student/records", { credentials: "include" });
                if (!response.ok) {
                    throw new Error("未登录");
                }
                const data = await response.json();
                if (data && data.length > 0) {
                    list.innerHTML = data.map(r => '<div class="record-item"><div class="record-info"><h4>' + r.activity_name + '</h4></div></div>').join('');
                } else {
                    list.innerHTML = '<div class="empty-state"><div class="icon">📭</div><p>暂无签到记录</p></div>';
                }
            } catch (error) {
                list.innerHTML = '<div class="empty-state"><div class="icon">❌</div><p>加载失败，请重试</p></div>';
            }
        }

        document.getElementById("checkinBtn").addEventListener("click", async function() {
            const code = document.getElementById("code").value.trim();
            if (!code) {
                showCheckinResult("请输入签到码", false);
                return;
            }

            if (code.length !== 6) {
                showCheckinResult("签到码必须是6位数字", false);
                return;
            }

            try {
                const response = await fetch("/api/student/checkin", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ code: code }),
                    credentials: "include"
                });
                const data = await response.json();
                if (response.ok) {
                    showCheckinResult("✅ 签到成功！\n时间：" + data.checkin_time, true);
                    document.getElementById("code").value = "";
                    loadRecords();
                } else {
                    showCheckinResult(data.detail || "签到失败", false);
                }
            } catch (error) {
                showCheckinResult("网络错误，请重试", false);
            }
        });

        function showCheckinResult(message, isSuccess) {
            const result = document.getElementById("checkinResult");
            result.style.display = "block";
            result.className = "result " + (isSuccess ? "result-success" : "result-error");
            result.innerHTML = message.replace(/\n/g, "<br>");
        }

        checkLogin();
    </script>
</body>
</html>'''
