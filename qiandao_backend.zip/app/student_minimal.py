"""学生首页 - 优化版（带定位和验证码）"""

STUDENT_MINIMAL_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>讲座签到</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;600;700&display=swap');

* { margin: 0; padding: 0; box-sizing: border-box; }

:root {
    --primary: #6366f1;
    --primary-dark: #4f46e5;
    --success: #10b981;
    --success-light: #d1fae5;
    --danger: #ef4444;
    --danger-light: #fee2e2;
    --warning: #f59e0b;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-800: #1f2937;
    --gray-900: #111827;
    --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
    --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
    --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
    --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
    --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
    --radius: 16px;
    --radius-lg: 24px;
    --radius-xl: 32px;
}

body {
    font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    padding: 20px;
    padding-bottom: 100px;
}

.container {
    max-width: 420px;
    margin: 0 auto;
}

.user-card {
    background: white;
    border-radius: var(--radius-lg);
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--shadow-xl);
    display: flex;
    align-items: center;
    gap: 16px;
}

.avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 700;
    color: white;
    box-shadow: var(--shadow-md);
}

.user-info { flex: 1; }

.user-name {
    font-size: 20px;
    font-weight: 700;
    color: var(--gray-900);
    margin-bottom: 4px;
}

.user-id {
    font-size: 14px;
    color: var(--gray-500);
}

.logout-btn {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    border: none;
    background: var(--gray-100);
    color: var(--gray-500);
    font-size: 18px;
    cursor: pointer;
    transition: all 0.2s;
}

.logout-btn:hover {
    background: var(--gray-200);
    transform: scale(1.05);
}

.checkin-section {
    text-align: center;
    margin-bottom: 32px;
}

.checkin-btn {
    width: 180px;
    height: 180px;
    border-radius: 50%;
    border: none;
    background: linear-gradient(145deg, #ff6b9d 0%, #c44569 100%);
    color: white;
    font-size: 24px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
    box-shadow: 
        0 20px 40px rgba(196, 69, 105, 0.4),
        inset 0 -8px 20px rgba(0, 0, 0, 0.2),
        inset 0 8px 20px rgba(255, 255, 255, 0.2);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}

.checkin-btn::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: linear-gradient(
        45deg,
        transparent 30%,
        rgba(255, 255, 255, 0.3) 50%,
        transparent 70%
    );
    animation: shimmer 3s infinite;
}

@keyframes shimmer {
    0% { transform: translateX(-100%) rotate(45deg); }
    100% { transform: translateX(100%) rotate(45deg); }
}

.checkin-btn:hover {
    transform: scale(1.05);
}

.checkin-btn:active {
    transform: scale(0.95);
}

.checkin-btn.disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
}

.checkin-btn-icon { font-size: 48px; }
.checkin-btn-text { font-size: 18px; letter-spacing: 4px; }

.checkin-hint {
    color: rgba(255, 255, 255, 0.9);
    font-size: 14px;
    margin-top: 16px;
}

.actions {
    display: flex;
    gap: 12px;
    margin-bottom: 24px;
}

.action-btn {
    flex: 1;
    padding: 18px;
    border: none;
    border-radius: var(--radius);
    background: white;
    box-shadow: var(--shadow-lg);
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.action-btn:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-xl);
}

.action-icon {
    width: 44px;
    height: 44px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
}

.action-icon.blue {
    background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
    color: white;
}

.action-text {
    font-size: 15px;
    font-weight: 600;
    color: var(--gray-800);
}

.section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
}

.section-title {
    font-size: 18px;
    font-weight: 700;
    color: white;
    display: flex;
    align-items: center;
    gap: 8px;
}

.section-badge {
    background: rgba(255, 255, 255, 0.3);
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
}

.activity-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.activity-card {
    background: white;
    border-radius: var(--radius);
    padding: 18px;
    box-shadow: var(--shadow-lg);
}

.activity-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 10px;
}

.activity-name {
    font-size: 16px;
    font-weight: 600;
    color: var(--gray-900);
    flex: 1;
}

.activity-status {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.status-ongoing {
    background: var(--success-light);
    color: var(--success);
}

.status-upcoming {
    background: #dbeafe;
    color: #2563eb;
}

.status-completed {
    background: var(--gray-100);
    color: var(--gray-500);
}

.activity-meta {
    font-size: 14px;
    color: var(--gray-500);
    display: flex;
    align-items: center;
    gap: 6px;
}

.empty-state {
    background: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(10px);
    border-radius: var(--radius-lg);
    padding: 48px 24px;
    text-align: center;
}

.empty-icon { font-size: 56px; margin-bottom: 12px; }
.empty-text { color: rgba(255, 255, 255, 0.8); font-size: 15px; }

.location-warning {
    background: linear-gradient(135deg, rgba(245, 158, 11, 0.9) 0%, rgba(234, 88, 12, 0.9) 100%);
    border-radius: var(--radius);
    padding: 20px;
    margin-bottom: 24px;
    text-align: center;
    color: white;
}

.location-warning .warning-icon { font-size: 40px; margin-bottom: 12px; }
.location-warning .warning-title { font-size: 18px; font-weight: 700; margin-bottom: 8px; }
.location-warning .warning-desc { font-size: 14px; opacity: 0.9; }
.location-warning .warning-btn {
    margin-top: 16px;
    padding: 12px 30px;
    background: rgba(255, 255, 255, 0.2);
    border: none;
    border-radius: 10px;
    color: white;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
}

.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    z-index: 1000;
    justify-content: center;
    align-items: flex-end;
}

.modal-overlay.show {
    display: flex;
}

.modal {
    background: white;
    width: 100%;
    max-width: 420px;
    border-radius: var(--radius-xl) var(--radius-xl) 0 0;
    padding: 24px;
    padding-bottom: max(24px, env(safe-area-inset-bottom));
    animation: slideUp 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    max-height: 85vh;
    overflow-y: auto;
}

@keyframes slideUp {
    from { transform: translateY(100%); }
    to { transform: translateY(0); }
}

.modal-handle {
    width: 36px;
    height: 4px;
    background: var(--gray-300);
    border-radius: 2px;
    margin: 0 auto 20px;
}

.modal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
}

.modal-title {
    font-size: 20px;
    font-weight: 700;
    color: var(--gray-900);
}

.modal-close {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    border: none;
    background: var(--gray-100);
    color: var(--gray-500);
    font-size: 20px;
    cursor: pointer;
}

.check-options {
    display: flex;
    flex-direction: column;
    gap: 14px;
}

.check-option {
    padding: 20px;
    border: 2px solid var(--gray-200);
    border-radius: var(--radius);
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 16px;
}

.check-option:hover {
    border-color: var(--primary);
    background: #f5f3ff;
}

.check-option.active {
    border-color: var(--primary);
    background: #f5f3ff;
}

.option-icon {
    width: 52px;
    height: 52px;
    border-radius: 14px;
    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    color: white;
}

.option-content { flex: 1; }

.option-title {
    font-size: 16px;
    font-weight: 600;
    color: var(--gray-900);
    margin-bottom: 4px;
}

.option-desc {
    font-size: 13px;
    color: var(--gray-500);
}

.input-section {
    margin-top: 20px;
}

.code-input {
    width: 100%;
    padding: 20px;
    border: 2px solid var(--gray-200);
    border-radius: var(--radius);
    font-size: 28px;
    font-weight: 700;
    text-align: center;
    letter-spacing: 8px;
    outline: none;
    transition: all 0.3s;
    font-family: monospace;
}

.code-input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
}

.captcha-section {
    margin-top: 16px;
    background: var(--gray-50);
    border-radius: var(--radius);
    padding: 16px;
}

.captcha-label {
    font-size: 14px;
    font-weight: 600;
    color: var(--gray-700);
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.captcha-refresh {
    color: var(--primary);
    font-size: 13px;
    cursor: pointer;
}

.captcha-display {
    background: white;
    padding: 20px;
    border-radius: var(--radius);
    text-align: center;
    font-size: 36px;
    font-weight: 700;
    letter-spacing: 10px;
    color: var(--primary);
    font-family: monospace;
    margin-bottom: 12px;
    border: 2px solid var(--gray-200);
}

.captcha-timer {
    font-size: 12px;
    color: var(--gray-500);
    text-align: center;
}

.captcha-input {
    width: 100%;
    padding: 16px;
    border: 2px solid var(--gray-200);
    border-radius: var(--radius);
    font-size: 20px;
    font-weight: 700;
    text-align: center;
    letter-spacing: 8px;
    outline: none;
    font-family: monospace;
}

.captcha-input:focus {
    border-color: var(--primary);
}

.submit-btn {
    width: 100%;
    padding: 18px;
    margin-top: 20px;
    border: none;
    border-radius: var(--radius);
    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
    color: white;
    font-size: 17px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    box-shadow: var(--shadow-lg);
}

.submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-xl);
}

.submit-btn:active {
    transform: translateY(0);
}

.submit-btn.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.toast {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0.8);
    background: var(--gray-900);
    color: white;
    padding: 20px 36px;
    border-radius: var(--radius);
    font-size: 16px;
    font-weight: 500;
    z-index: 3000;
    opacity: 0;
    pointer-events: none;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.toast.show {
    opacity: 1;
    transform: translate(-50%, -50%) scale(1);
}

.toast.success {
    background: linear-gradient(135deg, var(--success) 0%, #059669 100%);
}

.toast.error {
    background: linear-gradient(135deg, var(--danger) 0%, #dc2626 100%);
}

.loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 2000;
}

.loading-overlay.show { display: flex; }

.loading-spinner {
    width: 50px;
    height: 50px;
    border: 4px solid rgba(255, 255, 255, 0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}
</style>
</head>
<body>
<div class="container">
    <div class="user-card">
        <div class="avatar" id="avatar">?</div>
        <div class="user-info">
            <div class="user-name" id="name">加载中...</div>
            <div class="user-id" id="sid">--</div>
        </div>
        <button class="logout-btn" id="logoutBtn" title="退出登录">🚪</button>
    </div>

    <div id="locationWarning" class="location-warning" style="display: none;">
        <div class="warning-icon">📍</div>
        <div class="warning-title" id="locationTitle">位置未授权</div>
        <div class="warning-desc" id="locationDesc">请授权获取位置信息以进行签到</div>
        <button class="warning-btn" id="requestLocationBtn">获取位置</button>
    </div>

    <div class="checkin-section">
        <button class="checkin-btn" id="checkinBtn">
            <span class="checkin-btn-icon">📝</span>
            <span class="checkin-btn-text">签 到</span>
        </button>
        <div class="checkin-hint" id="checkinHint">点击按钮进行签到</div>
    </div>

    <div class="section-header">
        <div class="section-title">
            📌 进行中的活动
            <span class="section-badge" id="activityCount">0</span>
        </div>
    </div>
    <div class="activity-list" id="activityList">
        <div class="empty-state">
            <div class="empty-icon">🎪</div>
            <div class="empty-text">暂无进行中的活动</div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="checkinModal">
    <div class="modal">
        <div class="modal-handle"></div>
        <div class="modal-header">
            <div class="modal-title">📝 签到</div>
            <button class="modal-close" id="closeModal">×</button>
        </div>
        
        <div class="check-options">
            <div class="check-option" id="scanOption">
                <div class="option-icon">📷</div>
                <div class="option-content">
                    <div class="option-title">扫码签到</div>
                    <div class="option-desc">扫描活动二维码快速签到</div>
                </div>
            </div>
            <div class="check-option" id="codeOption">
                <div class="option-icon">⌨️</div>
                <div class="option-content">
                    <div class="option-title">输入签到码</div>
                    <div class="option-desc">手动输入签到码进行签到</div>
                </div>
            </div>
        </div>
        
        <div class="input-section" id="inputSection">
            <input type="text" class="code-input" id="codeInput" placeholder="签到码" maxlength="6" autocomplete="off">
            <div id="captchaSection" style="display: none;">
                <div class="captcha-section">
                    <div class="captcha-label">
                        <span>验证码</span>
                        <span class="captcha-refresh" id="refreshCaptcha">🔄 刷新</span>
                    </div>
                    <div class="captcha-display" id="captchaDisplay">----</div>
                    <div class="captcha-timer" id="captchaTimer">60秒后刷新</div>
                    <input type="text" class="captcha-input" id="captchaInput" placeholder="请输入验证码" maxlength="8" autocomplete="off">
                </div>
            </div>
            <button class="submit-btn" id="submitBtn">确认签到</button>
        </div>
    </div>
</div>

<div class="toast" id="toast"></div>
<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-spinner"></div>
</div>

<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script>
(function() {
    var token = null;
    var user = null;
    var currentActivity = null;
    var currentLocation = { latitude: null, longitude: null };
    var captchaData = null;
    var captchaTimer = null;
    var html5QrcodeScanner = null;

    function $(id) { return document.getElementById(id); }

    function showToast(msg, type) {
        var toast = $('toast');
        toast.textContent = msg;
        toast.className = 'toast ' + (type || '');
        setTimeout(function() { toast.classList.add('show'); }, 10);
        setTimeout(function() { toast.classList.remove('show'); }, 2500);
    }

    function showLoading() { $('loadingOverlay').classList.add('show'); }
    function hideLoading() { $('loadingOverlay').classList.remove('show'); }

    function init() {
        token = localStorage.getItem('student_token');
        if (!token) {
            window.location.href = '/student';
            return;
        }
        loadUser();
        loadCurrentActivity();
        bindEvents();
        
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(pos) {
                    currentLocation.latitude = pos.coords.latitude;
                    currentLocation.longitude = pos.coords.longitude;
                },
                function(err) {
                    console.log('Location error:', err);
                }
            );
        }
    }

    function loadUser() {
        fetch('/api/student/profile?token=' + token)
            .then(function(r) { return r.json(); })
            .then(function(d) {
                user = d;
                $('avatar').textContent = d.name.charAt(0);
                $('name').textContent = d.name;
                $('sid').textContent = '学号: ' + d.student_id;
            })
            .catch(function(e) {
                showToast('加载用户信息失败', 'error');
            });
    }

    function loadCurrentActivity() {
        fetch('/api/student/current-checkin?token=' + token)
            .then(function(r) { return r.json(); })
            .then(function(d) {
                currentActivity = d.activity;
                if (currentActivity) {
                    $('activityCount').textContent = '1';
                    $('activityList').innerHTML = '<div class="activity-card"><div class="activity-header"><div class="activity-name">' + currentActivity.name + '</div><span class="activity-status status-ongoing">进行中</span></div><div class="activity-meta">📍 ' + (currentActivity.location || '') + '</div></div>';
                    $('checkinBtn').classList.remove('disabled');
                    
                    if (currentActivity.enable_location_check && !currentLocation.latitude) {
                        showLocationWarning('位置未授权', '请授权获取位置信息以进行签到');
                    }
                } else {
                    $('activityCount').textContent = '0';
                    $('activityList').innerHTML = '<div class="empty-state"><div class="empty-icon">🎪</div><div class="empty-text">暂无进行中的活动</div></div>';
                    $('checkinBtn').classList.add('disabled');
                    $('checkinHint').textContent = '暂无进行中的活动';
                }
            })
            .catch(function(e) {
                console.log('loadCurrentActivity error:', e);
            });
    }

    function showLocationWarning(title, desc) {
        $('locationTitle').textContent = title;
        $('locationDesc').textContent = desc;
        $('locationWarning').style.display = 'block';
        $('checkinBtn').classList.add('disabled');
    }

    function hideLocationWarning() {
        $('locationWarning').style.display = 'none';
        $('checkinBtn').classList.remove('disabled');
    }

    function requestLocation() {
        if (!navigator.geolocation) {
            showToast('您的浏览器不支持定位功能', 'error');
            return;
        }
        
        showLoading();
        navigator.geolocation.getCurrentPosition(
            function(pos) {
                hideLoading();
                currentLocation.latitude = pos.coords.latitude;
                currentLocation.longitude = pos.coords.longitude;
                hideLocationWarning();
                showToast('📍 位置获取成功', 'success');
                
                if (currentActivity && currentActivity.enable_location_check) {
                    verifyLocation();
                }
            },
            function(err) {
                hideLoading();
                var msg = '位置获取失败';
                if (err.code === err.PERMISSION_DENIED) {
                    msg = '请在浏览器设置中开启位置权限';
                } else if (err.code === err.POSITION_UNAVAILABLE) {
                    msg = '当前无法获取位置信息';
                }
                showToast(msg, 'error');
            },
            { enableHighAccuracy: true, timeout: 10000 }
        );
    }

    function verifyLocation() {
        if (!currentActivity || !currentActivity.enable_location_check) return;
        if (!currentActivity.location_latitude || !currentActivity.location_longitude) return;
        if (!currentLocation.latitude || !currentLocation.longitude) return;

        var distance = calculateDistance(
            currentLocation.latitude, currentLocation.longitude,
            currentActivity.location_latitude, currentActivity.location_longitude
        );

        if (distance > currentActivity.location_radius) {
            showLocationWarning('超出签到范围', '您当前位置距离签到点约 ' + Math.round(distance) + ' 米，请前往指定地点签到');
            return false;
        }
        return true;
    }

    function calculateDistance(lat1, lon1, lat2, lon2) {
        var R = 6371000;
        var dLat = toRad(lat2 - lat1);
        var dLon = toRad(lon2 - lon1);
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    function toRad(x) {
        return x * Math.PI / 180;
    }

    function openCheckinModal() {
        if (!currentActivity) {
            showToast('暂无进行中的活动', 'error');
            return;
        }

        if (currentActivity.enable_location_check) {
            if (!currentLocation.latitude) {
                requestLocation();
                return;
            }
            
            var valid = verifyLocation();
            if (!valid) return;
        }

        $('scanOption').classList.remove('active');
        $('codeOption').classList.remove('active');
        $('inputSection').style.display = 'none';
        $('captchaSection').style.display = 'none';
        $('codeInput').value = '';
        $('captchaInput').value = '';
        
        $('checkinModal').classList.add('show');
        
        if (currentActivity.enable_captcha) {
            loadCaptcha();
        }
    }

    function loadCaptcha() {
        if (!currentActivity) return;
        
        fetch('/api/activity/' + currentActivity.id + '/captcha')
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.captcha_enabled) {
                    captchaData = d;
                    updateCaptchaDisplay();
                    startCaptchaTimer();
                }
            })
            .catch(function(e) {
                console.log('loadCaptcha error:', e);
            });
    }

    function updateCaptchaDisplay() {
        if (!captchaData) return;
        $('captchaDisplay').textContent = captchaData.captcha;
        $('captchaTimer').textContent = captchaData.expires_in + '秒后刷新';
    }

    function startCaptchaTimer() {
        if (captchaTimer) clearInterval(captchaTimer);
        
        captchaTimer = setInterval(function() {
            if (!captchaData) {
                clearInterval(captchaTimer);
                return;
            }
            
            captchaData.expires_in--;
            $('captchaTimer').textContent = captchaData.expires_in + '秒后刷新';
            
            if (captchaData.expires_in <= 0) {
                clearInterval(captchaTimer);
                loadCaptcha();
            }
        }, 1000);
    }

    function refreshCaptcha() {
        if (!currentActivity) return;
        
        fetch('/api/activity/' + currentActivity.id + '/refresh-captcha')
            .then(function(r) { return r.json(); })
            .then(function(d) {
                captchaData = {
                    captcha: d.captcha,
                    expires_in: d.expires_in,
                    refresh_interval: d.refresh_interval
                };
                updateCaptchaDisplay();
                startCaptchaTimer();
                $('captchaInput').value = '';
            })
            .catch(function(e) {
                showToast('刷新验证码失败', 'error');
            });
    }

    function selectScanOption() {
        $('scanOption').classList.add('active');
        $('codeOption').classList.remove('active');
        
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            showToast('您的浏览器不支持摄像头', 'error');
            selectCodeOption();
            return;
        }

        $('inputSection').style.display = 'none';
        
        html5QrcodeScanner = new Html5Qrcode("qr-reader");
        html5QrcodeScanner.start(
            { facingMode: "environment" },
            { fps: 10, qrbox: { width: 250, height: 250 } },
            function(code) {
                processCheckin(code);
            },
            function() {}
        ).catch(function() {
            showToast('无法访问摄像头', 'error');
            selectCodeOption();
        });
    }

    function selectCodeOption() {
        $('codeOption').classList.add('active');
        $('scanOption').classList.remove('active');
        
        if (html5QrcodeScanner) {
            html5QrcodeScanner.stop().then(function() {
                html5QrcodeScanner.clear();
            }).catch(function() {});
            html5QrcodeScanner = null;
        }
        
        $('inputSection').style.display = 'block';
        if (currentActivity && currentActivity.enable_captcha) {
            $('captchaSection').style.display = 'block';
        }
        $('codeInput').focus();
    }

    function processCheckin(code) {
        if (!user) {
            showToast('请先登录', 'error');
            return;
        }
        
        var payload = {
            activity_code: code,
            student_id: user.student_id,
            name: user.name
        };
        
        if (currentLocation.latitude && currentLocation.longitude) {
            payload.latitude = currentLocation.latitude;
            payload.longitude = currentLocation.longitude;
        }
        
        if (currentActivity && currentActivity.enable_captcha) {
            var captchaInput = $('captchaInput').value.trim();
            if (!captchaInput) {
                showToast('请输入验证码', 'error');
                return;
            }
            payload.captcha = captchaInput;
        }
        
        showLoading();
        
        fetch('/api/checkin', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            hideLoading();
            closeModal();
            showToast('🎉 签到成功！', 'success');
            loadCurrentActivity();
        })
        .catch(function(e) {
            hideLoading();
            if (e.message && e.message.includes('距离')) {
                showToast(e.message, 'error');
                showLocationWarning('超出签到范围', e.message);
            } else {
                showToast('签到失败: ' + (e.message || '网络错误'), 'error');
            }
        });
    }

    function closeModal() {
        $('checkinModal').classList.remove('show');
        
        if (html5QrcodeScanner) {
            html5QrcodeScanner.stop().then(function() {
                html5QrcodeScanner.clear();
            }).catch(function() {});
            html5QrcodeScanner = null;
        }
        
        if (captchaTimer) {
            clearInterval(captchaTimer);
            captchaTimer = null;
        }
    }

    function logout() {
        if (confirm('确定要退出登录吗？')) {
            localStorage.removeItem('student_token');
            window.location.href = '/student';
        }
    }

    function bindEvents() {
        $('checkinBtn').addEventListener('click', openCheckinModal);
        $('logoutBtn').addEventListener('click', logout);
        $('closeModal').addEventListener('click', closeModal);
        $('requestLocationBtn').addEventListener('click', requestLocation);
        
        $('checkinModal').addEventListener('click', function(e) {
            if (e.target === $('checkinModal')) {
                closeModal();
            }
        });

        $('scanOption').addEventListener('click', selectScanOption);
        $('codeOption').addEventListener('click', selectCodeOption);
        $('refreshCaptcha').addEventListener('click', refreshCaptcha);
        
        $('submitBtn').addEventListener('click', function() {
            var code = $('codeInput').value.trim();
            if (!code) {
                showToast('请输入签到码', 'error');
                return;
            }
            processCheckin(code);
        });

        $('codeInput').addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                $('submitBtn').click();
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
</script>
</body>
</html>"""
