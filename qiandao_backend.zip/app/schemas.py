"""数据验证模型。"""
import re
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field, field_validator


class AdminLogin(BaseModel):
    username: str = Field(..., min_length=1, max_length=64)
    password: str = Field(..., min_length=1, max_length=64)


class AdminCreate(BaseModel):
    username: str = Field(..., min_length=1, max_length=64)
    password: str = Field(..., min_length=6, max_length=64)
    real_name: str = Field(..., min_length=1, max_length=64)
    role: str = Field(default="admin")
    department: Optional[str] = Field(None, max_length=64)
    is_super: bool = Field(default=False)


class StudentCheckin(BaseModel):
    student_id: str = Field(..., min_length=1, max_length=64)
    name: str = Field(..., min_length=1, max_length=64)
    activity_code: str = Field(..., min_length=1, max_length=16)
    latitude: Optional[float] = Field(None)
    longitude: Optional[float] = Field(None)
    captcha: Optional[str] = Field(None, max_length=16)

    @field_validator('student_id')
    @classmethod
    def student_id_must_be_digits(cls, v: str) -> str:
        if not re.match(r'^[0-9]+$', v):
            raise ValueError('学号只能使用数字')
        return v

    @field_validator('name')
    @classmethod
    def name_must_be_chinese(cls, v: str) -> str:
        if not re.match(r'^[\u4e00-\u9fa5]+$', v):
            raise ValueError('姓名只能使用中文')
        return v


class ActivityCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)
    description: Optional[str] = Field(None, max_length=512)
    location: Optional[str] = Field(None, max_length=128)
    department: Optional[str] = Field(None, max_length=64)
    checkin_duration: int = Field(default=30, ge=5, le=180)
    code_refresh_interval: int = Field(default=60)
    
    enable_location_check: bool = Field(default=False)
    location_latitude: Optional[float] = Field(None)
    location_longitude: Optional[float] = Field(None)
    location_radius: int = Field(default=100, ge=10, le=1000)
    
    enable_captcha: bool = Field(default=False)
    captcha_length: int = Field(default=4, ge=4, le=8)
    captcha_refresh_interval: int = Field(default=60, ge=10, le=300)


class ActivityUpdate(BaseModel):
    name: Optional[str] = Field(None, max_length=128)
    description: Optional[str] = Field(None, max_length=512)
    location: Optional[str] = Field(None, max_length=128)
    department: Optional[str] = Field(None, max_length=64)
    checkin_duration: Optional[int] = None
    code_refresh_interval: Optional[int] = None
    
    enable_location_check: Optional[bool] = None
    location_latitude: Optional[float] = None
    location_longitude: Optional[float] = None
    location_radius: Optional[int] = None
    
    enable_captcha: Optional[bool] = None
    captcha_length: Optional[int] = None
    captcha_refresh_interval: Optional[int] = None


class ManualCheckin(BaseModel):
    student_id: str = Field(..., min_length=1, max_length=64)
    name: str = Field(..., min_length=1, max_length=64)
    class_name: Optional[str] = Field(None, max_length=64)

    @field_validator('student_id')
    @classmethod
    def student_id_must_be_digits(cls, v: str) -> str:
        if not re.match(r'^[0-9]+$', v):
            raise ValueError('学号只能使用数字')
        return v

    @field_validator('name')
    @classmethod
    def name_must_be_chinese(cls, v: str) -> str:
        if not re.match(r'^[\u4e00-\u9fa5]+$', v):
            raise ValueError('姓名只能使用中文')
        return v


class Token(BaseModel):
    access_token: str
    token_type: str
    admin: dict


class StudentImportItem(BaseModel):
    student_id: str = Field(..., min_length=1, max_length=64)
    name: str = Field(..., min_length=1, max_length=64)
    class_name: Optional[str] = Field(None, max_length=64)

    @field_validator('student_id')
    @classmethod
    def student_id_must_be_digits(cls, v: str) -> str:
        if not v.isdigit():
            raise ValueError('学号只能使用数字')
        return v

    @field_validator('name')
    @classmethod
    def name_must_be_chinese(cls, v: str) -> str:
        if not re.match(r'^[\u4e00-\u9fa5]+$', v):
            raise ValueError('姓名只能使用中文')
        return v


class StudentImportRequest(BaseModel):
    students: list[StudentImportItem]
