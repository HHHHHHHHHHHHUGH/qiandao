"""简单测试页面"""

from fastapi import APIRouter

router = APIRouter()

@router.get("/test")
async def test_page():
    return """
<!DOCTYPE html>
<html>
<head>
    <title>测试页面</title>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; padding: 50px; text-align: center; background: #f5f5f5; }
        button {
            padding: 20px 40px;
            font-size: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(102,126,234,0.4);
        }
        button:hover { transform: translateY(-2px); }
        #result { margin-top: 30px; font-size: 18px; color: #666; }
    </style>
</head>
<body>
    <h1>🔘 按钮测试</h1>
    <button onclick="testButton()">点击我</button>
    <div id="result"></div>
    
    <script>
        function testButton() {
            alert('按钮点击成功！');
            document.getElementById('result').innerHTML = '<span style="color:green;">✅ 按钮点击成功！JavaScript正常工作</span>';
        }
    </script>
</body>
</html>
"""
