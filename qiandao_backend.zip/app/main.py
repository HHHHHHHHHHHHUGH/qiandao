"""FastAPI 应用入口"""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from .config import CORS_ORIGINS
from .database import Base, engine, get_db, get_password_hash
from .models import Admin, Student
from sqlalchemy import select
from .routers import admin, checkin
from .test_button import router as test_router
from .simple_admin import router as simple_admin_router
from .test_page import router as test_page_router
from .simple_create_activity import router as create_activity_router
from .basic_admin import router as basic_admin_router
from .minimal_admin import router as minimal_admin_router

Base.metadata.create_all(bind=engine)


def create_default_admin():
    db = next(get_db())
    try:
        admin_user = db.execute(select(Admin).where(Admin.username == "hahaha")).scalar_one_or_none()
        if not admin_user:
            admin_user = Admin(
                username="hahaha",
                password=get_password_hash("333333"),
                real_name="管理员",
                role="super_admin",
                department="系统",
                is_super=True,
            )
            db.add(admin_user)
            db.commit()
            print("默认管理员已创建: hahaha / 333333")
    except Exception as e:
        print(f"创建默认管理员时出错: {e}")
    finally:
        db.close()


app = FastAPI(
    title="在线签到系统",
    description="基于 FastAPI + SQLite 的签到服务",
    version="3.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def set_encoding_header(request: Request, call_next):
    response = await call_next(request)
    if "Content-Type" in response.headers and "application/json" in response.headers["Content-Type"]:
        response.headers["Content-Type"] = "application/json; charset=utf-8"
    return response

app.include_router(checkin.router)
app.include_router(admin.router)
app.include_router(test_router)
app.include_router(simple_admin_router)
app.include_router(test_page_router)
app.include_router(create_activity_router)
app.include_router(basic_admin_router)
app.include_router(minimal_admin_router)


def create_test_student():
    db = next(get_db())
    try:
        test_student = db.execute(select(Student).where(Student.student_id == "2502160608024")).scalar_one_or_none()
        if not test_student:
            test_student = Student(
                student_id="2502160608024",
                name="朱意婷",
                class_name="测试班级"
            )
            db.add(test_student)
            db.commit()
            print("测试学生已创建: 2502160608024 / 朱意婷")
    except Exception as e:
        print(f"创建测试学生时出错: {e}")
    finally:
        db.close()


@app.on_event("startup")
def startup_event():
    create_default_admin()
    create_test_student()


@app.get("/api/health", tags=["meta"])
def health():
    return {"status": "ok"}


@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    html_content = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>在线签到系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            background: white;
            border-radius: 24px;
            padding: 50px 40px;
            max-width: 450px;
            width: 90%;
            text-align: center;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
        }
        .logo {
            width: 90px;
            height: 90px;
            margin: 0 auto 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 22px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 42px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
        }
        h1 { color: #1a1a2e; font-size: 28px; margin-bottom: 8px; }
        p { color: #666; font-size: 14px; margin-bottom: 32px; }
        .btn {
            display: block;
            padding: 16px 24px;
            margin: 12px 0;
            border: none;
            border-radius: 14px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }
        .btn-secondary {
            background: #f5f5f5;
            color: #333;
        }
        .btn-secondary:hover { background: #eee; }
        .footer { margin-top: 30px; color: #999; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">📋</div>
        <h1>在线签到系统</h1>
        <p>便捷高效的校园活动签到解决方案</p>
        <a href="/student" class="btn btn-primary">📱 学生签到</a>
        <a href="/admin/login" class="btn btn-secondary">🔐 管理员登录</a>
    </div>
</body>
</html>'''
    return HTMLResponse(content=html_content)


@app.get("/student", response_class=HTMLResponse)
async def student_login_page(request: Request):
    html_content = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>学生登录 - 讲座报名签到系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 24px;
            padding: 40px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
        }
        .logo {
            width: 70px;
            height: 70px;
            margin: 0 auto 24px;
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            border-radius: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 32px;
        }
        h1 {
            text-align: center;
            color: #1a1a2e;
            font-size: 24px;
            margin-bottom: 8px;
        }
        .subtitle {
            text-align: center;
            color: #888;
            font-size: 14px;
            margin-bottom: 32px;
        }
        .input-group {
            margin-bottom: 20px;
        }
        .input-group label {
            display: block;
            color: #333;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        .input-group input {
            width: 100%;
            padding: 14px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            font-size: 16px;
            outline: none;
            transition: border-color 0.25s;
        }
        .input-group input:focus {
            border-color: #667eea;
        }
        .btn-login {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            margin-top: 8px;
            transition: all 0.3s ease;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
        }
        .btn-login:active {
            transform: translateY(0);
        }
        .error {
            color: #e53935;
            font-size: 13px;
            text-align: center;
            margin-top: 16px;
            display: none;
        }
        .error.show {
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">📝</div>
        <h1>学生登录</h1>
        <p class="subtitle">讲座报名签到系统</p>
        <div class="input-group">
            <label>姓名</label>
            <input type="text" id="studentName" placeholder="请输入姓名">
        </div>
        <div class="input-group">
            <label>学号</label>
            <input type="text" id="studentId" placeholder="请输入学号">
        </div>
        <button class="btn-login" id="loginBtn">登录</button>
        <div class="error" id="errorMsg">登录失败，请检查学号和密码</div>
    </div>
    <script>
        document.getElementById('loginBtn').addEventListener('click', function() {
            var studentName = document.getElementById('studentName').value.trim();
            var studentId = document.getElementById('studentId').value.trim();
            
            if (!studentName || !studentId) {
                document.getElementById('errorMsg').textContent = '请填写姓名和学号';
                document.getElementById('errorMsg').classList.add('show');
                return;
            }
            
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/student/login', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        var data = JSON.parse(xhr.responseText);
                        localStorage.setItem('student_token', data.token);
                        window.location.href = '/student/main';
                    } else {
                        var errorText = '登录失败，请检查学号和密码';
                        try {
                            var response = JSON.parse(xhr.responseText);
                            if (response.detail) {
                                errorText = response.detail;
                            }
                        } catch (e) {}
                        document.getElementById('errorMsg').textContent = errorText;
                        document.getElementById('errorMsg').classList.add('show');
                    }
                }
            };
            xhr.send(JSON.stringify({ student_id: studentId, name: studentName }));
        });
        
        document.getElementById('studentId').addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                document.getElementById('loginBtn').click();
            }
        });
    </script>
</body>
</html>'''
    return HTMLResponse(content=html_content)


@app.get("/student/main", response_class=HTMLResponse)
async def student_main_page(request: Request):
    from .student_minimal import STUDENT_MINIMAL_HTML
    return HTMLResponse(content=STUDENT_MINIMAL_HTML)


@app.get("/simple-test", response_class=HTMLResponse)
async def simple_test(request: Request):
    from .simple_test import SIMPLE_TEST_HTML
    return HTMLResponse(content=SIMPLE_TEST_HTML)


@app.get("/login", response_class=HTMLResponse)
@app.get("/admin/login", response_class=HTMLResponse)
async def unified_login_page(request: Request):
    from .unified_login import UNIFIED_LOGIN_HTML
    return HTMLResponse(
        content=UNIFIED_LOGIN_HTML,
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0"
        }
    )


@app.get("/admin/main")
async def admin_main_page(request: Request):
    user_agent = request.headers.get("user-agent", "").lower()
    is_mobile = any(mobile in user_agent for mobile in ["mobile", "android", "iphone", "ipad", "ipod", "windows phone"])
    
    if is_mobile:
        from .admin_mobile import ADMIN_MOBILE_HTML
        return HTMLResponse(
            content=ADMIN_MOBILE_HTML,
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0"
            }
        )
    else:
        from .admin_full import ADMIN_FULL_HTML
        return HTMLResponse(
            content=ADMIN_FULL_HTML,
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0"
            }
        )

@app.get("/admin/dashboard")
async def admin_dashboard_page(request: Request):
    from .admin_main_final import ADMIN_MAIN_HTML
    from fastapi.responses import HTMLResponse
    return HTMLResponse(content=ADMIN_MAIN_HTML)

@app.get("/test-admin", response_class=HTMLResponse)
async def test_admin_page(request: Request):
    return HTMLResponse(content="<html><head><title>Test</title></head><body><h1>Hello World</h1></body></html>")


@app.get("/admin/mobile", response_class=HTMLResponse)
async def admin_mobile_page(request: Request):
    from .admin_mobile import ADMIN_MOBILE_HTML
    return HTMLResponse(
        content=ADMIN_MOBILE_HTML,
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0"
        }
    )
