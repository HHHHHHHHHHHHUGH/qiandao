"""基础管理员页面"""

from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from .database import get_db
from .models import Activity, Admin
from .config import generate_checkin_code

router = APIRouter()

@router.get("/admin/basic")
async def basic_admin(request: Request):
    db = next(get_db())
    token = request.cookies.get("admin_token")
    
    if not token:
        return RedirectResponse(url="/admin/login")
    
    activities = db.execute(select(Activity)).scalars().all()
    activities_html = ""
    if activities:
        activities_html = """
        <table style="width:100%;border-collapse:collapse;margin-top:20px;">
            <tr style="border-bottom:2px solid #f0f0f0;">
                <th style="text-align:left;padding:12px;">活动名称</th>
                <th style="text-align:left;padding:12px;">状态</th>
                <th style="text-align:left;padding:12px;">签到码</th>
                <th style="text-align:right;padding:12px;">操作</th>
            </tr>
        """
        for a in activities:
            status = "进行中" if a.is_active else "未开始"
            status_color = "green" if a.is_active else "gray"
            activities_html += f"""
            <tr style="border-bottom:1px solid #f0f0f0;">
                <td style="padding:12px;">{a.name}</td>
                <td style="padding:12px;"><span style="color:{status_color};">{status}</span></td>
                <td style="padding:12px;font-family:monospace;">{a.code or '-'}</td>
                <td style="padding:12px;text-align:right;">
                    <a href="/admin/basic/activity/{a.id}" style="padding:6px 12px;background:#667eea;color:white;border-radius:6px;text-decoration:none;font-size:12px;margin-right:6px;">详情</a>
                    <a href="/admin/basic/activity/{a.id}/start" style="padding:6px 12px;background:#4caf50;color:white;border-radius:6px;text-decoration:none;font-size:12px;margin-right:6px;">开始</a>
                    <a href="/admin/basic/activity/{a.id}/end" style="padding:6px 12px;background:#e53935;color:white;border-radius:6px;text-decoration:none;font-size:12px;">结束</a>
                </td>
            </tr>
            """
        activities_html += "</table>"
    else:
        activities_html = '<div style="text-align:center;padding:40px;color:#999;">暂无活动</div>'
    
    return HTMLResponse(content=f"""
<!DOCTYPE html>
<html>
<head>
    <title>管理员后台</title>
    <meta charset="utf-8">
    <style>
        body {{ font-family: Arial, sans-serif; margin: 0; background: linear-gradient(135deg, #667eea, #764ba2); min-height: 100vh; }}
        .container {{ max-width: 1000px; margin: 0 auto; padding: 30px; }}
        .card {{ background: white; border-radius: 16px; padding: 24px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }}
        .card-header {{ display: flex; justify-content: space-between; align-items: center; }}
        .btn-primary {{
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
        }}
        .btn-primary:hover {{ opacity: 0.9; }}
        h2 {{ margin: 0; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>📋 活动管理</h2>
                <a href="/admin/basic/create" class="btn-primary">+ 新建活动</a>
            </div>
            {activities_html}
        </div>
    </div>
</body>
</html>
""")

@router.get("/admin/basic/create")
async def create_activity_page(request: Request):
    token = request.cookies.get("admin_token")
    if not token:
        return RedirectResponse(url="/admin/login")
    
    return HTMLResponse(content="""
<!DOCTYPE html>
<html>
<head>
    <title>创建活动</title>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); min-height: 100vh; padding: 30px; }
        .container { max-width: 500px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; }
        h2 { text-align: center; margin-bottom: 30px; }
        input {
            width: 100%;
            padding: 14px;
            margin-bottom: 15px;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }
        .back-link { display: block; text-align: center; margin-top: 20px; color: #667eea; }
    </style>
</head>
<body>
    <div class="container">
        <h2>📋 创建活动</h2>
        <form method="POST">
            <input type="text" name="name" placeholder="活动名称" required>
            <input type="text" name="description" placeholder="活动描述（可选）">
            <input type="text" name="location" placeholder="活动地点（可选）">
            <input type="text" name="department" placeholder="所属部门（可选）">
            <input type="number" name="checkin_duration" placeholder="签到时长（分钟）" value="30" min="1">
            <button type="submit">创建活动</button>
        </form>
        <a href="/admin/basic" class="back-link">← 返回活动列表</a>
    </div>
</body>
</html>
""")

@router.post("/admin/basic/create")
async def create_activity_post(name: str = Form(...), description: str = Form(""),
                               location: str = Form(""), department: str = Form(""),
                               checkin_duration: int = Form(30)):
    db = next(get_db())
    code = generate_checkin_code()
    activity = Activity(
        name=name,
        description=description,
        location=location,
        department=department,
        code=code,
        checkin_duration=checkin_duration
    )
    db.add(activity)
    db.commit()
    db.refresh(activity)
    
    return HTMLResponse(content=f"""
<!DOCTYPE html>
<html>
<head>
    <title>创建成功</title>
    <meta charset="utf-8">
    <style>
        body {{ font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); min-height: 100vh; padding: 30px; }}
        .container {{ max-width: 400px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; text-align: center; }}
        .success-icon {{ font-size: 60px; margin-bottom: 20px; }}
        button {{
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="success-icon">✅</div>
        <h2>创建成功！</h2>
        <p>活动名称: {name}</p>
        <p>签到码: {code}</p>
        <button onclick="window.location.href='/admin/basic'">返回活动列表</button>
    </div>
</body>
</html>
""")

@router.get("/admin/basic/activity/{activity_id}/start")
async def start_activity(activity_id: int):
    db = next(get_db())
    activity = db.get(Activity, activity_id)
    if activity:
        activity.is_active = True
        db.commit()
    return RedirectResponse(url="/admin/basic")

@router.get("/admin/basic/activity/{activity_id}/end")
async def end_activity(activity_id: int):
    db = next(get_db())
    activity = db.get(Activity, activity_id)
    if activity:
        activity.is_active = False
        db.commit()
    return RedirectResponse(url="/admin/basic")

@router.get("/admin/basic/activity/{activity_id}")
async def activity_detail(activity_id: int, request: Request):
    token = request.cookies.get("admin_token")
    if not token:
        return RedirectResponse(url="/admin/login")
    
    db = next(get_db())
    activity = db.get(Activity, activity_id)
    if not activity:
        return HTMLResponse(content="<h1>活动不存在</h1>")
    
    status_color = 'green' if activity.is_active else 'gray'
    status_text = '进行中' if activity.is_active else '未开始'
    
    html = """
<!DOCTYPE html>
<html>
<head>
    <title>活动详情</title>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); min-height: 100vh; padding: 30px; }
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; }
        .info { padding: 15px; background: #f8f9fa; border-radius: 10px; margin-bottom: 15px; }
        .label { font-size: 12px; color: #888; margin-bottom: 5px; }
        .value { font-size: 18px; font-weight: bold; }
        .back-link { display: block; text-align: center; margin-top: 20px; color: #667eea; }
    </style>
</head>
<body>
    <div class="container">
        <h2 style="text-align:center;">📋 {name}</h2>
        <div class="info">
            <div class="label">状态</div>
            <div class="value" style="color: {status_color};">{status_text}</div>
        </div>
        <div class="info">
            <div class="label">签到码</div>
            <div class="value" style="font-family:monospace;">{code}</div>
        </div>
        <div class="info">
            <div class="label">签到时长</div>
            <div class="value">{duration}分钟</div>
        </div>
        <div class="info">
            <div class="label">活动描述</div>
            <div>{description}</div>
        </div>
        <div class="info">
            <div class="label">活动地点</div>
            <div>{location}</div>
        </div>
        <div class="info">
            <div class="label">所属部门</div>
            <div>{department}</div>
        </div>
        <a href="/admin/basic" class="back-link">← 返回活动列表</a>
    </div>
</body>
</html>
""".format(
        name=activity.name,
        status_color=status_color,
        status_text=status_text,
        code=activity.code,
        duration=activity.checkin_duration,
        description=activity.description or '-',
        location=activity.location or '-',
        department=activity.department or '-'
    )
    
    return HTMLResponse(content=html)
