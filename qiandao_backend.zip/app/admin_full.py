"""管理员后台 - 完整版"""

ADMIN_FULL_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员后台</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f5f7fa; min-height: 100vh; }
        .sidebar { position: fixed; left: 0; top: 0; width: 260px; height: 100vh; background: #1a1a2e; padding: 24px; z-index: 100; }
        .sidebar-brand { display: flex; align-items: center; gap: 12px; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 1px solid #2d2d44; }
        .sidebar-brand .icon { width: 44px; height: 44px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 22px; }
        .sidebar-brand .text { color: #fff; font-size: 18px; font-weight: 700; }
        .nav-menu { list-style: none; }
        .nav-item { margin-bottom: 4px; }
        .nav-link { display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 10px; color: #a0aec0; text-decoration: none; font-size: 14px; font-weight: 500; transition: all 0.25s; cursor: pointer; }
        .nav-link:hover { background: rgba(102, 126, 234, 0.15); color: #fff; }
        .nav-link.active { background: linear-gradient(135deg, rgba(102, 126, 234, 0.25) 0%, rgba(118, 75, 162, 0.25) 100%); color: #fff; border-left: 3px solid #667eea; }
        .nav-icon { font-size: 18px; }
        .user-panel { position: absolute; bottom: 24px; left: 24px; right: 24px; padding: 16px; background: #2d2d44; border-radius: 12px; display: flex; align-items: center; gap: 12px; }
        .user-avatar { width: 40px; height: 40px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; }
        .user-info { flex: 1; }
        .user-name { color: #fff; font-weight: 600; font-size: 14px; }
        .user-role { color: #a0aec0; font-size: 12px; }
        .logout-btn { color: #ff6b6b; cursor: pointer; padding: 8px 12px; border-radius: 8px; font-size: 12px; transition: background 0.2s; }
        .logout-btn:hover { background: rgba(255, 107, 107, 0.15); }
        .main-content { margin-left: 260px; min-height: 100vh; padding: 24px; }
        .page-header { margin-bottom: 24px; }
        .page-title { font-size: 24px; font-weight: 700; color: #1a1a2e; }
        .page-subtitle { color: #666; font-size: 14px; margin-top: 4px; }
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: #fff; padding: 24px; border-radius: 16px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); }
        .stat-icon { width: 48px; height: 48px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 24px; margin-bottom: 16px; }
        .stat-icon.users { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-icon.activities { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .stat-icon.checkins { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        .stat-icon.active { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); }
        .stat-value { font-size: 32px; font-weight: 700; color: #1a1a2e; margin-bottom: 4px; }
        .stat-label { color: #888; font-size: 14px; }
        .content-card { background: #fff; border-radius: 16px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); padding: 24px; }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .card-title { font-size: 18px; font-weight: 600; color: #1a1a2e; }
        .btn { padding: 10px 20px; border: none; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4); }
        .btn-success { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: #fff; }
        .btn-danger { background: linear-gradient(135deg, #ff6b6b 0%, #ffa500 100%); color: #fff; }
        .btn-secondary { background: #f0f0f0; color: #333; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        .table { width: 100%; border-collapse: collapse; }
        .table th, .table td { padding: 14px 16px; text-align: left; border-bottom: 1px solid #f0f0f0; }
        .table th { background: #f8f9fa; font-weight: 600; color: #666; font-size: 13px; }
        .table td { font-size: 14px; color: #333; }
        .table tr:hover { background: #f8f9fa; }
        .badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .badge-success { background: #e8f5e9; color: #2e7d32; }
        .badge-warning { background: #fff3e0; color: #e65100; }
        .badge-danger { background: #ffebee; color: #c62828; }
        .badge-info { background: #e3f2fd; color: #1976d2; }
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 2000; }
        .modal-overlay.active { display: flex; }
        .modal-content { background: #fff; width: 90%; max-width: 500px; border-radius: 20px; padding: 28px; position: relative; }
        .modal-close { position: absolute; top: 16px; right: 16px; width: 32px; height: 32px; border: none; border-radius: 50%; background: #f0f0f0; font-size: 18px; cursor: pointer; }
        .modal-title { font-size: 20px; font-weight: 700; color: #1a1a2e; margin-bottom: 24px; }
        .form-group { margin-bottom: 18px; }
        .form-label { display: block; font-size: 14px; font-weight: 600; color: #333; margin-bottom: 8px; }
        .form-input { width: 100%; padding: 12px 14px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 14px; outline: none; transition: border-color 0.2s; }
        .form-input:focus { border-color: #667eea; }
        .form-textarea { min-height: 100px; resize: vertical; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .empty-state { text-align: center; padding: 60px 20px; color: #999; }
        .empty-icon { font-size: 48px; margin-bottom: 16px; }
        .empty-text { font-size: 14px; }
        .toast { display: none; position: fixed; top: 24px; right: 24px; padding: 16px 24px; border-radius: 12px; color: #fff; font-weight: 500; z-index: 3000; }
        .toast.success { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); }
        .toast.error { background: linear-gradient(135deg, #ff6b6b 0%, #ffa500 100%); }
        .toast.show { display: block; animation: slideIn 0.3s ease; }
        @keyframes slideIn { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        .qr-code-box { background: #fff; padding: 24px; border-radius: 16px; text-align: center; }
        .qr-code { width: 180px; height: 180px; margin: 0 auto 16px; background: #f8f9fa; border-radius: 12px; }
        .qr-code img { width: 100%; height: 100%; border-radius: 12px; }
        .qr-code-value { font-size: 20px; font-weight: 700; color: #1a1a2e; letter-spacing: 4px; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-brand">
            <div class="icon">⚙️</div>
            <span class="text">签到管理</span>
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><div class="nav-link active" id="nav-dashboard"><span class="nav-icon">📊</span>数据概览</div></li>
            <li class="nav-item"><div class="nav-link" id="nav-activities"><span class="nav-icon">📋</span>活动管理</div></li>
            <li class="nav-item"><div class="nav-link" id="nav-checkins"><span class="nav-icon">✅</span>签到记录</div></li>
            <li class="nav-item"><div class="nav-link" id="nav-students"><span class="nav-icon">👥</span>学生管理</div></li>
            <li class="nav-item"><div class="nav-link" id="nav-admins"><span class="nav-icon">👤</span>管理员管理</div></li>
        </ul>
        <div class="user-panel">
            <div class="user-avatar" id="user-avatar">A</div>
            <div class="user-info">
                <div class="user-name" id="user-name">管理员</div>
                <div class="user-role" id="user-role">超级管理员</div>
            </div>
            <div class="logout-btn" id="logout-btn">退出</div>
        </div>
    </div>

    <div class="main-content">
        <div id="page-dashboard" class="page-content">
            <div class="page-header">
                <h1 class="page-title">数据概览</h1>
                <p class="page-subtitle">欢迎回来，查看系统运行状态</p>
            </div>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon users">👥</div>
                    <div class="stat-value" id="stat-students">0</div>
                    <div class="stat-label">学生总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon activities">📋</div>
                    <div class="stat-value" id="stat-activities">0</div>
                    <div class="stat-label">活动总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon checkins">✅</div>
                    <div class="stat-value" id="stat-checkins">0</div>
                    <div class="stat-label">签到总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon active">🔄</div>
                    <div class="stat-value" id="stat-active">0</div>
                    <div class="stat-label">进行中活动</div>
                </div>
            </div>
            <div class="content-card">
                <div class="card-header">
                    <h2 class="card-title">近期活动</h2>
                    <button class="btn btn-primary" id="btn-create-activity">+ 新建活动</button>
                </div>
                <table class="table">
                    <thead><tr><th>活动名称</th><th>地点</th><th>状态</th><th>签到码</th><th>操作</th></tr></thead>
                    <tbody id="activity-list-body">
                        <tr><td colspan="5" class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">暂无活动</div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="page-activities" class="page-content" style="display: none;">
            <div class="page-header">
                <h1 class="page-title">活动管理</h1>
                <p class="page-subtitle">管理所有签到活动</p>
            </div>
            <div class="content-card">
                <div class="card-header">
                    <h2 class="card-title">活动列表</h2>
                    <button class="btn btn-primary" id="btn-create-activity2">+ 新建活动</button>
                </div>
                <table class="table">
                    <thead><tr><th>活动名称</th><th>地点</th><th>签到码</th><th>开始时间</th><th>结束时间</th><th>状态</th><th>操作</th></tr></thead>
                    <tbody id="activities-list-body">
                        <tr><td colspan="7" class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">暂无活动</div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="page-checkins" class="page-content" style="display: none;">
            <div class="page-header">
                <h1 class="page-title">签到记录</h1>
                <p class="page-subtitle">查看所有签到记录</p>
            </div>
            <div class="content-card">
                <table class="table">
                    <thead><tr><th>活动名称</th><th>学生姓名</th><th>学号</th><th>签到时间</th><th>状态</th></tr></thead>
                    <tbody id="checkins-list-body">
                        <tr><td colspan="5" class="empty-state"><div class="empty-icon">📋</div><div class="empty-text">暂无签到记录</div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="page-students" class="page-content" style="display: none;">
            <div class="page-header">
                <h1 class="page-title">学生管理</h1>
                <p class="page-subtitle">管理学生信息</p>
            </div>
            <div class="content-card">
                <table class="table">
                    <thead><tr><th>学号</th><th>姓名</th><th>班级</th><th>签到次数</th></tr></thead>
                    <tbody id="students-list-body">
                        <tr><td colspan="4" class="empty-state"><div class="empty-icon">👥</div><div class="empty-text">暂无学生数据</div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="page-admins" class="page-content" style="display: none;">
            <div class="page-header">
                <h1 class="page-title">管理员管理</h1>
                <p class="page-subtitle">管理系统管理员</p>
            </div>
            <div class="content-card">
                <table class="table">
                    <thead><tr><th>用户名</th><th>真实姓名</th><th>角色</th><th>部门</th></tr></thead>
                    <tbody id="admins-list-body">
                        <tr><td colspan="4" class="empty-state"><div class="empty-icon">👤</div><div class="empty-text">暂无管理员</div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal-overlay" id="create-modal">
        <div class="modal-content">
            <button class="modal-close" id="modal-close">×</button>
            <h2 class="modal-title">📋 新建活动</h2>
            <div class="form-group">
                <label class="form-label">活动名称 *</label>
                <input type="text" class="form-input" id="input-name" placeholder="请输入活动名称">
            </div>
            <div class="form-group">
                <label class="form-label">活动描述</label>
                <textarea class="form-input form-textarea" id="input-desc" placeholder="请输入活动描述"></textarea>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">地点</label>
                    <input type="text" class="form-input" id="input-location" placeholder="请输入活动地点">
                </div>
                <div class="form-group">
                    <label class="form-label">部门</label>
                    <input type="text" class="form-input" id="input-department" placeholder="请输入部门">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">签到时长(分钟)</label>
                    <input type="number" class="form-input" id="input-duration" placeholder="60" value="60">
                </div>
            </div>
            <button class="btn btn-primary" style="width: 100%; margin-top: 10px;" id="btn-submit">创建活动</button>
        </div>
    </div>

    <div class="modal-overlay" id="qr-modal">
        <div class="modal-content">
            <button class="modal-close" id="qr-close">×</button>
            <h2 class="modal-title">📱 签到二维码</h2>
            <div class="qr-code-box">
                <div class="qr-code" id="qr-code"><img id="qr-image" src="" alt="二维码"></div>
                <div class="qr-code-value" id="qr-code-value">------</div>
                <p style="color: #888; font-size: 13px; margin-top: 12px;">学生可扫码或输入签到码完成签到</p>
            </div>
            <div style="display: flex; gap: 12px; margin-top: 20px;">
                <button class="btn btn-secondary" style="flex: 1;" id="btn-refresh-code">刷新签到码</button>
                <button class="btn btn-danger" style="flex: 1;" id="btn-stop-activity">结束活动</button>
            </div>
        </div>
    </div>

    <div class="modal-overlay" id="students-modal">
        <div class="modal-content" style="max-width: 700px; max-height: 80vh; overflow: hidden;">
            <button class="modal-close" id="students-close">×</button>
            <h2 class="modal-title" id="students-modal-title">👥 活动参加人员</h2>
            <div style="max-height: 60vh; overflow-y: auto;">
                <table class="table" style="font-size: 13px;">
                    <thead><tr><th>学号</th><th>姓名</th><th>班级</th><th>签到时间</th></tr></thead>
                    <tbody id="activity-students-body">
                        <tr><td colspan="4" class="empty-state"><div class="empty-icon">👥</div><div class="empty-text">暂无签到人员</div></td></tr>
                    </tbody>
                </table>
            </div>
            <div style="margin-top: 16px; display: flex; justify-content: space-between; align-items: center;">
                <span style="color: #666; font-size: 14px;" id="students-count">共 0 人</span>
            </div>
        </div>
    </div>

    <div class="modal-overlay" id="enroll-modal">
        <div class="modal-content" style="max-width: 700px; max-height: 80vh; overflow: hidden;">
            <button class="modal-close" id="enroll-close">×</button>
            <h2 class="modal-title" id="enroll-modal-title">📝 活动报名管理</h2>
            <div style="margin-bottom: 16px;">
                <div style="margin-bottom: 16px; padding: 12px; background: #f8f9fa; border-radius: 8px;">
                    <div style="margin-bottom: 8px;">
                        <label style="font-size: 14px; font-weight: 600; color: #333;">📥 Excel导入</label>
                    </div>
                    <div style="display: flex; gap: 12px; align-items: center;">
                        <input type="file" id="excel-file" accept=".xlsx,.xls" style="flex: 1;">
                        <button class="btn btn-success btn-sm" id="btn-import-excel">导入</button>
                    </div>
                    <div style="margin-top: 8px; font-size: 12px; color: #888;">
                        Excel格式要求：包含「学号」「姓名」列，可选「班级」列
                    </div>
                </div>
                <hr style="border: none; border-top: 1px solid #eee; margin: 16px 0;">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">学号</label>
                        <input type="text" class="form-input" id="enroll-student-id" placeholder="请输入学号">
                    </div>
                    <div class="form-group">
                        <label class="form-label">姓名</label>
                        <input type="text" class="form-input" id="enroll-student-name" placeholder="请输入姓名">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">班级</label>
                    <input type="text" class="form-input" id="enroll-class-name" placeholder="请输入班级">
                </div>
                <button class="btn btn-primary" style="width: 100%;" id="btn-add-enroll">+ 添加报名</button>
            </div>
            <div style="max-height: 40vh; overflow-y: auto;">
                <table class="table" style="font-size: 13px;">
                    <thead><tr><th>学号</th><th>姓名</th><th>班级</th><th>报名时间</th><th>操作</th></tr></thead>
                    <tbody id="enrollments-body">
                        <tr><td colspan="5" class="empty-state"><div class="empty-icon">📝</div><div class="empty-text">暂无报名人员</div></td></tr>
                    </tbody>
                </table>
            </div>
            <div style="margin-top: 16px; display: flex; justify-content: space-between; align-items: center;">
                <span style="color: #666; font-size: 14px;" id="enroll-count">共 0 人</span>
            </div>
        </div>
    </div>

    <div class="modal-overlay" id="report-modal">
        <div class="modal-content" style="max-width: 800px; max-height: 85vh; overflow: hidden;">
            <button class="modal-close" id="report-close">×</button>
            <h2 class="modal-title" id="report-modal-title">📊 签到核对报告</h2>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 20px;">
                <div style="background: #f8f9fa; padding: 16px; border-radius: 12px; text-align: center;">
                    <div style="font-size: 28px; font-weight: 700; color: #667eea;">0</div>
                    <div style="font-size: 12px; color: #666;" id="report-enrolled">报名人数</div>
                </div>
                <div style="background: #f8f9fa; padding: 16px; border-radius: 12px; text-align: center;">
                    <div style="font-size: 28px; font-weight: 700; color: #43e97b;" id="report-checked">已签到</div>
                    <div style="font-size: 12px; color: #666;">签到人数</div>
                </div>
                <div style="background: #f8f9fa; padding: 16px; border-radius: 12px; text-align: center;">
                    <div style="font-size: 28px; font-weight: 700; color: #ff6b6b;" id="report-absent">0</div>
                    <div style="font-size: 12px; color: #666;">未签到</div>
                </div>
            </div>
            <div style="max-height: 55vh; overflow-y: auto;">
                <table class="table" style="font-size: 13px;">
                    <thead><tr><th>学号</th><th>姓名</th><th>班级</th><th>报名时间</th><th>签到状态</th><th>签到时间</th></tr></thead>
                    <tbody id="report-body">
                        <tr><td colspan="6" class="empty-state"><div class="empty-icon">📊</div><div class="empty-text">暂无数据</div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="toast" id="toast"></div>

    <script>
        var token = localStorage.getItem('admin_token');
        var currentActivityId = null;

        function init() {
            if (!token) { window.location.href = '/admin/login'; return; }
            loadDashboard();
            loadActivities();
            loadCheckins();
            loadStudents();
            loadAdmins();
            bindEvents();
        }

        function bindEvents() {
            document.getElementById('nav-dashboard').onclick = showDashboard;
            document.getElementById('nav-activities').onclick = showActivities;
            document.getElementById('nav-checkins').onclick = showCheckins;
            document.getElementById('nav-students').onclick = showStudents;
            document.getElementById('nav-admins').onclick = showAdmins;
            document.getElementById('logout-btn').onclick = logout;
            document.getElementById('btn-create-activity').onclick = showCreateModal;
            document.getElementById('btn-create-activity2').onclick = showCreateModal;
            document.getElementById('modal-close').onclick = closeCreateModal;
            document.getElementById('create-modal').onclick = function(e) { if (e.target === this) closeCreateModal(); };
            document.getElementById('btn-submit').onclick = submitCreate;
            document.getElementById('qr-close').onclick = closeQrModal;
            document.getElementById('qr-modal').onclick = function(e) { if (e.target === this) closeQrModal(); };
            document.getElementById('students-close').onclick = closeStudentsModal;
            document.getElementById('students-modal').onclick = function(e) { if (e.target === this) closeStudentsModal(); };
            document.getElementById('enroll-close').onclick = closeEnrollModal;
            document.getElementById('enroll-modal').onclick = function(e) { if (e.target === this) closeEnrollModal(); };
            document.getElementById('btn-add-enroll').onclick = addEnroll;
            document.getElementById('btn-import-excel').onclick = importExcel;
            document.getElementById('report-close').onclick = closeReportModal;
            document.getElementById('report-modal').onclick = function(e) { if (e.target === this) closeReportModal(); };
        }

        function showDashboard() {
            setActiveNav('nav-dashboard');
            showPage('page-dashboard');
        }

        function showActivities() {
            setActiveNav('nav-activities');
            showPage('page-activities');
            loadActivities();
        }

        function showCheckins() {
            setActiveNav('nav-checkins');
            showPage('page-checkins');
            loadCheckins();
        }

        function showStudents() {
            setActiveNav('nav-students');
            showPage('page-students');
            loadStudents();
        }

        function showAdmins() {
            setActiveNav('nav-admins');
            showPage('page-admins');
            loadAdmins();
        }

        function setActiveNav(id) {
            document.querySelectorAll('.nav-link').forEach(el => el.classList.remove('active'));
            document.getElementById(id).classList.add('active');
        }

        function showPage(id) {
            document.querySelectorAll('.page-content').forEach(el => el.style.display = 'none');
            document.getElementById(id).style.display = 'block';
        }

        function logout() {
            localStorage.removeItem('admin_token');
            window.location.href = '/admin/login';
        }

        function showToast(msg, type = 'success') {
            var toast = document.getElementById('toast');
            toast.textContent = msg;
            toast.className = 'toast ' + type + ' show';
            setTimeout(() => toast.classList.remove('show'), 3000);
        }

        function loadDashboard() {
            fetch('/api/admin/stats?token=' + token).then(r => r.json()).then(d => {
                document.getElementById('stat-students').textContent = d.students || 0;
                document.getElementById('stat-activities').textContent = d.activities || 0;
                document.getElementById('stat-checkins').textContent = d.checkins || 0;
                document.getElementById('stat-active').textContent = d.active_activities || 0;
            });
        }

        function loadActivities() {
            fetch('/api/admin/activities?token=' + token).then(r => r.json()).then(d => {
                var html = '';
                if (!d.items || d.items.length === 0) {
                    html = '<tr><td colspan="7" class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">暂无活动</div></td></tr>';
                } else {
                    d.items.forEach(a => {
                        var status = a.is_active ? '<span class="badge badge-success">进行中</span>' : '<span class="badge badge-info">已结束</span>';
                        var ops = a.is_active 
                            ? `<button class="btn btn-sm btn-secondary" onclick="showQrCode(${a.id}, '${a.code}')">📱 签到码</button> <button class="btn btn-sm btn-info" onclick="showEnrollments(${a.id})">📝 报名管理</button> <button class="btn btn-sm btn-primary" onclick="showCheckinReport(${a.id})">� 核对签到</button>`
                            : `<button class="btn btn-sm btn-success" onclick="startActivity(${a.id})">▶️ 开始</button> <button class="btn btn-sm btn-info" onclick="showEnrollments(${a.id})">📝 报名管理</button> <button class="btn btn-sm btn-primary" onclick="showCheckinReport(${a.id})">� 核对签到</button>`;
                        html += `<tr><td>${a.name}</td><td>${a.location || '-'}</td><td>${a.code}</td><td>${a.checkin_start || '-'}</td><td>${a.checkin_end || '-'}</td><td>${status}</td><td>${ops}</td></tr>`;
                    });
                }
                document.getElementById('activities-list-body').innerHTML = html;
                document.getElementById('activity-list-body').innerHTML = html.replace('colspan="7"', 'colspan="5"');
            });
        }

        function loadCheckins() {
            fetch('/api/admin/checkins?token=' + token).then(r => r.json()).then(d => {
                var html = '';
                if (!d.items || d.items.length === 0) {
                    html = '<tr><td colspan="5" class="empty-state"><div class="empty-icon">📋</div><div class="empty-text">暂无签到记录</div></td></tr>';
                } else {
                    d.items.forEach(c => {
                        html += `<tr><td>${c.activity_name || '-'}</td><td>${c.student_name}</td><td>${c.student_id}</td><td>${c.checkin_time}</td><td><span class="badge badge-success">已签到</span></td></tr>`;
                    });
                }
                document.getElementById('checkins-list-body').innerHTML = html;
            });
        }

        function loadStudents() {
            fetch('/api/admin/students?token=' + token).then(r => r.json()).then(d => {
                var html = '';
                if (!d.items || d.items.length === 0) {
                    html = '<tr><td colspan="4" class="empty-state"><div class="empty-icon">👥</div><div class="empty-text">暂无学生数据</div></td></tr>';
                } else {
                    d.items.forEach(s => {
                        html += `<tr><td>${s.student_id}</td><td>${s.name}</td><td>${s.class_name || '-'}</td><td>${s.checkin_count || 0}</td></tr>`;
                    });
                }
                document.getElementById('students-list-body').innerHTML = html;
            });
        }

        function loadAdmins() {
            fetch('/api/admin/admins?token=' + token).then(r => r.json()).then(d => {
                var html = '';
                if (!d.items || d.items.length === 0) {
                    html = '<tr><td colspan="4" class="empty-state"><div class="empty-icon">👤</div><div class="empty-text">暂无管理员</div></td></tr>';
                } else {
                    d.items.forEach(a => {
                        var role = a.is_super ? '超级管理员' : '管理员';
                        html += `<tr><td>${a.username}</td><td>${a.real_name}</td><td>${role}</td><td>${a.department || '-'}</td></tr>`;
                    });
                }
                document.getElementById('admins-list-body').innerHTML = html;
            });
        }

        function showCreateModal() {
            document.getElementById('input-name').value = '';
            document.getElementById('input-desc').value = '';
            document.getElementById('input-location').value = '';
            document.getElementById('input-department').value = '';
            document.getElementById('input-duration').value = '60';
            document.getElementById('create-modal').classList.add('active');
        }

        function closeCreateModal() {
            document.getElementById('create-modal').classList.remove('active');
        }

        function submitCreate() {
            var name = document.getElementById('input-name').value.trim();
            if (!name) { showToast('请输入活动名称', 'error'); return; }
            
            fetch('/api/admin/activities', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: name,
                    description: document.getElementById('input-desc').value,
                    location: document.getElementById('input-location').value,
                    department: document.getElementById('input-department').value,
                    duration: parseInt(document.getElementById('input-duration').value) || 60
                })
            }).then(r => r.json()).then(d => {
                if (d.success) {
                    showToast('活动创建成功！');
                    closeCreateModal();
                    loadDashboard();
                    loadActivities();
                } else {
                    showToast(d.message || '创建失败', 'error');
                }
            }).catch(e => showToast('创建失败', 'error'));
        }

        function startActivity(id) {
            fetch('/api/admin/activities/' + id + '/start?token=' + token, { method: 'POST' })
            .then(r => {
                if (!r.ok) throw new Error('请求失败');
                return r.json();
            }).then(d => {
                showToast('活动已开始！');
                loadDashboard();
                loadActivities();
            }).catch(e => {
                showToast('操作失败', 'error');
            });
        }

        function showQrCode(id, code) {
            currentActivityId = id;
            document.getElementById('qr-code-value').textContent = code;
            document.getElementById('qr-image').src = '/api/admin/activities/' + id + '/qr-code?token=' + token + '&t=' + Date.now();
            document.getElementById('qr-modal').classList.add('active');
        }

        function closeQrModal() {
            document.getElementById('qr-modal').classList.remove('active');
            currentActivityId = null;
        }

        function showActivityStudents(activityId) {
            fetch('/api/admin/activities/' + activityId + '/students?token=' + token)
            .then(r => r.json()).then(d => {
                var html = '';
                if (!d.items || d.items.length === 0) {
                    html = '<tr><td colspan="4" class="empty-state"><div class="empty-icon">👥</div><div class="empty-text">暂无签到人员</div></td></tr>';
                } else {
                    d.items.forEach(s => {
                        html += `<tr><td>${s.student_id}</td><td>${s.student_name}</td><td>${s.class_name || '-'}</td><td>${s.checkin_time || '-'}</td></tr>`;
                    });
                }
                document.getElementById('activity-students-body').innerHTML = html;
                document.getElementById('students-count').textContent = '共 ' + (d.items ? d.items.length : 0) + ' 人';
                document.getElementById('students-modal-title').textContent = '👥 ' + (d.activity_name || '活动') + ' - 参加人员';
                document.getElementById('students-modal').classList.add('active');
            }).catch(e => showToast('加载失败', 'error'));
        }

        function closeStudentsModal() {
            document.getElementById('students-modal').classList.remove('active');
        }

        function showEnrollments(activityId) {
            currentActivityId = activityId;
            fetch('/api/admin/activities/' + activityId + '/enrollments?token=' + token)
            .then(r => r.json()).then(d => {
                var html = '';
                if (!d.items || d.items.length === 0) {
                    html = '<tr><td colspan="5" class="empty-state"><div class="empty-icon">📝</div><div class="empty-text">暂无报名人员</div></td></tr>';
                } else {
                    d.items.forEach(e => {
                        html += `<tr><td>${e.student_id}</td><td>${e.student_name}</td><td>${e.class_name || '-'}</td><td>${e.enrolled_at}</td><td><button class="btn btn-sm btn-danger" onclick="deleteEnroll(${e.id})">删除</button></td></tr>`;
                    });
                }
                document.getElementById('enrollments-body').innerHTML = html;
                document.getElementById('enroll-count').textContent = '共 ' + (d.items ? d.items.length : 0) + ' 人';
                document.getElementById('enroll-modal-title').textContent = '📝 ' + (d.activity_name || '活动') + ' - 报名管理';
                document.getElementById('enroll-student-id').value = '';
                document.getElementById('enroll-student-name').value = '';
                document.getElementById('enroll-class-name').value = '';
                document.getElementById('enroll-modal').classList.add('active');
            }).catch(e => showToast('加载失败', 'error'));
        }

        function closeEnrollModal() {
            document.getElementById('enroll-modal').classList.remove('active');
            currentActivityId = null;
        }

        function addEnroll() {
            var studentId = document.getElementById('enroll-student-id').value.trim();
            var studentName = document.getElementById('enroll-student-name').value.trim();
            if (!studentId || !studentName) {
                showToast('请填写学号和姓名', 'error');
                return;
            }
            fetch('/api/admin/activities/' + currentActivityId + '/enroll?token=' + token, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    student_id: studentId,
                    student_name: studentName,
                    class_name: document.getElementById('enroll-class-name').value
                })
            }).then(r => r.json()).then(d => {
                if (d.message) {
                    showToast(d.message);
                    document.getElementById('enroll-student-id').value = '';
                    document.getElementById('enroll-student-name').value = '';
                    document.getElementById('enroll-class-name').value = '';
                    showEnrollments(currentActivityId);
                } else {
                    showToast(d.detail || '添加失败', 'error');
                }
            }).catch(e => showToast('添加失败', 'error'));
        }

        function deleteEnroll(enrollId) {
            if (!confirm('确定要删除该报名记录吗？')) return;
            fetch('/api/admin/activities/' + currentActivityId + '/enrollments/' + enrollId + '?token=' + token, {
                method: 'DELETE'
            }).then(r => r.json()).then(d => {
                if (d.message) {
                    showToast(d.message);
                    showEnrollments(currentActivityId);
                } else {
                    showToast('删除失败', 'error');
                }
            });
        }

        function importExcel() {
            var fileInput = document.getElementById('excel-file');
            if (!fileInput.files || fileInput.files.length === 0) {
                showToast('请先选择Excel文件', 'error');
                return;
            }
            
            var formData = new FormData();
            formData.append('file', fileInput.files[0]);
            
            fetch('/api/admin/activities/' + currentActivityId + '/import-excel?token=' + token, {
                method: 'POST',
                body: formData
            }).then(r => {
                if (!r.ok) {
                    return r.json().then(err => { throw err; });
                }
                return r.json();
            }).then(d => {
                if (d.success) {
                    var msg = '导入成功：新增 ' + d.success_count + ' 人';
                    if (d.skip_count > 0) {
                        msg += '，跳过 ' + d.skip_count + ' 人';
                    }
                    if (d.errors && d.errors.length > 0) {
                        msg += '，错误 ' + d.errors.length + ' 条';
                        console.log('导入错误：', d.errors);
                    }
                    showToast(msg, 'success');
                    fileInput.value = '';
                    showEnrollments(currentActivityId);
                } else {
                    showToast(d.detail || '导入失败', 'error');
                }
            }).catch(e => {
                console.error(e);
                showToast(e.detail || '导入失败', 'error');
            });
        }

        function showCheckinReport(activityId) {
            fetch('/api/admin/activities/' + activityId + '/checkin-report?token=' + token)
            .then(r => r.json()).then(d => {
                var checkedItems = d.items.filter(i => i.is_checked_in);
                var absentItems = d.items.filter(i => !i.is_checked_in);
                
                document.getElementById('report-enrolled').textContent = d.total_enrolled + ' 报名人数';
                document.getElementById('report-checked').textContent = d.total_checked_in;
                document.getElementById('report-absent').textContent = d.absent_count;
                
                var html = '';
                
                if (checkedItems.length > 0) {
                    html += '<tr style="background: #e8f5e9;"><td colspan="6" style="padding: 12px; font-weight: 600; color: #2e7d32;">✅ 已签到名单 (' + checkedItems.length + '人)</td></tr>';
                    checkedItems.forEach(item => {
                        html += '<tr style="background: #f1f8e9;"><td>' + item.student_id + '</td><td>' + item.student_name + '</td><td>' + (item.class_name || '-') + '</td><td>' + item.enrolled_at + '</td><td><span class="badge badge-success">已签到</span></td><td>' + (item.checkin_time || '-') + '</td></tr>';
                    });
                }
                
                if (absentItems.length > 0) {
                    html += '<tr style="background: #ffebee;"><td colspan="6" style="padding: 12px; font-weight: 600; color: #c62828;">❌ 未签到名单 (' + absentItems.length + '人)</td></tr>';
                    absentItems.forEach(item => {
                        html += '<tr style="background: #fff3e0;"><td>' + item.student_id + '</td><td>' + item.student_name + '</td><td>' + (item.class_name || '-') + '</td><td>' + item.enrolled_at + '</td><td><span class="badge badge-danger">未签到</span></td><td>-</td></tr>';
                    });
                }
                
                if (!d.items || d.items.length === 0) {
                    html = '<tr><td colspan="6" class="empty-state"><div class="empty-icon">📊</div><div class="empty-text">暂无数据</div></td></tr>';
                }
                
                document.getElementById('report-body').innerHTML = html;
                document.getElementById('report-modal-title').textContent = '📊 ' + (d.activity_name || '活动') + ' - 签到核对报告';
                document.getElementById('report-modal').classList.add('active');
            }).catch(e => showToast('加载失败', 'error'));
        }

        function closeReportModal() {
            document.getElementById('report-modal').classList.remove('active');
        }

        document.getElementById('btn-refresh-code').onclick = function() {
            if (!currentActivityId) return;
            fetch('/api/admin/activities/' + currentActivityId + '/refresh-code?token=' + token, { method: 'POST' })
            .then(r => r.json()).then(d => {
                if (d.code) {
                    document.getElementById('qr-code-value').textContent = d.code;
                    document.getElementById('qr-image').src = '/api/admin/activities/' + currentActivityId + '/qr-code?token=' + token + '&t=' + Date.now();
                    showToast('签到码已刷新！');
                    loadActivities();
                } else {
                    showToast('刷新失败', 'error');
                }
            });
        };

        document.getElementById('btn-stop-activity').onclick = function() {
            if (!currentActivityId) return;
            if (!confirm('确定要结束此活动吗？')) return;
            fetch('/api/admin/activities/' + currentActivityId + '/stop?token=' + token, { method: 'POST' })
            .then(r => r.json()).then(d => {
                if (d.success) {
                    showToast('活动已结束！');
                    closeQrModal();
                    loadDashboard();
                    loadActivities();
                } else {
                    showToast(d.message || '操作失败', 'error');
                }
            });
        };

        init();
    </script>
</body>
</html>
"""
