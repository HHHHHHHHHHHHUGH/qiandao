"""管理员后台 - 移动端版本"""

ADMIN_MOBILE_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>签到管理</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f5f5f5; min-height: 100vh; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; color: #fff; }
        .header-top { display: flex; align-items: center; justify-content: space-between; }
        .header-title { font-size: 20px; font-weight: 700; }
        .logout-btn { padding: 8px 16px; background: rgba(255,255,255,.2); border: none; border-radius: 8px; color: #fff; font-size: 14px; }
        .user-info { margin-top: 15px; display: flex; align-items: center; gap: 12px; }
        .user-avatar { width: 45px; height: 45px; border-radius: 50%; background: rgba(255,255,255,.3); display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: 600; }
        .user-name { font-size: 16px; font-weight: 600; }
        .user-role { font-size: 12px; opacity: .8; }
        
        .nav-tabs { display: flex; background: #fff; padding: 10px; gap: 8px; border-bottom: 1px solid #eee; }
        .nav-tab { flex: 1; padding: 12px; text-align: center; border-radius: 10px; font-size: 14px; font-weight: 500; color: #666; background: #f5f5f5; border: none; }
        .nav-tab.active { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; }
        
        .content { padding: 15px; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 20px; }
        .stat-card { background: #fff; padding: 20px; border-radius: 16px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,.05); }
        .stat-value { font-size: 32px; font-weight: 700; color: #1a1a2e; }
        .stat-label { font-size: 12px; color: #888; margin-top: 4px; }
        
        .section-title { font-size: 16px; font-weight: 700; color: #1a1a2e; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between; }
        .add-btn { font-size: 13px; color: #667eea; font-weight: 500; }
        
        .activity-list { margin-bottom: 20px; }
        .activity-card { background: #fff; padding: 18px; border-radius: 16px; margin-bottom: 12px; box-shadow: 0 2px 8px rgba(0,0,0,.05); }
        .activity-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }
        .activity-name { font-size: 16px; font-weight: 600; color: #1a1a2e; }
        .activity-status { padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; }
        .status-active { background: #e8f5e9; color: #2e7d32; }
        .status-inactive { background: #e3f2fd; color: #1976d2; }
        .activity-meta { font-size: 13px; color: #888; margin-bottom: 12px; }
        .activity-code { display: inline-block; padding: 8px 16px; background: #f8f9fa; border-radius: 8px; font-size: 16px; font-weight: 700; letter-spacing: 3px; color: #667eea; }
        .activity-actions { display: flex; gap: 10px; margin-top: 15px; }
        .act-btn { flex: 1; padding: 12px; border: none; border-radius: 10px; font-size: 14px; font-weight: 600; }
        .btn-success { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: #fff; }
        .btn-secondary { background: #f0f0f0; color: #333; }
        .btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; }
        .btn-danger { background: linear-gradient(135deg, #ff6b6b 0%, #ffa500 100%); color: #fff; }
        
        .empty-state { text-align: center; padding: 40px 20px; color: #999; }
        .empty-icon { font-size: 48px; margin-bottom: 12px; }
        
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,.5); justify-content: center; align-items: center; z-index: 1000; }
        .modal-overlay.show { display: flex; }
        .modal-content { background: #fff; width: 90%; max-width: 380px; border-radius: 20px; padding: 25px; position: relative; }
        .modal-close { position: absolute; top: 15px; right: 15px; width: 32px; height: 32px; border: none; border-radius: 50%; background: #f0f0f0; font-size: 18px; }
        .modal-title { font-size: 18px; font-weight: 700; color: #1a1a2e; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-label { display: block; font-size: 14px; font-weight: 600; color: #333; margin-bottom: 6px; }
        .form-input { width: 100%; padding: 14px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 15px; }
        .form-textarea { min-height: 80px; resize: vertical; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .modal-btn { width: 100%; padding: 14px; border: none; border-radius: 10px; font-size: 16px; font-weight: 600; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; }
        
        .qr-code-box { text-align: center; margin-bottom: 20px; }
        .qr-code { width: 200px; height: 200px; margin: 0 auto; background: #f8f9fa; border-radius: 16px; padding: 10px; }
        .qr-code img { width: 100%; height: 100%; }
        .qr-code-value { font-size: 22px; font-weight: 700; letter-spacing: 4px; color: #1a1a2e; margin-top: 12px; }
        
        .report-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px; }
        .report-item { background: #f8f9fa; padding: 15px; border-radius: 12px; text-align: center; }
        .report-num { font-size: 24px; font-weight: 700; }
        .report-num.enrolled { color: #667eea; }
        .report-num.checked { color: #43e97b; }
        .report-num.absent { color: #ff6b6b; }
        .report-label { font-size: 11px; color: #888; margin-top: 4px; }
        
        .list-box { max-height: 40vh; overflow-y: auto; }
        .list-table { width: 100%; font-size: 13px; }
        .list-table th { background: #f8f9fa; padding: 10px; text-align: left; font-weight: 600; color: #666; font-size: 12px; }
        .list-table td { padding: 10px; border-bottom: 1px solid #f0f0f0; color: #333; }
        .row-checked { background: #f1f8e9; }
        .row-absent { background: #fff3e0; }
        
        .excel-upload { margin-bottom: 15px; padding: 15px; background: #f8f9fa; border-radius: 10px; }
        .upload-btn { padding: 10px 20px; background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: #fff; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; }
        
        .toast { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0,0,0,.8); color: #fff; padding: 16px 32px; border-radius: 10px; font-size: 15px; z-index: 2000; }
        .toast.show { display: block; }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-top">
            <div class="header-title">签到管理</div>
            <button class="logout-btn" id="logoutBtn">退出</button>
        </div>
        <div class="user-info">
            <div class="user-avatar" id="avatar">A</div>
            <div>
                <div class="user-name" id="name">管理员</div>
                <div class="user-role" id="role">超级管理员</div>
            </div>
        </div>
    </div>
    
    <div class="nav-tabs">
        <button class="nav-tab active" id="tab-dashboard-btn">📊 概览</button>
        <button class="nav-tab" id="tab-activities-btn">📋 活动</button>
        <button class="nav-tab" id="tab-records-btn">✅ 记录</button>
    </div>
    
    <div class="content">
        <div id="tab-dashboard">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value" id="stat-students">0</div>
                    <div class="stat-label">学生总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="stat-activities">0</div>
                    <div class="stat-label">活动总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="stat-checkins">0</div>
                    <div class="stat-label">签到总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="stat-active">0</div>
                    <div class="stat-label">进行中</div>
                </div>
            </div>
            
            <div class="section-title">
                <span>近期活动</span>
                <span class="add-btn" id="add-activity-btn">+ 新建</span>
            </div>
            <div class="activity-list" id="dashboard-activities">
                <div class="empty-state"><div class="empty-icon">📭</div><div>暂无活动</div></div>
            </div>
        </div>
        
        <div id="tab-activities" style="display: none;">
            <div class="section-title">
                <span>活动列表</span>
                <span class="add-btn" id="add-activity-btn2">+ 新建</span>
            </div>
            <div class="activity-list" id="activity-list">
                <div class="empty-state"><div class="empty-icon">📭</div><div>暂无活动</div></div>
            </div>
        </div>
        
        <div id="tab-records" style="display: none;">
            <div class="section-title">签到记录</div>
            <div id="records-list">
                <div class="empty-state"><div class="empty-icon">✅</div><div>暂无记录</div></div>
            </div>
        </div>
    </div>
    
    <div class="modal-overlay" id="create-modal">
        <div class="modal-content">
            <button class="modal-close" id="close-create-modal">×</button>
            <div class="modal-title">📋 新建活动</div>
            <div class="form-group">
                <label class="form-label">活动名称 *</label>
                <input type="text" class="form-input" id="input-name" placeholder="请输入活动名称">
            </div>
            <div class="form-group">
                <label class="form-label">活动描述</label>
                <textarea class="form-input form-textarea" id="input-desc" placeholder="请输入活动描述"></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">地点</label>
                <input type="text" class="form-input" id="input-location" placeholder="请输入活动地点">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">时长(分钟)</label>
                    <input type="number" class="form-input" id="input-duration" value="60">
                </div>
            </div>
            
            <div class="form-group" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee;">
                <label class="form-label">📍 定位签到设置</label>
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                    <input type="checkbox" id="input-enable-location" style="width: 20px; height: 20px;">
                    <label for="input-enable-location" style="font-weight: 600; color: #333;">启用定位签到</label>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">纬度</label>
                        <input type="text" class="form-input" id="input-latitude" placeholder="如: 30.5928">
                    </div>
                    <div class="form-group">
                        <label class="form-label">经度</label>
                        <input type="text" class="form-input" id="input-longitude" placeholder="如: 114.3055">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">有效范围(米)</label>
                    <input type="number" class="form-input" id="input-radius" value="100" placeholder="签到半径">
                </div>
            </div>
            
            <div class="form-group" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee;">
                <label class="form-label">🔢 验证码设置</label>
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                    <input type="checkbox" id="input-enable-captcha" style="width: 20px; height: 20px;">
                    <label for="input-enable-captcha" style="font-weight: 600; color: #333;">启用验证码</label>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">验证码位数</label>
                        <input type="number" class="form-input" id="input-captcha-length" value="4" min="4" max="8">
                    </div>
                    <div class="form-group">
                        <label class="form-label">刷新间隔(秒)</label>
                        <input type="number" class="form-input" id="input-captcha-interval" value="60" min="10" max="300">
                    </div>
                </div>
            </div>
            
            <button class="modal-btn" id="submit-create-btn">创建活动</button>
        </div>
    </div>
    
    <div class="modal-overlay" id="qr-modal">
        <div class="modal-content">
            <button class="modal-close" id="close-qr-modal">×</button>
            <div class="modal-title">📱 签到二维码</div>
            <div class="qr-code-box">
                <div class="qr-code" id="qr-code"><img id="qr-image" src="" alt="二维码"></div>
                <div class="qr-code-value" id="qr-code-value">------</div>
            </div>
            <div style="display: flex; gap: 10px;">
                <button class="act-btn btn-secondary" id="refresh-code-btn">🔄 刷新</button>
                <button class="act-btn btn-danger" id="stop-activity-btn">⏹️ 结束</button>
            </div>
        </div>
    </div>
    
    <div class="modal-overlay" id="enroll-modal">
        <div class="modal-content">
            <button class="modal-close" id="close-enroll-modal">×</button>
            <div class="modal-title">📝 报名管理</div>
            <div class="excel-upload">
                <input type="file" id="excel-file" accept=".xlsx,.xls" style="display: none;">
                <button class="upload-btn" id="upload-excel-btn">📥 导入Excel</button>
                <div style="font-size: 12px; color: #888; margin-top: 8px;">格式：学号、姓名、班级(可选)</div>
            </div>
            <div class="form-row">
                <input type="text" class="form-input" id="enroll-id" placeholder="学号">
                <input type="text" class="form-input" id="enroll-name" placeholder="姓名">
            </div>
            <input type="text" class="form-input" id="enroll-class" placeholder="班级(可选)" style="margin-bottom: 10px;">
            <button class="modal-btn" id="add-enroll-btn">+ 添加报名</button>
            <div class="list-box" style="margin-top: 15px;">
                <table class="list-table">
                    <thead><tr><th>学号</th><th>姓名</th><th>操作</th></tr></thead>
                    <tbody id="enroll-list">
                        <tr><td colspan="3" style="text-align: center; color: #999;">暂无报名</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="modal-overlay" id="report-modal">
        <div class="modal-content">
            <button class="modal-close" id="close-report-modal">×</button>
            <div class="modal-title">📊 签到核对</div>
            <div class="report-grid">
                <div class="report-item"><div class="report-num enrolled" id="report-enrolled">0</div><div class="report-label">报名人数</div></div>
                <div class="report-item"><div class="report-num checked" id="report-checked">0</div><div class="report-label">已签到</div></div>
                <div class="report-item"><div class="report-num absent" id="report-absent">0</div><div class="report-label">未签到</div></div>
            </div>
            <div class="list-box">
                <table class="list-table">
                    <thead><tr><th>学号</th><th>姓名</th><th>状态</th></tr></thead>
                    <tbody id="report-list">
                        <tr><td colspan="3" style="text-align: center; color: #999;">暂无数据</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="toast" id="toast"></div>
    
    <script>
        var token = null;
        var currentActivityId = null;
        
        function ready(fn) {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', fn);
            } else {
                fn();
            }
        }
        
        function showToast(msg) {
            var t = document.getElementById('toast');
            t.textContent = msg;
            t.classList.add('show');
            setTimeout(function() {
                t.classList.remove('show');
            }, 2000);
        }
        
        function closeModal(id) {
            document.getElementById(id).classList.remove('show');
        }
        
        function logout() {
            localStorage.removeItem('admin_token');
            window.location.href = '/admin/login';
        }
        
        function showTab(tab) {
            document.querySelectorAll('.nav-tab').forEach(function(el) {
                el.classList.remove('active');
            });
            document.getElementById('tab-' + tab + '-btn').classList.add('active');
            document.getElementById('tab-dashboard').style.display = 'none';
            document.getElementById('tab-activities').style.display = 'none';
            document.getElementById('tab-records').style.display = 'none';
            document.getElementById('tab-' + tab).style.display = 'block';
            if (tab === 'activities') loadActivities();
            if (tab === 'records') loadRecords();
        }
        
        function loadUser() {
            fetch('/api/admin/me?token=' + token).then(function(r) {
                return r.json();
            }).then(function(d) {
                if (d.id) {
                    document.getElementById('avatar').textContent = d.real_name.charAt(0);
                    document.getElementById('name').textContent = d.real_name;
                    document.getElementById('role').textContent = d.is_super ? '超级管理员' : '部门管理员';
                }
            }).catch(function(e) {
                console.log('loadUser error:', e);
            });
        }
        
        function loadDashboard() {
            fetch('/api/admin/stats?token=' + token).then(function(r) {
                return r.json();
            }).then(function(d) {
                document.getElementById('stat-students').textContent = d.students || 0;
                document.getElementById('stat-activities').textContent = d.activities || 0;
                document.getElementById('stat-checkins').textContent = d.checkins || 0;
                document.getElementById('stat-active').textContent = d.active_activities || 0;
            }).catch(function(e) {
                console.log('loadDashboard error:', e);
            });
        }
        
        function loadActivities() {
            fetch('/api/admin/activities?token=' + token).then(function(r) {
                return r.json();
            }).then(function(d) {
                if (!d.items || d.items.length === 0) {
                    document.getElementById('activity-list').innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div>暂无活动</div></div>';
                    document.getElementById('dashboard-activities').innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div>暂无活动</div></div>';
                    return;
                }
                var html = '';
                for (var i = 0; i < d.items.length; i++) {
                    var a = d.items[i];
                    var status = a.is_active ? '<span class="activity-status status-active">进行中</span>' : '<span class="activity-status status-inactive">未开始</span>';
                    var startBtn = a.is_active ? 
                        '<button class="act-btn btn-secondary" onclick="showQrCode(' + a.id + ', \'' + a.code + '\')">📱 签到码</button>' : 
                        '<button class="act-btn btn-success" onclick="startActivity(' + a.id + ')">▶️ 开始</button>';
                    html += '<div class="activity-card">' +
                        '<div class="activity-header">' +
                        '<div class="activity-name">' + a.name + '</div>' +
                        status +
                        '</div>' +
                        '<div class="activity-meta">' + (a.location || '') + ' | ' + (a.checkin_start || '') + '</div>' +
                        '<div class="activity-code">' + a.code + '</div>' +
                        '<div class="activity-actions">' +
                        startBtn +
                        '<button class="act-btn btn-secondary" onclick="showEnrollments(' + a.id + ')">📝 报名</button>' +
                        '<button class="act-btn btn-primary" onclick="showReport(' + a.id + ')">📊 核对</button>' +
                        '</div>' +
                        '</div>';
                }
                document.getElementById('activity-list').innerHTML = html;
                document.getElementById('dashboard-activities').innerHTML = html;
            }).catch(function(e) {
                console.log('loadActivities error:', e);
            });
        }
        
        function loadRecords() {
            fetch('/api/admin/checkins?token=' + token).then(function(r) {
                return r.json();
            }).then(function(d) {
                if (!d.items || d.items.length === 0) {
                    document.getElementById('records-list').innerHTML = '<div class="empty-state"><div class="empty-icon">✅</div><div>暂无记录</div></div>';
                    return;
                }
                var html = '';
                var items = d.items.slice(0, 20);
                for (var i = 0; i < items.length; i++) {
                    var c = items[i];
                    html += '<div class="activity-card" style="padding: 15px;">' +
                        '<div style="font-weight: 600; color: #1a1a2e;">' + c.activity_name + '</div>' +
                        '<div style="font-size: 14px; color: #666; margin-top: 4px;">' + c.student_name + ' | ' + c.student_id + '</div>' +
                        '<div style="font-size: 12px; color: #999; margin-top: 4px;">' + c.checkin_time + '</div>' +
                        '</div>';
                }
                document.getElementById('records-list').innerHTML = html;
            }).catch(function(e) {
                console.log('loadRecords error:', e);
            });
        }
        
        function showCreateModal() {
            document.getElementById('input-name').value = '';
            document.getElementById('input-desc').value = '';
            document.getElementById('input-location').value = '';
            document.getElementById('input-duration').value = '60';
            document.getElementById('input-enable-location').checked = false;
            document.getElementById('input-latitude').value = '';
            document.getElementById('input-longitude').value = '';
            document.getElementById('input-radius').value = '100';
            document.getElementById('input-enable-captcha').checked = false;
            document.getElementById('input-captcha-length').value = '4';
            document.getElementById('input-captcha-interval').value = '60';
            document.getElementById('create-modal').classList.add('show');
        }
        
        function submitCreate() {
            var name = document.getElementById('input-name').value.trim();
            if (!name) {
                showToast('请输入活动名称');
                return;
            }
            
            var data = {
                name: name,
                description: document.getElementById('input-desc').value,
                location: document.getElementById('input-location').value,
                checkin_duration: parseInt(document.getElementById('input-duration').value) || 60,
                
                enable_location_check: document.getElementById('input-enable-location').checked,
                location_latitude: document.getElementById('input-latitude').value ? parseFloat(document.getElementById('input-latitude').value) : null,
                location_longitude: document.getElementById('input-longitude').value ? parseFloat(document.getElementById('input-longitude').value) : null,
                location_radius: parseInt(document.getElementById('input-radius').value) || 100,
                
                enable_captcha: document.getElementById('input-enable-captcha').checked,
                captcha_length: parseInt(document.getElementById('input-captcha-length').value) || 4,
                captcha_refresh_interval: parseInt(document.getElementById('input-captcha-interval').value) || 60
            };
            
            fetch('/api/admin/activities', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            }).then(function(r) {
                if (!r.ok) {
                    return r.json().then(function(err) {
                        throw new Error(err.detail || '请求失败');
                    });
                }
                return r.json();
            }).then(function(d) {
                showToast('活动创建成功！');
                closeModal('create-modal');
                loadDashboard();
                loadActivities();
            }).catch(function(e) {
                showToast('创建失败: ' + e.message);
                console.log('创建活动错误:', e);
            });
        }
        
        function startActivity(id) {
            fetch('/api/admin/activities/' + id + '/start?token=' + token, { method: 'POST' })
            .then(function(r) {
                return r.json();
            }).then(function(d) {
                showToast('活动已开始！');
                loadDashboard();
                loadActivities();
            }).catch(function(e) {
                showToast('操作失败');
            });
        }
        
        function showQrCode(id, code) {
            currentActivityId = id;
            document.getElementById('qr-code-value').textContent = code;
            document.getElementById('qr-image').src = '/api/admin/activities/' + id + '/qr-code?token=' + token + '&t=' + Date.now();
            document.getElementById('qr-modal').classList.add('show');
        }
        
        function refreshCode() {
            fetch('/api/admin/activities/' + currentActivityId + '/refresh-code?token=' + token, { method: 'POST' })
            .then(function(r) {
                return r.json();
            }).then(function(d) {
                document.getElementById('qr-code-value').textContent = d.code;
                document.getElementById('qr-image').src = '/api/admin/activities/' + currentActivityId + '/qr-code?token=' + token + '&t=' + Date.now();
                showToast('签到码已刷新！');
                loadActivities();
            }).catch(function(e) {
                showToast('刷新失败');
            });
        }
        
        function stopActivity() {
            if (!confirm('确定要结束活动吗？')) return;
            fetch('/api/admin/activities/' + currentActivityId + '/stop?token=' + token, { method: 'POST' })
            .then(function(r) {
                return r.json();
            }).then(function(d) {
                showToast('活动已结束！');
                closeModal('qr-modal');
                loadDashboard();
                loadActivities();
            }).catch(function(e) {
                showToast('操作失败');
            });
        }
        
        function showEnrollments(id) {
            currentActivityId = id;
            fetch('/api/admin/activities/' + id + '/enrollments?token=' + token).then(function(r) {
                return r.json();
            }).then(function(d) {
                var html = '';
                if (!d.items || d.items.length === 0) {
                    html = '<tr><td colspan="3" style="text-align: center; color: #999;">暂无报名</td></tr>';
                } else {
                    for (var i = 0; i < d.items.length; i++) {
                        var e = d.items[i];
                        html += '<tr><td>' + e.student_id + '</td><td>' + e.student_name + '</td><td><button style="color: #ff6b6b; border: none; background: none; font-size: 12px;" onclick="deleteEnroll(' + e.id + ')">删除</button></td></tr>';
                    }
                }
                document.getElementById('enroll-list').innerHTML = html;
                document.getElementById('enroll-modal').classList.add('show');
            }).catch(function(e) {
                console.log('showEnrollments error:', e);
            });
        }
        
        function addEnroll() {
            var sid = document.getElementById('enroll-id').value.trim();
            var name = document.getElementById('enroll-name').value.trim();
            if (!sid || !name) {
                showToast('请填写学号和姓名');
                return;
            }
            fetch('/api/admin/activities/' + currentActivityId + '/enroll?token=' + token, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    student_id: sid,
                    student_name: name,
                    class_name: document.getElementById('enroll-class').value
                })
            }).then(function(r) {
                return r.json();
            }).then(function(d) {
                showToast('添加成功！');
                document.getElementById('enroll-id').value = '';
                document.getElementById('enroll-name').value = '';
                document.getElementById('enroll-class').value = '';
                showEnrollments(currentActivityId);
            }).catch(function(e) {
                showToast('添加失败');
            });
        }
        
        function deleteEnroll(id) {
            if (!confirm('确定删除？')) return;
            fetch('/api/admin/activities/' + currentActivityId + '/enrollments/' + id + '?token=' + token, { method: 'DELETE' })
            .then(function(r) {
                return r.json();
            }).then(function(d) {
                showToast('删除成功');
                showEnrollments(currentActivityId);
            }).catch(function(e) {
                showToast('删除失败');
            });
        }
        
        function importExcel() {
            var file = document.getElementById('excel-file').files[0];
            if (!file) return;
            var formData = new FormData();
            formData.append('file', file);
            fetch('/api/admin/activities/' + currentActivityId + '/import-excel?token=' + token, {
                method: 'POST',
                body: formData
            }).then(function(r) {
                return r.json();
            }).then(function(d) {
                if (d.success) {
                    showToast('导入成功：' + d.success_count + '人');
                    document.getElementById('excel-file').value = '';
                    showEnrollments(currentActivityId);
                } else {
                    showToast(d.detail || '导入失败');
                }
            }).catch(function(e) {
                showToast('导入失败');
            });
        }
        
        function showReport(id) {
            fetch('/api/admin/activities/' + id + '/checkin-report?token=' + token).then(function(r) {
                return r.json();
            }).then(function(d) {
                document.getElementById('report-enrolled').textContent = d.total_enrolled;
                document.getElementById('report-checked').textContent = d.total_checked_in;
                document.getElementById('report-absent').textContent = d.absent_count;
                
                var html = '';
                if (!d.items || d.items.length === 0) {
                    html = '<tr><td colspan="3" style="text-align: center; color: #999;">暂无数据</td></tr>';
                } else {
                    for (var i = 0; i < d.items.length; i++) {
                        var item = d.items[i];
                        var cls = item.is_checked_in ? 'row-checked' : 'row-absent';
                        var status = item.is_checked_in ? '✅' : '❌';
                        html += '<tr class="' + cls + '"><td>' + item.student_id + '</td><td>' + item.student_name + '</td><td>' + status + '</td></tr>';
                    }
                }
                document.getElementById('report-list').innerHTML = html;
                document.getElementById('report-modal').classList.add('show');
            }).catch(function(e) {
                console.log('showReport error:', e);
            });
        }
        
        function bindEvents() {
            document.getElementById('logoutBtn').addEventListener('click', logout);
            document.getElementById('tab-dashboard-btn').addEventListener('click', function() { showTab('dashboard'); });
            document.getElementById('tab-activities-btn').addEventListener('click', function() { showTab('activities'); });
            document.getElementById('tab-records-btn').addEventListener('click', function() { showTab('records'); });
            document.getElementById('add-activity-btn').addEventListener('click', showCreateModal);
            document.getElementById('add-activity-btn2').addEventListener('click', showCreateModal);
            document.getElementById('close-create-modal').addEventListener('click', function() { closeModal('create-modal'); });
            document.getElementById('submit-create-btn').addEventListener('click', submitCreate);
            document.getElementById('close-qr-modal').addEventListener('click', function() { closeModal('qr-modal'); });
            document.getElementById('refresh-code-btn').addEventListener('click', refreshCode);
            document.getElementById('stop-activity-btn').addEventListener('click', stopActivity);
            document.getElementById('close-enroll-modal').addEventListener('click', function() { closeModal('enroll-modal'); });
            document.getElementById('upload-excel-btn').addEventListener('click', function() { document.getElementById('excel-file').click(); });
            document.getElementById('add-enroll-btn').addEventListener('click', addEnroll);
            document.getElementById('close-report-modal').addEventListener('click', function() { closeModal('report-modal'); });
            document.getElementById('excel-file').addEventListener('change', importExcel);
        }
        
        ready(function() {
            token = localStorage.getItem('admin_token');
            if (!token) {
                window.location.href = '/admin/login';
                return;
            }
            loadUser();
            loadDashboard();
            loadActivities();
            loadRecords();
            bindEvents();
        });
    </script>
</body>
</html>"""
