"""学生首页 - 讲座报名签到系统"""

STUDENT_MAIN_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>讲座报名签到系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 30px 20px;
        }
        
        /* 顶部用户信息区域 */
        .user-section {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 60px;
        }
        
        .avatar {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: white;
            font-weight: 600;
            box-shadow: 0 4px 20px rgba(79, 172, 254, 0.4);
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-size: 18px;
            font-weight: 600;
            color: white;
            margin-bottom: 4px;
        }
        
        .user-id {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
        }
        
        /* 签到按钮区域 */
        .checkin-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 40px;
        }
        
        .checkin-btn {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            font-size: 24px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 10px 40px rgba(240, 147, 251, 0.4);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .checkin-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 15px 50px rgba(240, 147, 251, 0.5);
        }
        
        .checkin-btn:active {
            transform: scale(0.95);
        }
        
        .checkin-icon {
            font-size: 48px;
        }
        
        .checkin-status {
            font-size: 12px;
            color: rgba(255, 255, 255, 0.8);
            margin-top: 16px;
        }
        
        .checkin-code {
            font-size: 16px;
            font-weight: 600;
            color: white;
            margin-top: 8px;
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            letter-spacing: 3px;
        }
        
        /* 签到弹窗 */
        .checkin-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        
        .checkin-modal-overlay.active {
            display: flex;
        }
        
        .checkin-modal-content {
            background: white;
            width: 90%;
            max-width: 400px;
            border-radius: 24px;
            padding: 30px;
            animation: slideUp 0.3s ease;
        }
        
        @keyframes slideUp {
            from {
                transform: translateY(20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .checkin-modal-header {
            text-align: center;
            margin-bottom: 24px;
        }
        
        .checkin-modal-title {
            font-size: 22px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 8px;
        }
        
        .checkin-modal-desc {
            font-size: 14px;
            color: #888;
        }
        
        .checkin-modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 36px;
            height: 36px;
            border: none;
            border-radius: 50%;
            background: #f0f0f0;
            font-size: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .checkin-options {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        
        .checkin-option {
            padding: 20px;
            border: 2px solid #e9ecef;
            border-radius: 16px;
            cursor: pointer;
            transition: all 0.25s;
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .checkin-option:hover {
            border-color: #667eea;
            background: #f8f9ff;
        }
        
        .checkin-option.active {
            border-color: #667eea;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
        }
        
        .option-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }
        
        .option-info {
            flex: 1;
        }
        
        .option-title {
            font-size: 16px;
            font-weight: 600;
            color: #1a1a2e;
            margin-bottom: 4px;
        }
        
        .option-desc {
            font-size: 13px;
            color: #888;
        }
        
        .qr-scan-area {
            display: none;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 16px;
            margin-top: 16px;
        }
        
        .qr-scan-area.active {
            display: block;
        }
        
        .qr-placeholder {
            width: 100%;
            padding-top: 100%;
            background: #e9ecef;
            border-radius: 12px;
            position: relative;
            margin-bottom: 16px;
        }
        
        .qr-placeholder::after {
            content: '📱';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 48px;
        }
        
        .qr-hint {
            text-align: center;
            font-size: 13px;
            color: #888;
        }
        
        .code-input-area {
            display: none;
            margin-top: 16px;
        }
        
        .code-input-area.active {
            display: block;
        }
        
        .code-input {
            width: 100%;
            padding: 16px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 600;
            text-align: center;
            letter-spacing: 4px;
            outline: none;
            transition: border-color 0.25s;
            margin-bottom: 16px;
        }
        
        .code-input:focus {
            border-color: #667eea;
        }
        
        .confirm-btn {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            transition: all 0.3s ease;
        }
        
        .confirm-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
        }
        
        /* 我的活动按钮 */
        .activities-section {
            display: flex;
            justify-content: center;
        }
        
        .activities-btn {
            width: 100%;
            max-width: 320px;
            padding: 20px;
            border: none;
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.95);
            color: #333;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        
        .activities-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
        }
        
        .activities-icon {
            font-size: 22px;
        }
        
        /* 活动列表弹窗 */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: flex-end;
            z-index: 1000;
        }
        
        .modal-overlay.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            width: 100%;
            max-width: 400px;
            border-radius: 24px 24px 0 0;
            padding: 30px 20px;
            padding-bottom: calc(30px + env(safe-area-inset-bottom));
            animation: slideUp 0.3s ease;
        }
        
        @keyframes slideUp {
            from {
                transform: translateY(100%);
            }
            to {
                transform: translateY(0);
            }
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }
        
        .modal-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a1a2e;
        }
        
        .modal-close {
            width: 36px;
            height: 36px;
            border: none;
            border-radius: 50%;
            background: #f0f0f0;
            font-size: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .activity-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        
        .activity-card {
            padding: 20px;
            background: #f8f9fa;
            border-radius: 12px;
            display: flex;
            gap: 16px;
        }
        
        .activity-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: white;
        }
        
        .activity-info {
            flex: 1;
        }
        
        .activity-name {
            font-size: 16px;
            font-weight: 600;
            color: #1a1a2e;
            margin-bottom: 4px;
        }
        
        .activity-meta {
            font-size: 13px;
            color: #888;
            margin-bottom: 2px;
        }
        
        .activity-status {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 8px;
        }
        
        .activity-status.upcoming {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .activity-status.ongoing {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .activity-status.completed {
            background: #f5f5f5;
            color: #999;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
        }
        
        .empty-icon {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 12px;
        }
        
        .empty-text {
            font-size: 14px;
            color: #999;
        }
        
        /* 签到成功提示 */
        .success-toast {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 20px 40px;
            border-radius: 12px;
            font-size: 16px;
            z-index: 2000;
            animation: fadeIn 0.3s ease;
        }
        
        .success-toast.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translate(-50%, -50%) scale(0.8);
            }
            to {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 顶部用户信息 -->
        <div class="user-section">
            <div class="avatar" id="userAvatar">?</div>
            <div class="user-info">
                <div class="user-name" id="userName">学生</div>
                <div class="user-id" id="userId">学号</div>
            </div>
        </div>
        
        <!-- 签到按钮 -->
        <div class="checkin-section">
            <button class="checkin-btn" id="checkinBtn">
                <span class="checkin-icon">📝</span>
                <span>签到</span>
            </button>
            <div class="checkin-status" id="checkinStatus">点击按钮进行签到</div>
            <div class="checkin-code" id="checkinCode" style="display: none;"></div>
        </div>
        
        <!-- 我的活动按钮 -->
        <div class="activities-section">
            <button class="activities-btn" id="activitiesBtn">
                <span class="activities-icon">📋</span>
                <span>我的活动</span>
            </button>
        </div>
    </div>
    
    <!-- 活动列表弹窗 -->
    <div class="modal-overlay" id="activitiesModal">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modal-title">我的活动</span>
                <button class="modal-close" id="modalClose">×</button>
            </div>
            <div class="activity-list" id="activityList">
                <div class="empty-state">
                    <div class="empty-icon">📭</div>
                    <div class="empty-text">暂无报名的活动</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 签到弹窗 -->
    <div class="checkin-modal-overlay" id="checkinModal">
        <div class="checkin-modal-content">
            <button class="checkin-modal-close" id="checkinModalClose">×</button>
            <div class="checkin-modal-header">
                <div class="checkin-modal-title">📝 签到</div>
                <div class="checkin-modal-desc">选择签到方式</div>
            </div>
            <div class="checkin-options">
                <div class="checkin-option" id="scanOption">
                    <div class="option-icon">📷</div>
                    <div class="option-info">
                        <div class="option-title">扫码签到</div>
                        <div class="option-desc">使用手机扫描二维码进行签到</div>
                    </div>
                </div>
                <div class="checkin-option" id="codeOption">
                    <div class="option-icon">🔢</div>
                    <div class="option-info">
                        <div class="option-title">输入签到码</div>
                        <div class="option-desc">手动输入签到码进行签到</div>
                    </div>
                </div>
            </div>
            <div class="qr-scan-area" id="qrScanArea">
                <div class="qr-placeholder"></div>
                <div class="qr-hint">打开手机扫码APP，扫描屏幕上的二维码</div>
            </div>
            <div class="code-input-area" id="codeInputArea">
                <input type="text" class="code-input" id="checkinCodeInput" placeholder="请输入签到码">
                <button class="confirm-btn" id="confirmCheckinBtn">确认签到</button>
            </div>
        </div>
    </div>
    
    <!-- 成功提示 -->
    <div class="success-toast" id="successToast">✅ 签到成功！</div>
    
    <script>
        var currentToken = localStorage.getItem('student_token');
        var currentUser = null;
        
        function initApp() {
            loadUserInfo();
            loadCheckinCode();
            loadActivities();
            bindEvents();
        }
        
        function loadUserInfo() {
            if (!currentToken) {
                window.location.href = '/student/login';
                return;
            }
            
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/student/profile?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    currentUser = data;
                    document.getElementById('userAvatar').textContent = data.name.charAt(0);
                    document.getElementById('userName').textContent = data.name;
                    document.getElementById('userId').textContent = '学号: ' + data.student_id;
                }
            };
            xhr.send();
        }
        
        function loadCheckinCode() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/student/current-checkin?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (data.activity) {
                        document.getElementById('checkinStatus').textContent = data.activity.name;
                        document.getElementById('checkinCode').textContent = '签到码: ' + data.code;
                        document.getElementById('checkinCode').style.display = 'block';
                    } else {
                        document.getElementById('checkinStatus').textContent = '当前没有进行中的活动';
                    }
                }
            };
            xhr.send();
        }
        
        function loadActivities() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/api/student/activities?token=' + currentToken, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    renderActivityList(data.items || []);
                }
            };
            xhr.send();
        }
        
        function renderActivityList(activities) {
            var container = document.getElementById('activityList');
            
            if (!activities || activities.length === 0) {
                container.innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-text">暂无报名的活动</div></div>';
                return;
            }
            
            var html = '';
            activities.forEach(function(activity) {
                var statusClass = 'completed';
                var statusText = '已结束';
                
                if (activity.is_active) {
                    statusClass = 'ongoing';
                    statusText = '进行中';
                } else if (new Date(activity.start_time) > new Date()) {
                    statusClass = 'upcoming';
                    statusText = '即将开始';
                }
                
                html += '<div class="activity-card">';
                html += '<div class="activity-icon">🎙️</div>';
                html += '<div class="activity-info">';
                html += '<div class="activity-name">' + activity.name + '</div>';
                html += '<div class="activity-meta">' + activity.location + '</div>';
                html += '<div class="activity-meta">' + activity.start_time + '</div>';
                html += '<span class="activity-status ' + statusClass + '">' + statusText + '</span>';
                html += '</div></div>';
            });
            
            container.innerHTML = html;
        }
        
        function bindEvents() {
            // 签到按钮 - 显示签到弹窗
            document.getElementById('checkinBtn').addEventListener('click', function() {
                if (!currentToken) return;
                showCheckinModal();
            });
            
            // 关闭签到弹窗
            document.getElementById('checkinModalClose').addEventListener('click', function() {
                closeCheckinModal();
            });
            
            // 点击遮罩关闭签到弹窗
            document.getElementById('checkinModal').addEventListener('click', function(e) {
                if (e.target === this) {
                    closeCheckinModal();
                }
            });
            
            // 选择扫码签到
            document.getElementById('scanOption').addEventListener('click', function() {
                selectCheckinOption('scan');
            });
            
            // 选择输入签到码
            document.getElementById('codeOption').addEventListener('click', function() {
                selectCheckinOption('code');
            });
            
            // 确认签到按钮
            document.getElementById('confirmCheckinBtn').addEventListener('click', function() {
                submitCheckin();
            });
            
            // 签到码输入回车提交
            document.getElementById('checkinCodeInput').addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    submitCheckin();
                }
            });
            
            // 我的活动按钮
            document.getElementById('activitiesBtn').addEventListener('click', function() {
                document.getElementById('activitiesModal').classList.add('active');
            });
            
            // 关闭弹窗
            document.getElementById('modalClose').addEventListener('click', function() {
                document.getElementById('activitiesModal').classList.remove('active');
            });
            
            // 点击遮罩关闭
            document.getElementById('activitiesModal').addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('active');
                }
            });
        }
        
        function showSuccessToast(message) {
            var toast = document.getElementById('successToast');
            toast.textContent = message;
            toast.classList.add('active');
            
            setTimeout(function() {
                toast.classList.remove('active');
            }, 2000);
        }
        
        function showCheckinModal() {
            document.getElementById('checkinModal').classList.add('active');
            document.getElementById('scanOption').classList.remove('active');
            document.getElementById('codeOption').classList.remove('active');
            document.getElementById('qrScanArea').classList.remove('active');
            document.getElementById('codeInputArea').classList.remove('active');
            document.getElementById('checkinCodeInput').value = '';
        }
        
        function closeCheckinModal() {
            document.getElementById('checkinModal').classList.remove('active');
        }
        
        function selectCheckinOption(option) {
            document.getElementById('scanOption').classList.remove('active');
            document.getElementById('codeOption').classList.remove('active');
            document.getElementById('qrScanArea').classList.remove('active');
            document.getElementById('codeInputArea').classList.remove('active');
            
            if (option === 'scan') {
                document.getElementById('scanOption').classList.add('active');
                document.getElementById('qrScanArea').classList.add('active');
            } else if (option === 'code') {
                document.getElementById('codeOption').classList.add('active');
                document.getElementById('codeInputArea').classList.add('active');
                document.getElementById('checkinCodeInput').focus();
            }
        }
        
        function submitCheckin() {
            var code = document.getElementById('checkinCodeInput').value.trim();
            
            if (!code) {
                alert('请输入签到码');
                return;
            }
            
            if (!currentUser) {
                alert('请先登录');
                return;
            }
            
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/checkin', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        showSuccessToast('✅ 签到成功！');
                        closeCheckinModal();
                        loadCheckinCode();
                        loadActivities();
                    } else {
                        var response = JSON.parse(xhr.responseText);
                        alert(response.detail || '签到失败');
                    }
                }
            };
            xhr.send(JSON.stringify({ activity_code: code, student_id: currentUser.student_id, name: currentUser.name }));
        }
        
        document.addEventListener('DOMContentLoaded', initApp);
    </script>
</body>
</html>
"""
