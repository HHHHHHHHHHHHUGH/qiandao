"""统一登录页面"""

UNIFIED_LOGIN_HTML = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>登录 - 讲座报名签到系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 15px;
        }
        .container {
            background: white;
            border-radius: 24px;
            padding: 35px 30px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
        }
        .logo {
            width: 70px;
            height: 70px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 32px;
        }
        h1 {
            text-align: center;
            color: #1a1a2e;
            font-size: 22px;
            margin-bottom: 6px;
        }
        .subtitle {
            text-align: center;
            color: #888;
            font-size: 13px;
            margin-bottom: 25px;
        }

        .role-tabs {
            display: flex;
            background: #f5f5f5;
            border-radius: 12px;
            padding: 4px;
            margin-bottom: 25px;
        }
        .role-tab {
            flex: 1;
            padding: 12px;
            text-align: center;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            color: #666;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            background: transparent;
        }
        .role-tab.active {
            background: white;
            color: #667eea;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .input-group {
            margin-bottom: 18px;
        }
        .input-group label {
            display: block;
            color: #333;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 6px;
        }
        .input-group input {
            width: 100%;
            padding: 14px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            font-size: 15px;
            outline: none;
            transition: border-color 0.25s;
        }
        .input-group input:focus {
            border-color: #667eea;
        }

        .btn-login {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            margin-top: 10px;
            transition: all 0.3s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
        }
        .btn-login:active {
            transform: translateY(0);
        }
        .btn-login:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }

        .error {
            color: #e53935;
            font-size: 13px;
            text-align: center;
            margin-top: 15px;
            display: none;
            padding: 10px;
            background: #ffebee;
            border-radius: 8px;
        }
        .error.show {
            display: block;
        }

        .admin-inputs { display: none; }
        .student-inputs { display: block; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">📋</div>
        <h1>讲座报名签到系统</h1>
        <p class="subtitle">请选择身份并登录</p>

        <div class="role-tabs">
            <button class="role-tab active" id="tab-student" onclick="switchRole('student')">👨‍🎓 学生</button>
            <button class="role-tab" id="tab-admin" onclick="switchRole('admin')">🔐 管理员</button>
        </div>

        <div class="student-inputs" id="student-form">
            <div class="input-group">
                <label>姓名</label>
                <input type="text" id="studentName" placeholder="请输入姓名">
            </div>
            <div class="input-group">
                <label>学号</label>
                <input type="text" id="studentId" placeholder="请输入学号">
            </div>
        </div>

        <div class="admin-inputs" id="admin-form">
            <div class="input-group">
                <label>用户名</label>
                <input type="text" id="adminUsername" placeholder="请输入用户名">
            </div>
            <div class="input-group">
                <label>密码</label>
                <input type="password" id="adminPassword" placeholder="请输入密码">
            </div>
        </div>

        <button class="btn-login" id="loginBtn" onclick="doLogin()">登录</button>
        <div class="error" id="errorMsg">登录失败</div>
    </div>

    <script>
        var currentRole = 'student';

        window.onload = function() {
            var btn = document.getElementById('loginBtn');
            btn.disabled = false;
            btn.textContent = '登录';
        };

        function switchRole(role) {
            currentRole = role;
            document.getElementById('tab-student').classList.toggle('active', role === 'student');
            document.getElementById('tab-admin').classList.toggle('active', role === 'admin');
            document.getElementById('student-form').style.display = role === 'student' ? 'block' : 'none';
            document.getElementById('admin-form').style.display = role === 'admin' ? 'block' : 'none';
            document.getElementById('errorMsg').classList.remove('show');
        }

        function doLogin() {
            var btn = document.getElementById('loginBtn');
            var errorMsg = document.getElementById('errorMsg');

            if (currentRole === 'student') {
                var name = document.getElementById('studentName').value.trim();
                var studentId = document.getElementById('studentId').value.trim();

                if (!name || !studentId) {
                    errorMsg.textContent = '请填写姓名和学号';
                    errorMsg.classList.add('show');
                    return;
                }

                btn.disabled = true;
                btn.textContent = '登录中...';

                fetch('/api/student/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ student_id: studentId, name: name })
                }).then(r => {
                    if (r.ok) return r.json();
                    throw new Error('登录失败');
                }).then(d => {
                    localStorage.setItem('student_token', d.token);
                    window.location.href = '/student/main';
                }).catch(e => {
                    errorMsg.textContent = '学号或姓名错误';
                    errorMsg.classList.add('show');
                    btn.disabled = false;
                    btn.textContent = '登录';
                });

            } else {
                var username = document.getElementById('adminUsername').value.trim();
                var password = document.getElementById('adminPassword').value.trim();

                if (!username || !password) {
                    errorMsg.textContent = '请填写用户名和密码';
                    errorMsg.classList.add('show');
                    return;
                }

                btn.disabled = true;
                btn.textContent = '登录中...';

                fetch('/api/admin/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username: username, password: password })
                }).then(r => {
                    if (r.ok) return r.json();
                    throw new Error('登录失败');
                }).then(d => {
                    localStorage.setItem('admin_token', d.access_token);
                    window.location.href = '/admin/main';
                }).catch(e => {
                    errorMsg.textContent = '用户名或密码错误';
                    errorMsg.classList.add('show');
                    btn.disabled = false;
                    btn.textContent = '登录';
                });
            }
        }

        document.getElementById('studentId').addEventListener('keyup', function(e) {
            if (e.key === 'Enter') doLogin();
        });
        document.getElementById('adminPassword').addEventListener('keyup', function(e) {
            if (e.key === 'Enter') doLogin();
        });
    </script>
</body>
</html>'''
