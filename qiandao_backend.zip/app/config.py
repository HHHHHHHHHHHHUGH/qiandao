"""应用配置集中管理。"""
from pathlib import Path
import tempfile
import random
import string

BASE_DIR = Path(__file__).resolve().parent.parent

DATABASE_URL = f"sqlite:///{tempfile.gettempdir()}/qiandao.db?charset=utf8"

SECRET_KEY = "your-secret-key-here-change-in-production"

ALGORITHM = "HS256"

ACCESS_TOKEN_EXPIRE_MINUTES = 30

CHECKIN_COOLDOWN_SECONDS = 10

CORS_ORIGINS = [
    "http://localhost:8000",
    "http://127.0.0.1:8000",
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

def generate_checkin_code(length: int = 6) -> str:
    """生成随机签到码"""
    return ''.join(random.choices(string.digits, k=length))