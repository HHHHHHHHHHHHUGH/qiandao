"""简单创建活动页面"""

from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from .database import get_db
from .models import Activity
from .config import generate_checkin_code

router = APIRouter()

@router.get("/create-activity")
async def create_activity_page(request: Request):
    token = request.cookies.get("admin_token") or request.query_params.get("token")
    if not token:
        return RedirectResponse(url="/admin/login")
    
    return """
<!DOCTYPE html>
<html>
<head>
    <title>创建活动</title>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); min-height: 100vh; padding: 30px; }
        .container { max-width: 500px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 30px; color: #333; }
        input {
            width: 100%;
            padding: 14px;
            margin-bottom: 15px;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            font-size: 14px;
            box-sizing: border-box;
        }
        input:focus { outline: none; border-color: #667eea; }
        button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }
        button:hover { transform: translateY(-2px); }
        .success { color: green; text-align: center; padding: 15px; background: #d4edda; border-radius: 8px; margin-bottom: 20px; }
        .error { color: red; text-align: center; padding: 15px; background: #f8d7da; border-radius: 8px; margin-bottom: 20px; }
        .back-link { display: block; text-align: center; margin-top: 20px; color: #667eea; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <h2>📋 创建活动</h2>
        <form method="POST">
            <input type="text" name="name" placeholder="活动名称" required>
            <input type="text" name="description" placeholder="活动描述（可选）">
            <input type="text" name="location" placeholder="活动地点（可选）">
            <input type="text" name="department" placeholder="所属部门（可选）">
            <input type="number" name="checkin_duration" placeholder="签到时长（分钟）" value="30" min="1">
            <button type="submit">创建活动</button>
        </form>
        <a href="/admin/simple" class="back-link">← 返回活动列表</a>
    </div>
</body>
</html>
"""

@router.post("/create-activity")
async def create_activity_post(name: str = Form(...), description: str = Form(""), 
                               location: str = Form(""), department: str = Form(""),
                               checkin_duration: int = Form(30)):
    db = next(get_db())
    try:
        code = generate_checkin_code()
        activity = Activity(
            name=name,
            description=description,
            location=location,
            department=department,
            code=code,
            checkin_duration=checkin_duration
        )
        db.add(activity)
        db.commit()
        db.refresh(activity)
        
        return HTMLResponse(content=f"""
<!DOCTYPE html>
<html>
<head>
    <title>创建成功</title>
    <meta charset="utf-8">
    <style>
        body {{ font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); min-height: 100vh; padding: 30px; }}
        .container {{ max-width: 400px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; text-align: center; }}
        .success-icon {{ font-size: 60px; margin-bottom: 20px; }}
        h2 {{ color: #333; }}
        .info {{ margin: 20px 0; color: #666; }}
        button {{
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="success-icon">✅</div>
        <h2>创建成功！</h2>
        <div class="info">活动名称: {name}</div>
        <div class="info">签到码: {code}</div>
        <button onclick="window.location.href='/admin/simple'">返回活动列表</button>
    </div>
</body>
</html>
""")
    except Exception as e:
        return HTMLResponse(content=f"""
<!DOCTYPE html>
<html>
<head>
    <title>创建失败</title>
    <meta charset="utf-8">
    <style>
        body {{ font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); min-height: 100vh; padding: 30px; }}
        .container {{ max-width: 400px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; text-align: center; }}
        .error-icon {{ font-size: 60px; margin-bottom: 20px; }}
        h2 {{ color: #333; }}
        .info {{ margin: 20px 0; color: #e53935; }}
        button {{
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="error-icon">❌</div>
        <h2>创建失败</h2>
        <div class="info">{str(e)}</div>
        <button onclick="window.location.href='/create-activity'">返回重试</button>
    </div>
</body>
</html>
""")
